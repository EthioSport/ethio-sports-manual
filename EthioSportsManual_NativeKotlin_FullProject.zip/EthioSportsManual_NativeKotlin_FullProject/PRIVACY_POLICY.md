# የግላዊነት ፖሊሲ እና የአገልግሎት ውል | Privacy Policy & Terms of Service

**የመተግበሪያ ስም (App Name):** ኢትዮ-ስፖርት ደንብ (Ethio-Sports Rulebook)  
**የፓኬጅ ስም (Package Name):** `eth.culturalsports.manual`  
**ባለቤት (Official Institution):** የኢትዮጵያ ባህል ስፖርቶች ፌዴሬሽን (Ethiopian Cultural Sports Federation)  
**ስሪት (Version):** 1.0.0 (Version Code: 1)

---

## ክፍል 1፦ የአማርኛ የግላዊነት ፖሊሲ (Amharic Privacy Policy)

### 1. አጠቃላይ መግቢያ
**«ኢትዮ-ስፖርት ደንብ»** መተግበሪያ የባህል ስፖርቶቻችንን በመላ ሀገሪቱ ለማጥናት፣ ለመጠበቅ፣ ለማስፋፋት፣ ለማስተዋወቅ፣ ለማልማት እንዲሁም ለመምራት ከኢ.ፌ.ዲ.ሪ ባህልና ስፖርት ሚኒስቴር ፈቃድ ተሰጥቶት በ1970 ዓ.ም በተመሰረተው አንጋፋው **የኢትዮጵያ ባህል ስፖርቶች ፌዴሬሽን** የተዘጋጀውን የተሻሻለው የውድድር ህግና ደንብ ማንዋል በ100% Native Android ቴክኖሎጂ ለተጠቃሚዎች የሚያቀርብ ነፃ የትምህርትና የማጣቀሻ መተግበሪያ ነው።

### 2. ምንም ዓይነት የግል መረጃ አለመሰብሰብ (Zero Data Collection)
* ይህ መተግበሪያ **100% ያለ ኢንተርኔት (Offline-First)** ይሰራል።
* መተግበሪያው በ`AndroidManifest.xml` ውስጥ የኢንተርኔት ፈቃድ (`android.permission.INTERNET`) እንኳ አይጠይቅም።
* የተጠቃሚን ስም፣ ስልክ ቁጥር፣ የኢሜይል አድራሻ፣ የመገኛ ቦታ (GPS Location)፣ የስልክ መለያ (Device ID) ወይም የአጠቃቀም መረጃ (Analytics/Tracking) በፍጹም አይሰበስብም፣ አያከማችም፣ ለሶስተኛ ወገንም አያጋራም።

### 3. በስልክ ውስጥ ብቻ የሚቀመط መረጃ (Local Storage & Security)
* ተጠቃሚው የሚመርጠው ቋንቋ (አማርኛ ወይም እንግሊዝኛ)፣ የፊደል መጠን (Font Scale)፣ የጨለማ/ብርሃን ገጽታ (Dark/Light Mode)፣ ምልክት የተደረገባቸው ገፆች (Bookmarks) እና የብቃት ምዘና ውጤቶች (Quiz Scores) በስልኩ ውስጣዊ ማህደር (`Room Database` እና `Jetpack DataStore`) ውስጥ ብቻ ይቀመጣሉ።
* ለዳኞችና ለፌዴሬሽን አመራሮች የተዘጋጀው የግል ማስታወሻ ክፍል በ`EncryptedSharedPreferences` እና በስልኩ የጣት አሻራ (`BiometricPrompt`) የተጠበቀ ሲሆን ከስልኩ ውጭ ወደ የትኛውም ሰርቨር አይላክም።

### 4. ከማስታወቂያና ከክፍያ ነፃ (Zero Ads & Zero Monetization)
* መተግበሪያው ምንም ዓይነት የንግድ ማስታወቂያ (No AdMob / No Third-Party Ads) ወይም የውስጥ ክፍያ (No In-App Purchases) የለውም።

### 5. የውጭ ማስፈንጠሪያዎች (External Links)
* በ«ስለ እኛ» (About Us) ገጽ ላይ የተቀመጡት የፌዴሬሽኑ ኦፊሴላዊ የኢሜይል፣ የቴሌግራም እና የፌስቡክ አድራሻዎች ተጠቃሚው ራሱ ሲነካቸው ብቻ በስልኩ ላይ ወዳለው የኢሜይል ወይም የብራውዘር መተግበሪያ ይከፈታሉ።

---

## Part 2: English Privacy Policy (Google Play Console Compliant)

### 1. Overview & Institutional Authority
**Ethio-Sports Rulebook (`eth.culturalsports.manual`)** is a 100% offline-first native Android educational and officiating reference application presenting the official Revised Competition Rules, Referee Signals, and Competition Score Forms of the **Ethiopian Cultural Sports Federation** (established in 1970 E.C. under the authorization of the FDRE Ministry of Culture and Sport).

### 2. Zero Personal Data Collection & Zero Permissions
* **No Internet Permission:** The application does not declare `android.permission.INTERNET` and makes zero network requests.
* **No External Storage Permission:** The application does not request `READ_EXTERNAL_STORAGE` or `WRITE_EXTERNAL_STORAGE`.
* **No Analytics or Tracking SDKs:** The application contains zero third-party analytics, crash-reporting, or tracking libraries.

### 3. Local Device Storage & Encryption
* User preferences (in-app language selection between Amharic and English, text size scaling, dark/light theme, bookmarks, and quiz scores) are stored strictly locally inside app-specific storage via Android Jetpack `DataStore`, `Room Database`, and `EncryptedSharedPreferences`.
* Optional biometric verification (`USE_BIOMETRIC`) is processed strictly by the Android operating system hardware keystore to unlock local referee notes and never leaves the device.

### 4. Contact Information
* **Institution:** Ethiopian Cultural Sports Federation (የኢትዮጵያ ባህል ስፖርቶች ፌዴሬሽን)
* **Email:** eth.culturalsportsfed.1977@gmail.com
* **Telegram:** @EthiopianculturalsportFDE
* **Facebook:** https://www.facebook.com/profile.php?id=61558619311072
* **Address:** 📍 Addis Ababa Stadium, next to Bethzatha Hospital, OBS Building 4th Floor, Office No. 406

© Ethiopian Cultural Sports Federation - All Rights Reserved.
