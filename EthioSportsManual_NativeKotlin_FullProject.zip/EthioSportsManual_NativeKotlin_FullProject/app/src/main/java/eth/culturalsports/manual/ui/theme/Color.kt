package eth.culturalsports.manual.ui.theme

import androidx.compose.ui.graphics.Color

val EthioGreen = Color(0xFF078930)
val EthioGreenDark = Color(0xFF065F46)
val EthioYellow = Color(0xFFF59E0B)
val EthioGold = Color(0xFFFBBF24)
val EthioRed = Color(0xFFDC2626)
val EthioBlue = Color(0xFF1D4ED8)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)

val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFE2E8F0)
