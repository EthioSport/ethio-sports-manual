package eth.culturalsports.manual.domain.repository

import eth.culturalsports.manual.domain.model.Chapter
import eth.culturalsports.manual.domain.model.QuizQuestion

interface ManualRepository {
    fun getCategories(languageCode: String): List<String>
    fun getChapters(languageCode: String): List<Chapter>
    fun getQuizzes(languageCode: String): List<QuizQuestion>
}
