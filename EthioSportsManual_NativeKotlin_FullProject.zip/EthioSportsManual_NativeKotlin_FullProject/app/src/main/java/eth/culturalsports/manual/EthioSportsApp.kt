package eth.culturalsports.manual

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class EthioSportsApp : Application()
