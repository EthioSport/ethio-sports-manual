package eth.culturalsports.manual

import android.app.Application

class EthioSportsApp : Application()
