package eth.culturalsports.manual.ui.components

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import eth.culturalsports.manual.R
import eth.culturalsports.manual.domain.model.SportFieldType
import eth.culturalsports.manual.domain.model.TacticalPebble
import eth.culturalsports.manual.domain.model.TacticalStroke
import eth.culturalsports.manual.domain.model.TacticalTool
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun InteractiveSportFieldCard(
    fieldType: SportFieldType,
    isAmharic: Boolean,
    tacticalTool: TacticalTool = TacticalTool.PAN_ZOOM,
    activeColor: Color = Color(0xFFFBBF24),
    isDashed: Boolean = false,
    strokes: List<TacticalStroke> = emptyList(),
    pebbles: List<TacticalPebble> = emptyList(),
    onAddStroke: (TacticalStroke) -> Unit = {},
    onAddPebble: (TacticalPebble) -> Unit = {},
    onOpenFullTacticalBoard: (() -> Unit)? = null
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val activeDragPoints = remember { mutableStateListOf<Offset>() }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.field_diagram_title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { scale = (scale - 0.25f).coerceAtLeast(1f) }) {
                        Icon(Icons.Default.Remove, contentDescription = stringResource(R.string.field_reset_zoom))
                    }
                    IconButton(onClick = { scale = (scale + 0.25f).coerceAtMost(3.5f) }) {
                        Icon(Icons.Default.Add, contentDescription = stringResource(R.string.field_zoom_hint))
                    }
                    IconButton(onClick = {
                        scale = 1f
                        offsetX = 0f
                        offsetY = 0f
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = stringResource(R.string.field_reset_zoom))
                    }
                }
            }

            Text(
                text = stringResource(R.string.field_zoom_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.65f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F172A))
                    .border(2.dp, Color(0xFFF59E0B), RoundedCornerShape(12.dp))
                    .pointerInput(tacticalTool) {
                        if (tacticalTool == TacticalTool.PAN_ZOOM) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 3.5f)
                                if (scale > 1f) {
                                    offsetX = (offsetX + pan.x).coerceIn(-600f, 600f)
                                    offsetY = (offsetY + pan.y).coerceIn(-400f, 400f)
                                } else {
                                    offsetX = 0f
                                    offsetY = 0f
                                }
                            }
                        }
                    }
                    .pointerInput(tacticalTool, activeColor, isDashed) {
                        if (tacticalTool == TacticalTool.FREEHAND_LINE || tacticalTool == TacticalTool.TACTICAL_ARROW) {
                            detectDragGestures(
                                onDragStart = { startOffset ->
                                    activeDragPoints.clear()
                                    activeDragPoints.add(startOffset)
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    activeDragPoints.add(change.position)
                                },
                                onDragEnd = {
                                    if (activeDragPoints.size >= 2) {
                                        onAddStroke(
                                            TacticalStroke(
                                                points = activeDragPoints.toList(),
                                                color = activeColor,
                                                isArrow = (tacticalTool == TacticalTool.TACTICAL_ARROW),
                                                isDashed = isDashed
                                            )
                                        )
                                    }
                                    activeDragPoints.clear()
                                }
                            )
                        }
                    }
                    .pointerInput(tacticalTool, activeColor, pebbles.size) {
                        if (tacticalTool == TacticalTool.PLACE_PEBBLE) {
                            detectTapGestures { tapOffset ->
                                onAddPebble(
                                    TacticalPebble(
                                        position = tapOffset,
                                        color = activeColor,
                                        label = "${pebbles.size + 1}"
                                    )
                                )
                            }
                        }
                    }
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offsetX,
                            translationY = offsetY
                        )
                ) {
                    drawSportFieldVector(fieldType = fieldType, isAm = isAmharic)

                    // Draw saved tactical strokes
                    for (stroke in strokes) {
                        drawTacticalStroke(stroke)
                    }

                    // Draw active drag stroke
                    if (activeDragPoints.size >= 2) {
                        drawTacticalStroke(
                            TacticalStroke(
                                points = activeDragPoints,
                                color = activeColor,
                                isArrow = (tacticalTool == TacticalTool.TACTICAL_ARROW),
                                isDashed = isDashed
                            )
                        )
                    }

                    // Draw placed pebbles/tokens
                    for (pebble in pebbles) {
                        drawCircle(
                            color = Color.Black,
                            radius = 15f,
                            center = pebble.position
                        )
                        drawCircle(
                            color = pebble.color,
                            radius = 13f,
                            center = pebble.position
                        )
                        drawCanvasLabel(
                            text = pebble.label,
                            x = pebble.position.x,
                            y = pebble.position.y + 5f,
                            color = Color.Black,
                            textSize = 16f,
                            alignCenter = true
                        )
                    }
                }
            }

            if (onOpenFullTacticalBoard != null) {
                Spacer(modifier = Modifier.height(8.dp))
                AssistChip(
                    onClick = onOpenFullTacticalBoard,
                    label = { Text(text = stringResource(R.string.field_open_tactical)) }
                )
            }
        }
    }
}

private fun DrawScope.drawTacticalStroke(stroke: TacticalStroke) {
    if (stroke.points.size < 2) return
    val pathEffect = if (stroke.isDashed) PathEffect.dashPathEffect(floatArrayOf(16f, 12f), 0f) else null
    if (stroke.isArrow) {
        val start = stroke.points.first()
        val end = stroke.points.last()
        drawLine(
            color = stroke.color,
            start = start,
            end = end,
            strokeWidth = stroke.strokeWidth,
            cap = StrokeCap.Round,
            pathEffect = pathEffect
        )
        val angle = atan2((end.y - start.y).toDouble(), (end.x - start.x).toDouble()).toFloat()
        val headLen = 24f
        val wing1 = Offset(
            end.x - headLen * cos(angle - 0.45f),
            end.y - headLen * sin(angle - 0.45f)
        )
        val wing2 = Offset(
            end.x - headLen * cos(angle + 0.45f),
            end.y - headLen * sin(angle + 0.45f)
        )
        val headPath = Path().apply {
            moveTo(end.x, end.y)
            lineTo(wing1.x, wing1.y)
            lineTo(wing2.x, wing2.y)
            close()
        }
        drawPath(path = headPath, color = stroke.color)
    } else {
        val path = Path().apply {
            moveTo(stroke.points.first().x, stroke.points.first().y)
            for (pt in stroke.points.drop(1)) {
                lineTo(pt.x, pt.y)
            }
        }
        drawPath(
            path = path,
            color = stroke.color,
            style = Stroke(width = stroke.strokeWidth, cap = StrokeCap.Round, pathEffect = pathEffect)
        )
    }
}

private fun DrawScope.drawCanvasLabel(
    text: String,
    x: Float,
    y: Float,
    color: Color = Color.White,
    textSize: Float = 22f,
    alignCenter: Boolean = false
) {
    drawContext.canvas.nativeCanvas.apply {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            setColor(color.toArgb())
            setTextSize(textSize)
            setFakeBoldText(true)
            setTextAlign(if (alignCenter) Paint.Align.CENTER else Paint.Align.LEFT)
        }
        drawText(text, x, y, paint)
    }
}

private fun DrawScope.drawSportFieldVector(fieldType: SportFieldType, isAm: Boolean) {
    val w = size.width
    val h = size.height
    val padX = w * 0.06f
    val padY = h * 0.12f
    val fw = w - padX * 2
    val fh = h - padY * 2

    when (fieldType) {
        SportFieldType.GENA_PITCH -> {
            drawRect(color = Color(0xFF14532D), size = size)
            val stripeCount = 8
            val stripeW = fw / stripeCount
            for (i in 0 until stripeCount) {
                drawRect(
                    color = if (i % 2 == 0) Color(0xFF1E4E28) else Color(0xFF163E1F),
                    topLeft = Offset(padX + i * stripeW, padY),
                    size = Size(stripeW, fh)
                )
            }
            drawRect(color = Color.White, topLeft = Offset(padX, padY), size = Size(fw, fh), style = Stroke(4f))
            drawLine(color = Color.White, start = Offset(w / 2, padY), end = Offset(w / 2, padY + fh), strokeWidth = 3.5f)
            drawCircle(color = Color.White, radius = fh * 0.16f, center = Offset(w / 2, h / 2), style = Stroke(3.5f))
            // Penalty boxes (10m x 6m)
            val penW = fw * 0.12f
            val penH = fh * 0.45f
            drawRect(color = Color.White, topLeft = Offset(padX, h / 2 - penH / 2), size = Size(penW, penH), style = Stroke(3f))
            drawRect(color = Color.White, topLeft = Offset(w - padX - penW, h / 2 - penH / 2), size = Size(penW, penH), style = Stroke(3f))
            // 3m Goal posts
            val goalH = fh * 0.22f
            drawLine(color = Color(0xFFEF4444), start = Offset(padX, h / 2 - goalH / 2), end = Offset(padX, h / 2 + goalH / 2), strokeWidth = 8f)
            drawLine(color = Color(0xFFEF4444), start = Offset(w - padX, h / 2 - goalH / 2), end = Offset(w - padX, h / 2 + goalH / 2), strokeWidth = 8f)
            drawCanvasLabel(
                text = if (isAm) "የገና ሜዳ፦ ርዝመት 90-100 ሜትር × ወርድ 45-50 ሜትር | የግብ ስፋት 3 ሜትር × ከፍታ 2 ሜትር"
                else "Gena Pitch: Length 90-100m × Width 45-50m | Goal 3m × 2m | Center Circle R=4m",
                x = w / 2, y = padY * 0.68f, color = Color(0xFFFCD34D), textSize = w * 0.025f, alignCenter = true
            )
        }

        SportFieldType.TIGL_WRESTLING_MAT -> {
            drawRect(color = Color(0xFF0F172A), size = size)
            val outerS = fh * 0.92f
            val outerX = (w - outerS) / 2
            val outerY = (h - outerS) / 2 + 8f
            drawRect(color = Color(0xFF475569), topLeft = Offset(outerX, outerY), size = Size(outerS, outerS))
            drawRect(color = Color(0xFF38BDF8), topLeft = Offset(outerX, outerY), size = Size(outerS, outerS), style = Stroke(4f))
            val innerS = outerS * 0.78f
            val innerX = (w - innerS) / 2
            val innerY = outerY + (outerS - innerS) / 2
            drawRect(color = Color(0xFF14532D), topLeft = Offset(innerX, innerY), size = Size(innerS, innerS))
            drawRect(color = Color.White, topLeft = Offset(innerX, innerY), size = Size(innerS, innerS), style = Stroke(3.5f))
            drawCircle(color = Color(0xFFFBBF24), radius = innerS * 0.22f, center = Offset(w / 2, innerY + innerS / 2), style = Stroke(4f))
            drawCanvasLabel(
                text = if (isAm) "የትግል ፍራሽ፦ ውጫዊ 6×6 ሜትር | የውስጥ መታገያ 5×5 ሜትር | 50 ሴ.ሜ የደህንነት ርቀት"
                else "Tigl Mat: Outer 6m×6m | Inner Wrestling Zone 5m×5m | 50cm Safety Zone",
                x = w / 2, y = padY * 0.62f, color = Color(0xFFFCD34D), textSize = w * 0.025f, alignCenter = true
            )
        }

        SportFieldType.KURBO_FIELD -> {
            drawRect(color = Color(0xFF1E3F18), size = size)
            drawRect(color = Color.White, topLeft = Offset(padX, padY), size = Size(fw, fh), style = Stroke(3.5f))
            val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 8f), 0f)
            val menX = padX + fw * 0.18f
            val womenX = padX + fw * 0.38f
            val trackX = padX + fw * 0.78f
            drawLine(color = Color(0xFFFCD34D), start = Offset(menX, padY), end = Offset(menX, padY + fh), strokeWidth = 5f, pathEffect = dash)
            drawLine(color = Color(0xFF38BDF8), start = Offset(womenX, padY), end = Offset(womenX, padY + fh), strokeWidth = 5f, pathEffect = dash)
            drawRect(color = Color(0x33FFFFFF), topLeft = Offset(trackX, padY + fh * 0.1f), size = Size(fw * 0.09f, fh * 0.8f))
            drawRect(color = Color.White, topLeft = Offset(trackX, padY + fh * 0.1f), size = Size(fw * 0.09f, fh * 0.8f), style = Stroke(3f))
            drawCircle(color = Color(0xFFEA580C), radius = fh * 0.09f, center = Offset(trackX + fw * 0.045f, h / 2), style = Stroke(7f))
            drawCanvasLabel(
                text = if (isAm) "የኩርቦ ሜዳ፦ ወንዶች መወርወሪያ 10 ሜትር | ሴቶች 7 ሜትር | መንከባለያ ትራክ 10 × 1.25 ሜትር"
                else "Kurbo Field: Men's Line 10m | Women's Line 7m | Rolling Track 10m × 1.25m",
                x = w / 2, y = padY * 0.68f, color = Color(0xFFFCD34D), textSize = w * 0.025f, alignCenter = true
            )
        }

        SportFieldType.KINCHIBOSH_12_BOARD -> {
            drawRect(color = Color(0xFF291509), size = size)
            drawRoundRect(color = Color(0xFF4E230D), topLeft = Offset(padX, padY), size = Size(fw, fh), cornerRadius = CornerRadius(20f, 20f))
            drawRoundRect(color = Color(0xFFFCD34D), topLeft = Offset(padX, padY), size = Size(fw, fh), cornerRadius = CornerRadius(20f, 20f), style = Stroke(4f))
            val innerX = padX + fw * 0.14f
            val innerW = fw * 0.72f
            drawRect(color = Color(0xFF9A3412), topLeft = Offset(innerX, padY + 12f), size = Size(innerW, fh / 2 - 12f))
            drawRect(color = Color(0xFF065F46), topLeft = Offset(innerX, h / 2), size = Size(innerW, fh / 2 - 12f))
            drawLine(color = Color(0xFFEF4444), start = Offset(innerX, h / 2), end = Offset(innerX + innerW, h / 2), strokeWidth = 5f)
            // Stores
            drawOval(color = Color(0xFF1C0A02), topLeft = Offset(padX + fw * 0.03f, padY + fh * 0.18f), size = Size(fw * 0.08f, fh * 0.64f))
            drawOval(color = Color(0xFF1C0A02), topLeft = Offset(w - padX - fw * 0.11f, padY + fh * 0.18f), size = Size(fw * 0.08f, fh * 0.64f))
            // 12 Holes (6x2) with 4 pebbles each
            val holeR = fh * 0.11f
            for (r in 0..1) {
                for (c in 0..5) {
                    val cx = innerX + (c + 0.5f) * (innerW / 6f)
                    val cy = if (r == 0) padY + fh * 0.28f else padY + fh * 0.72f
                    drawCircle(color = Color(0xFF1C1917), radius = holeR, center = Offset(cx, cy))
                    drawCircle(color = if (r == 0) Color(0xFFFB923C) else Color(0xFF34D399), radius = holeR, center = Offset(cx, cy), style = Stroke(3f))
                    val d = holeR * 0.36f
                    for (ox in listOf(-d, d)) {
                        for (oy in listOf(-d, d)) {
                            drawCircle(color = Color(0xFFFBBF24), radius = holeR * 0.22f, center = Offset(cx + ox, cy + oy))
                        }
                    }
                }
            }
            drawCanvasLabel(
                text = if (isAm) "ባለ 12 ጉድጓድ ቅንጭቦሽ ገበጣ፦ 84×27 ሴ.ሜ | 6-6 ቤቶች | በእያንዳንዱ 4 ጠጠር (48 ጠጠሮች)"
                else "12-Hole Kinchibosh Gebeta: 84×27cm | 6-6 Houses | 4 Pebbles/Hole (48 Pebbles)",
                x = w / 2, y = padY * 0.68f, color = Color(0xFFFCD34D), textSize = w * 0.024f, alignCenter = true
            )
        }

        SportFieldType.SLUS_18_BOARD -> {
            drawRect(color = Color(0xFF291509), size = size)
            drawRoundRect(color = Color(0xFF4E230D), topLeft = Offset(padX, padY), size = Size(fw, fh), cornerRadius = CornerRadius(20f, 20f))
            drawRoundRect(color = Color(0xFFFCD34D), topLeft = Offset(padX, padY), size = Size(fw, fh), cornerRadius = CornerRadius(20f, 20f), style = Stroke(4f))
            val innerX = padX + fw * 0.14f
            val innerW = fw * 0.72f
            val holeR = fh * 0.09f
            for (r in 0..2) {
                for (c in 0..5) {
                    val isP2 = (r == 0) || (r == 1 && c < 3)
                    val cx = innerX + (c + 0.5f) * (innerW / 6f)
                    val cy = padY + (r + 0.5f) * (fh / 3f)
                    drawCircle(color = if (isP2) Color(0xFF451A03) else Color(0xFF022C22), radius = holeR, center = Offset(cx, cy))
                    drawCircle(color = if (isP2) Color(0xFFFB923C) else Color(0xFF34D399), radius = holeR, center = Offset(cx, cy), style = Stroke(3f))
                    val d = holeR * 0.35f
                    drawCircle(color = Color(0xFFFBBF24), radius = holeR * 0.22f, center = Offset(cx, cy - d))
                    drawCircle(color = Color(0xFFFBBF24), radius = holeR * 0.22f, center = Offset(cx - d, cy + d * 0.8f))
                    drawCircle(color = Color(0xFFFBBF24), radius = holeR * 0.22f, center = Offset(cx + d, cy + d * 0.8f))
                }
            }
            // Stepped red divider separating 9 & 9 holes
            val stepPath = Path().apply {
                moveTo(innerX, padY + fh * (2f / 3f))
                lineTo(innerX + innerW / 2f, padY + fh * (2f / 3f))
                lineTo(innerX + innerW / 2f, padY + fh * (1f / 3f))
                lineTo(innerX + innerW, padY + fh * (1f / 3f))
            }
            drawPath(path = stepPath, color = Color(0xFFEF4444), style = Stroke(5f))
            drawCanvasLabel(
                text = if (isAm) "ባለ 18 ጉድጓድ ስሉስ ገበጣ፦ 96-100 × 34-38 ሴ.ሜ | 9-9 ቤቶች | በእያንዳንዱ 3 ጠጠር (54 ጠጠሮች)"
                else "18-Hole Slus Gebeta: 96-100×34-38cm | Stepped 9-9 Houses | 3 Pebbles/Hole (54 Total)",
                x = w / 2, y = padY * 0.68f, color = Color(0xFFFCD34D), textSize = w * 0.024f, alignCenter = true
            )
        }

        SportFieldType.SHAH_BOARD -> {
            drawRect(color = Color(0xFF0F172A), size = size)
            val bs = fh * 0.88f
            val bx = (w - bs) / 2f
            val by = padY + (fh - bs) / 2f
            drawRect(color = Color(0xFF22C55E), topLeft = Offset(bx, by), size = Size(bs, bs))
            drawRect(color = Color.Black, topLeft = Offset(bx, by), size = Size(bs, bs), style = Stroke(5f))
            val off1 = bs * 0.16f
            drawRect(color = Color(0xFFEAB308), topLeft = Offset(bx + off1, by + off1), size = Size(bs - off1 * 2, bs - off1 * 2))
            drawRect(color = Color.Black, topLeft = Offset(bx + off1, by + off1), size = Size(bs - off1 * 2, bs - off1 * 2), style = Stroke(5f))
            val off2 = bs * 0.32f
            drawRect(color = Color(0xFFEF4444), topLeft = Offset(bx + off2, by + off2), size = Size(bs - off2 * 2, bs - off2 * 2))
            drawRect(color = Color.Black, topLeft = Offset(bx + off2, by + off2), size = Size(bs - off2 * 2, bs - off2 * 2), style = Stroke(5f))
            val midX = bx + bs / 2f
            val midY = by + bs / 2f
            drawLine(Color.Black, Offset(midX, by), Offset(midX, by + off2), strokeWidth = 5f)
            drawLine(Color.Black, Offset(midX, by + bs - off2), Offset(midX, by + bs), strokeWidth = 5f)
            drawLine(Color.Black, Offset(bx, midY), Offset(bx + off2, midY), strokeWidth = 5f)
            drawLine(Color.Black, Offset(bx + bs - off2, midY), Offset(bx + bs, midY), strokeWidth = 5f)
            for (off in listOf(0f, off1, off2)) {
                val x0 = bx + off
                val y0 = by + off
                val s = bs - off * 2f
                val pts = listOf(
                    Offset(x0, y0), Offset(x0 + s / 2f, y0), Offset(x0 + s, y0),
                    Offset(x0 + s, y0 + s / 2f), Offset(x0 + s, y0 + s),
                    Offset(x0 + s / 2f, y0 + s), Offset(x0, y0 + s), Offset(x0, y0 + s / 2f)
                )
                for (pt in pts) {
                    drawCircle(Color.Black, radius = 9f, center = pt)
                    drawCircle(Color.White, radius = 9f, center = pt, style = Stroke(2f))
                }
            }
            drawCanvasLabel(
                text = if (isAm) "የሻህ ቦርድ፦ 40×40 ሴ.ሜ | 3 ካሬዎች (አረንጓዴ፣ ቢጫ፣ ቀይ) | 24 ጣቢያዎች | 9-9 ጠጠሮች"
                else "Shah Board: 40×40cm | 3 Concentric Squares (Green, Yellow, Red) | 24 Stations | 9-9 Pebbles",
                x = w / 2, y = padY * 0.65f, color = Color(0xFFFCD34D), textSize = w * 0.024f, alignCenter = true
            )
        }

        SportFieldType.BUB_BOARD -> {
            drawRect(color = Color(0xFF0F172A), size = size)
            val bs = fh * 0.88f
            val bx = (w - bs) / 2f
            val by = padY + (fh - bs) / 2f
            drawRect(color = Color(0xFF22C55E), topLeft = Offset(bx, by), size = Size(bs, bs / 2f))
            drawRect(color = Color(0xFFEF4444), topLeft = Offset(bx, by + bs / 2f), size = Size(bs, bs / 2f))
            val diamond = Path().apply {
                moveTo(bx + bs / 2f, by + bs * 0.25f)
                lineTo(bx + bs * 0.75f, by + bs / 2f)
                lineTo(bx + bs / 2f, by + bs * 0.75f)
                lineTo(bx + bs * 0.25f, by + bs / 2f)
                close()
            }
            drawPath(diamond, color = Color(0xFFFACC15))
            drawPath(diamond, color = Color.Black, style = Stroke(4.5f))
            val step = bs / 4f
            for (i in 0..4) {
                drawLine(Color.Black, Offset(bx + i * step, by), Offset(bx + i * step, by + bs), strokeWidth = 4f)
                drawLine(Color.Black, Offset(bx, by + i * step), Offset(bx + bs, by + i * step), strokeWidth = 4f)
            }
            for (r in 0..4) {
                for (c in 0..4) {
                    val pt = Offset(bx + c * step, by + r * step)
                    drawCircle(Color.Black, radius = 8.5f, center = pt)
                    drawCircle(Color.White, radius = 8.5f, center = pt, style = Stroke(2f))
                }
            }
            drawCanvasLabel(
                text = if (isAm) "የቡብ ቦርድ፦ 40×40 ሴ.ሜ | 16 ካሬዎችና የመሀል አልማዝ | 25 ጣቢያዎች | 12-12 ጠጠሮች"
                else "Bub Board: 40×40cm | 16 Grid Squares & Central Diamond | 25 Stations | 12-12 Pebbles",
                x = w / 2, y = padY * 0.65f, color = Color(0xFFFCD34D), textSize = w * 0.024f, alignCenter = true
            )
        }

        SportFieldType.FERES_GUGS_FIELD -> {
            drawRect(color = Color(0xFF17310F), size = size)
            drawRect(color = Color.White, topLeft = Offset(padX, padY), size = Size(fw, fh), style = Stroke(3.5f))
            val startW = fw * 0.16f
            val attackW = fw * 0.24f
            drawRect(color = Color(0x44F59E0B), topLeft = Offset(padX, padY + fh * 0.25f), size = Size(startW, fh * 0.5f))
            drawLine(color = Color(0xFFEF4444), start = Offset(padX, padY), end = Offset(padX, padY + fh), strokeWidth = 6f)
            drawLine(
                color = Color(0xFF38BDF8),
                start = Offset(padX + startW, padY),
                end = Offset(padX + startW, padY + fh),
                strokeWidth = 4f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
            )
            drawRect(color = Color(0x44EA580C), topLeft = Offset(w - padX - attackW, padY), size = Size(attackW, fh))
            drawLine(color = Color(0xFFEA580C), start = Offset(w - padX - attackW, padY), end = Offset(w - padX - attackW, padY + fh), strokeWidth = 4f)
            drawCanvasLabel(
                text = if (isAm) "የፈረስ ጉግስ ሜዳ፦ 400-600×50-60 ሜትር | መነሻ 20 ሜትር | መጋለቢያ 280-480 ሜትር | ማጥቂያ 100 ሜትር"
                else "Feres Gugs Field: 400-600×50-60m | Start 20m | Galloping 280-480m | Attack Zone 100m",
                x = w / 2, y = padY * 0.68f, color = Color(0xFFFCD34D), textSize = w * 0.023f, alignCenter = true
            )
        }

        SportFieldType.FERES_SHERT_TRACK -> {
            drawRect(color = Color(0xFF1E3F18), size = size)
            drawRect(color = Color(0xFF78350F), topLeft = Offset(padX, padY), size = Size(fw, fh))
            drawRect(color = Color.White, topLeft = Offset(padX, padY), size = Size(fw, fh), style = Stroke(3.5f))
            val laneH = fh / 6f
            val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f), 0f)
            for (i in 1..5) {
                drawLine(Color.White, Offset(padX, padY + i * laneH), Offset(padX + fw, padY + i * laneH), strokeWidth = 2f, pathEffect = dash)
            }
            drawLine(Color.White, Offset(padX + fw * 0.1f, padY), Offset(padX + fw * 0.1f, padY + fh), strokeWidth = 6f)
            drawLine(Color(0xFFEF4444), Offset(w - padX - fw * 0.1f, padY), Offset(w - padX - fw * 0.1f, padY + fh), strokeWidth = 6f)
            drawCanvasLabel(
                text = if (isAm) "የፈረስ ሽርጥ ባለ 6 መም ትራክ፦ ርዝመት 400-600 ሜትር × ወርድ 48-60 ሜትር (በእያንዳንዱ መም 8-10 ሜትር)"
                else "Feres Shert 6-Lane Track: Length 400-600m × Width 48-60m (8-10m per Lane)",
                x = w / 2, y = padY * 0.68f, color = Color(0xFFFCD34D), textSize = w * 0.023f, alignCenter = true
            )
        }

        SportFieldType.HURBE_5ZONE_PITCH -> {
            drawRect(color = Color(0xFF0F172A), size = size)
            val weights = listOf(20f / 70f, 15f / 70f, 15f / 70f, 15f / 70f, 5f / 70f)
            val colors = listOf(
                Color(0x44F59E0B),
                Color(0x33EF4444),
                Color(0x44EF4444),
                Color(0x55EF4444),
                Color(0x5510B981)
            )
            var curX = padX
            for (i in weights.indices) {
                val zw = fw * weights[i]
                drawRect(color = colors[i], topLeft = Offset(curX, padY), size = Size(zw, fh))
                drawRect(color = Color.White, topLeft = Offset(curX, padY), size = Size(zw, fh), style = Stroke(2.5f))
                curX += zw
            }
            drawCanvasLabel(
                text = if (isAm) "የሁርቤ 5 ቀጠና ሜዳ፦ 70×50 ሜትር (አጥቂ 20 ሜትር + 3 መከላከያ 15-15-15 ሜትር + ነፃ 5 ሜትር)"
                else "Hurbe 5-Zone Pitch: 70m×50m (Attacker 20m + 3 Defense Zones 15m each + Free Zone 5m)",
                x = w / 2, y = padY * 0.68f, color = Color(0xFFFCD34D), textSize = w * 0.023f, alignCenter = true
            )
        }

        SportFieldType.QEST_ARCHERY_RANGE -> {
            drawRect(color = Color(0xFF1E3F18), size = size)
            drawRect(color = Color.White, topLeft = Offset(padX, padY), size = Size(fw, fh), style = Stroke(3f))
            val waitX = padX + fw * 0.08f
            val menX = padX + fw * 0.22f
            val womenX = padX + fw * 0.36f
            drawLine(Color(0xFFFCD34D), Offset(waitX, padY), Offset(waitX, padY + fh), strokeWidth = 3f)
            drawLine(Color.White, Offset(menX, padY), Offset(menX, padY + fh), strokeWidth = 5f)
            drawLine(Color(0xFF38BDF8), Offset(womenX, padY), Offset(womenX, padY + fh), strokeWidth = 4f)
            // 45 degree boundary rays
            drawLine(Color(0xFFEF4444), Offset(menX, h / 2), Offset(padX + fw, padY), strokeWidth = 3.5f)
            drawLine(Color(0xFFEF4444), Offset(menX, h / 2), Offset(padX + fw, padY + fh), strokeWidth = 3.5f)
            // 5-Color Target (Ø 62cm)
            val tx = padX + fw * 0.82f
            val ty = h / 2
            val maxR = fh * 0.28f
            val ringCols = listOf(Color(0xFF111827), Color(0xFF2563EB), Color(0xFFDC2626), Color(0xFFF8FAFC), Color(0xFF16A34A))
            for (i in 0..4) {
                val r = maxR * ((5 - i) / 5f)
                drawCircle(color = ringCols[i], radius = r, center = Offset(tx, ty))
                drawCircle(color = Color.White, radius = r, center = Offset(tx, ty), style = Stroke(2f))
            }
            drawCanvasLabel(
                text = if (isAm) "የቀስት ሜዳና ባለ 5 ቀለበት ኢላማ (62 ሴ.ሜ)፦ ወንዶች 15-20 ሜትር | ሴቶች 13-15 ሜትር | 45° ጨረር"
                else "Qest Archery Range & 5-Ring Target (Ø 62cm): Men 15-20m | Women 13-15m | 45° Rays",
                x = w / 2, y = padY * 0.68f, color = Color(0xFFFCD34D), textSize = w * 0.023f, alignCenter = true
            )
        }

        SportFieldType.GOVERNANCE_STRUCTURE, SportFieldType.FESTIVAL_TRAINING_BOARD -> {
            drawRect(color = Color(0xFF0F172A), size = size)
            val cols = listOf(Color(0xFF10B981), Color(0xFFF59E0B), Color(0xFFEF4444))
            val boxW = fw * 0.29f
            val boxH = fh * 0.52f
            for (i in 0..2) {
                val bx = padX + i * (boxW + fw * 0.065f)
                val by = padY + fh * 0.16f
                drawRoundRect(color = Color(0xFF1E293B), topLeft = Offset(bx, by), size = Size(boxW, boxH), cornerRadius = CornerRadius(16f, 16f))
                drawRoundRect(color = cols[i], topLeft = Offset(bx, by), size = Size(boxW, boxH), cornerRadius = CornerRadius(16f, 16f), style = Stroke(4f))
            }
            drawCanvasLabel(
                text = if (isAm) "የኢትዮጵያ ባህል ስፖርቶች ፌዴሬሽን የዳኝነት፣ የ4 ደረጃ ቅጣት እና የይግባኝ አወቃቀር"
                else "Ethiopian Cultural Sports Federation Officiating, 4-Tier Penalty & Appeal Structure",
                x = w / 2, y = padY * 0.68f, color = Color(0xFFFCD34D), textSize = w * 0.024f, alignCenter = true
            )
        }
    }
}
