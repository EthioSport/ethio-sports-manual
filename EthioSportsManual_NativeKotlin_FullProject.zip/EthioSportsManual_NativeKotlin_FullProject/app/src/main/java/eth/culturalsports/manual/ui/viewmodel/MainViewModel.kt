package eth.culturalsports.manual.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModelProvider
import eth.culturalsports.manual.data.local.ManualDatabase
import eth.culturalsports.manual.data.repository.ManualRepositoryImpl

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import eth.culturalsports.manual.data.local.BookmarkDao
import eth.culturalsports.manual.data.local.BookmarkEntity
import eth.culturalsports.manual.data.local.OfficialNoteDao
import eth.culturalsports.manual.data.local.OfficialNoteEntity
import eth.culturalsports.manual.data.local.QuizScoreDao
import eth.culturalsports.manual.data.local.QuizScoreEntity
import eth.culturalsports.manual.data.preferences.UserPreferencesRepository
import eth.culturalsports.manual.data.preferences.UserPreferencesState
import eth.culturalsports.manual.domain.model.Chapter
import eth.culturalsports.manual.domain.model.QuizQuestion
import eth.culturalsports.manual.domain.model.SearchMatchResult
import eth.culturalsports.manual.domain.model.SportFieldType
import eth.culturalsports.manual.domain.model.TacticalPebble
import eth.culturalsports.manual.domain.model.TacticalStroke
import eth.culturalsports.manual.domain.model.TacticalTool
import eth.culturalsports.manual.domain.repository.ManualRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(FlowPreview::class)
class MainViewModel(
    private val manualRepository: ManualRepository,
    private val prefsRepository: UserPreferencesRepository,
    private val bookmarkDao: BookmarkDao,
    private val quizScoreDao: QuizScoreDao,
    private val officialNoteDao: OfficialNoteDao
) : ViewModel() {

    val userPrefs: StateFlow<UserPreferencesState> = prefsRepository.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferencesState())

    val bookmarks: StateFlow<List<BookmarkEntity>> = bookmarkDao.observeBookmarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentQuizScores: StateFlow<List<QuizScoreEntity>> = quizScoreDao.observeRecentScores()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val officialNotes: StateFlow<List<OfficialNoteEntity>> = officialNoteDao.observeNotes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedCategoryIndex = MutableStateFlow(0)
    val selectedCategoryIndex: StateFlow<Int> = _selectedCategoryIndex.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedQuizCategoryIndex = MutableStateFlow(0)
    val selectedQuizCategoryIndex: StateFlow<Int> = _selectedQuizCategoryIndex.asStateFlow()

    private val _currentQuizIndex = MutableStateFlow(0)
    val currentQuizIndex: StateFlow<Int> = _currentQuizIndex.asStateFlow()

    private val _quizAnswersMap = MutableStateFlow<Map<Int, Int>>(emptyMap())
    val quizAnswersMap: StateFlow<Map<Int, Int>> = _quizAnswersMap.asStateFlow()

    private val _selectedFieldType = MutableStateFlow(SportFieldType.GENA_PITCH)
    val selectedFieldType: StateFlow<SportFieldType> = _selectedFieldType.asStateFlow()

    private val _tacticalTool = MutableStateFlow(TacticalTool.PAN_ZOOM)
    val tacticalTool: StateFlow<TacticalTool> = _tacticalTool.asStateFlow()

    private val _tacticalColor = MutableStateFlow(Color(0xFFFBBF24))
    val tacticalColor: StateFlow<Color> = _tacticalColor.asStateFlow()

    private val _isDashedStroke = MutableStateFlow(false)
    val isDashedStroke: StateFlow<Boolean> = _isDashedStroke.asStateFlow()

    private val _strokes = MutableStateFlow<List<TacticalStroke>>(emptyList())
    val strokes: StateFlow<List<TacticalStroke>> = _strokes.asStateFlow()

    private val _redoStrokes = MutableStateFlow<List<TacticalStroke>>(emptyList())

    private val _pebbles = MutableStateFlow<List<TacticalPebble>>(emptyList())
    val pebbles: StateFlow<List<TacticalPebble>> = _pebbles.asStateFlow()

    val categories: StateFlow<List<String>> = userPrefs
        .combine(_selectedCategoryIndex) { prefs, _ ->
            manualRepository.getCategories(prefs.languageCode)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allChapters: StateFlow<List<Chapter>> = userPrefs
        .combine(_selectedCategoryIndex) { prefs, _ ->
            manualRepository.getChapters(prefs.languageCode)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredChapters: StateFlow<List<Chapter>> = combine(
        allChapters,
        categories,
        _selectedCategoryIndex
    ) { chaps, cats, catIdx ->
        if (catIdx <= 0 || catIdx >= cats.size) {
            chaps
        } else {
            val selectedCatName = cats[catIdx]
            chaps.filter { it.categoryName == selectedCatName }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val debouncedSearchResults: StateFlow<List<SearchMatchResult>> = combine(
        allChapters,
        _searchQuery.debounce(300L)
    ) { chaps, query ->
        val q = query.trim()
        if (q.isEmpty()) {
            emptyList()
        } else {
            val matches = mutableListOf<SearchMatchResult>()
            for (chap in chaps) {
                for (sec in chap.sections) {
                    if (
                        chap.title.contains(q, ignoreCase = true) ||
                        sec.titleText.contains(q, ignoreCase = true) ||
                        sec.bodyText.contains(q, ignoreCase = true)
                    ) {
                        matches.add(
                            SearchMatchResult(
                                chapterId = chap.id,
                                chapterTitle = chap.title,
                                categoryName = chap.categoryName,
                                sectionIndex = sec.index,
                                sectionTitle = sec.titleText,
                                sectionBody = sec.bodyText,
                                iconRes = chap.iconRes
                            )
                        )
                    }
                }
            }
            matches
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredQuizzes: StateFlow<List<QuizQuestion>> = combine(
        userPrefs,
        categories,
        _selectedQuizCategoryIndex
    ) { prefs, cats, catIdx ->
        val allQ = manualRepository.getQuizzes(prefs.languageCode)
        if (catIdx <= 0 || catIdx >= cats.size) {
            allQ
        } else {
            val selectedCat = cats[catIdx]
            allQ.filter { it.category == selectedCat }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectCategory(index: Int) {
        _selectedCategoryIndex.value = index
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectQuizCategory(index: Int) {
        _selectedQuizCategoryIndex.value = index
        _currentQuizIndex.value = 0
        _quizAnswersMap.value = emptyMap()
    }

    fun answerQuizQuestion(questionId: Int, optionIndex: Int) {
        if (_quizAnswersMap.value.containsKey(questionId)) return
        _quizAnswersMap.value = _quizAnswersMap.value + (questionId to optionIndex)
    }

    fun nextQuizQuestion(totalCount: Int) {
        if (_currentQuizIndex.value + 1 < totalCount) {
            _currentQuizIndex.value += 1
        }
    }

    fun prevQuizQuestion() {
        if (_currentQuizIndex.value > 0) {
            _currentQuizIndex.value -= 1
        }
    }

    fun resetQuizSession(saveScoreCategory: String, score: Int, total: Int) {
        viewModelScope.launch {
            if (total > 0 && _quizAnswersMap.value.isNotEmpty()) {
                quizScoreDao.insertScore(
                    QuizScoreEntity(
                        category = saveScoreCategory,
                        score = score,
                        totalQuestions = total
                    )
                )
            }
            _currentQuizIndex.value = 0
            _quizAnswersMap.value = emptyMap()
        }
    }

    fun toggleLanguage() {
        viewModelScope.launch {
            val nextLang = if (userPrefs.value.languageCode == "am") "en" else "am"
            prefsRepository.setLanguage(nextLang)
        }
    }

    fun setLanguage(langCode: String) {
        viewModelScope.launch {
            prefsRepository.setLanguage(langCode)
        }
    }

    fun toggleDarkMode() {
        viewModelScope.launch {
            prefsRepository.setDarkMode(!userPrefs.value.isDarkMode)
        }
    }

    fun toggleDynamicColors() {
        viewModelScope.launch {
            prefsRepository.setDynamicColors(!userPrefs.value.useDynamicColors)
        }
    }

    fun updateFontScale(scale: Float) {
        viewModelScope.launch {
            prefsRepository.setFontScale(scale)
        }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            prefsRepository.setOnboardingCompleted(true)
        }
    }

    fun acceptPrivacyPolicy() {
        viewModelScope.launch {
            prefsRepository.setPrivacyAccepted(true)
        }
    }

    fun toggleBookmark(chapterId: Int, sectionIndex: Int = 0) {
        viewModelScope.launch {
            val exists = bookmarks.value.any { it.chapterId == chapterId }
            if (exists) {
                bookmarkDao.removeBookmark(chapterId)
            } else {
                bookmarkDao.insertBookmark(BookmarkEntity(chapterId = chapterId, sectionIndex = sectionIndex))
            }
        }
    }

    fun saveLastRead(chapterId: Int, sectionIndex: Int = 0) {
        viewModelScope.launch {
            prefsRepository.saveReadingPosition(chapterId, sectionIndex)
        }
    }

    fun selectFieldType(fieldType: SportFieldType) {
        _selectedFieldType.value = fieldType
        clearTacticalBoard()
    }

    fun setTacticalTool(tool: TacticalTool) {
        _tacticalTool.value = tool
    }

    fun setTacticalColor(color: Color) {
        _tacticalColor.value = color
    }

    fun toggleDashedStroke() {
        _isDashedStroke.value = !_isDashedStroke.value
    }

    fun addTacticalStroke(stroke: TacticalStroke) {
        _strokes.value = _strokes.value + stroke
        _redoStrokes.value = emptyList()
    }

    fun addTacticalPebble(pebble: TacticalPebble) {
        _pebbles.value = _pebbles.value + pebble
    }

    fun undoTactical() {
        if (_strokes.value.isNotEmpty()) {
            val last = _strokes.value.last()
            _strokes.value = _strokes.value.dropLast(1)
            _redoStrokes.value = _redoStrokes.value + last
        } else if (_pebbles.value.isNotEmpty()) {
            _pebbles.value = _pebbles.value.dropLast(1)
        }
    }

    fun redoTactical() {
        if (_redoStrokes.value.isNotEmpty()) {
            val last = _redoStrokes.value.last()
            _redoStrokes.value = _redoStrokes.value.dropLast(1)
            _strokes.value = _strokes.value + last
        }
    }

    fun clearTacticalBoard() {
        _strokes.value = emptyList()
        _redoStrokes.value = emptyList()
        _pebbles.value = emptyList()
    }

    fun addOfficialNote(title: String, content: String) {
        if (content.isBlank()) return
        viewModelScope.launch {
            officialNoteDao.insertNote(
                OfficialNoteEntity(
                    title = title.ifBlank { "Official Inspection Note" },
                    encryptedContent = content.trim()
                )
            )
        }
    }

    fun deleteOfficialNote(note: OfficialNoteEntity) {
        viewModelScope.launch {
            officialNoteDao.deleteNote(note)
        }
    }

    companion object {
        fun provideFactory(context: Context): ViewModelProvider.Factory {
            val appCtx = context.applicationContext
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = ManualDatabase.getInstance(appCtx)
                    return MainViewModel(
                        manualRepository = ManualRepositoryImpl(appCtx),
                        prefsRepository = UserPreferencesRepository(appCtx),
                        bookmarkDao = db.bookmarkDao(),
                        quizScoreDao = db.quizScoreDao(),
                        officialNoteDao = db.officialNoteDao()
                    ) as T
                }
            }
        }
    }
}
