package eth.culturalsports.manual.data.repository

import android.content.Context
import android.content.res.Configuration
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import eth.culturalsports.manual.R
import eth.culturalsports.manual.domain.model.Chapter
import eth.culturalsports.manual.domain.model.CompetitionFormTable
import eth.culturalsports.manual.domain.model.QuizQuestion
import eth.culturalsports.manual.domain.model.RuleSection
import eth.culturalsports.manual.domain.model.SportFieldType
import eth.culturalsports.manual.domain.model.SportPhotoItem
import eth.culturalsports.manual.domain.repository.ManualRepository
import java.util.Locale

private data class ChapterHeaderSpec(
    val id: Int,
    @DrawableRes val iconRes: Int,
    @StringRes val catRes: Int,
    @StringRes val titleRes: Int,
    @StringRes val subRes: Int
)

private data class FormResSpec(
    @StringRes val titleRes: Int,
    @StringRes val metaRes: Int,
    @StringRes val headersRes: Int,
    @StringRes val rowsRes: Int,
    @StringRes val footerRes: Int
)

private data class QuizResSpec(
    val id: Int,
    @StringRes val catRes: Int,
    @StringRes val qRes: Int,
    @StringRes val opt0Res: Int,
    @StringRes val opt1Res: Int,
    @StringRes val opt2Res: Int,
    @StringRes val opt3Res: Int,
    val ansIndex: Int,
    @StringRes val explRes: Int
)

class ManualRepositoryImpl(private val appContext: Context) : ManualRepository {

    private fun localizedContext(languageCode: String): Context {
        val locale = Locale(languageCode)
        val config = Configuration(appContext.resources.configuration)
        config.setLocale(locale)
        return appContext.createConfigurationContext(config)
    }

    private val categoryResIds = listOf(
        R.string.cat_name_0, R.string.cat_name_1, R.string.cat_name_2, R.string.cat_name_3,
        R.string.cat_name_4, R.string.cat_name_5, R.string.cat_name_6, R.string.cat_name_7,
        R.string.cat_name_8, R.string.cat_name_9, R.string.cat_name_10, R.string.cat_name_11,
        R.string.cat_name_12, R.string.cat_name_13
    )

    private val chapterHeaders = listOf(
        ChapterHeaderSpec(1, R.drawable.ic_sport_1, R.string.chap_1_cat, R.string.chap_1_title, R.string.chap_1_sub),
        ChapterHeaderSpec(2, R.drawable.ic_sport_2, R.string.chap_2_cat, R.string.chap_2_title, R.string.chap_2_sub),
        ChapterHeaderSpec(3, R.drawable.ic_sport_3, R.string.chap_3_cat, R.string.chap_3_title, R.string.chap_3_sub),
        ChapterHeaderSpec(4, R.drawable.ic_sport_4, R.string.chap_4_cat, R.string.chap_4_title, R.string.chap_4_sub),
        ChapterHeaderSpec(5, R.drawable.ic_sport_5, R.string.chap_5_cat, R.string.chap_5_title, R.string.chap_5_sub),
        ChapterHeaderSpec(6, R.drawable.ic_sport_6, R.string.chap_6_cat, R.string.chap_6_title, R.string.chap_6_sub),
        ChapterHeaderSpec(7, R.drawable.ic_sport_7, R.string.chap_7_cat, R.string.chap_7_title, R.string.chap_7_sub),
        ChapterHeaderSpec(8, R.drawable.ic_sport_8, R.string.chap_8_cat, R.string.chap_8_title, R.string.chap_8_sub),
        ChapterHeaderSpec(9, R.drawable.ic_sport_9, R.string.chap_9_cat, R.string.chap_9_title, R.string.chap_9_sub),
        ChapterHeaderSpec(10, R.drawable.ic_sport_10, R.string.chap_10_cat, R.string.chap_10_title, R.string.chap_10_sub),
        ChapterHeaderSpec(11, R.drawable.ic_sport_11, R.string.chap_11_cat, R.string.chap_11_title, R.string.chap_11_sub),
        ChapterHeaderSpec(12, R.drawable.ic_sport_12, R.string.chap_12_cat, R.string.chap_12_title, R.string.chap_12_sub),
        ChapterHeaderSpec(13, R.drawable.ic_sport_13, R.string.chap_13_cat, R.string.chap_13_title, R.string.chap_13_sub)
    )

    private val chapterSectionSpecs: Map<Int, List<Pair<Int, Int>>> = mapOf(
        1 to listOf(Pair(R.string.chap_1_sec_0_title, R.string.chap_1_sec_0_body), Pair(R.string.chap_1_sec_1_title, R.string.chap_1_sec_1_body), Pair(R.string.chap_1_sec_2_title, R.string.chap_1_sec_2_body), Pair(R.string.chap_1_sec_3_title, R.string.chap_1_sec_3_body), Pair(R.string.chap_1_sec_4_title, R.string.chap_1_sec_4_body), Pair(R.string.chap_1_sec_5_title, R.string.chap_1_sec_5_body), Pair(R.string.chap_1_sec_6_title, R.string.chap_1_sec_6_body), Pair(R.string.chap_1_sec_7_title, R.string.chap_1_sec_7_body), Pair(R.string.chap_1_sec_8_title, R.string.chap_1_sec_8_body), Pair(R.string.chap_1_sec_9_title, R.string.chap_1_sec_9_body), Pair(R.string.chap_1_sec_10_title, R.string.chap_1_sec_10_body), Pair(R.string.chap_1_sec_11_title, R.string.chap_1_sec_11_body), Pair(R.string.chap_1_sec_12_title, R.string.chap_1_sec_12_body), Pair(R.string.chap_1_sec_13_title, R.string.chap_1_sec_13_body)),
        2 to listOf(Pair(R.string.chap_2_sec_0_title, R.string.chap_2_sec_0_body), Pair(R.string.chap_2_sec_1_title, R.string.chap_2_sec_1_body), Pair(R.string.chap_2_sec_2_title, R.string.chap_2_sec_2_body), Pair(R.string.chap_2_sec_3_title, R.string.chap_2_sec_3_body), Pair(R.string.chap_2_sec_4_title, R.string.chap_2_sec_4_body), Pair(R.string.chap_2_sec_5_title, R.string.chap_2_sec_5_body), Pair(R.string.chap_2_sec_6_title, R.string.chap_2_sec_6_body), Pair(R.string.chap_2_sec_7_title, R.string.chap_2_sec_7_body), Pair(R.string.chap_2_sec_8_title, R.string.chap_2_sec_8_body), Pair(R.string.chap_2_sec_9_title, R.string.chap_2_sec_9_body), Pair(R.string.chap_2_sec_10_title, R.string.chap_2_sec_10_body), Pair(R.string.chap_2_sec_11_title, R.string.chap_2_sec_11_body), Pair(R.string.chap_2_sec_12_title, R.string.chap_2_sec_12_body), Pair(R.string.chap_2_sec_13_title, R.string.chap_2_sec_13_body), Pair(R.string.chap_2_sec_14_title, R.string.chap_2_sec_14_body), Pair(R.string.chap_2_sec_15_title, R.string.chap_2_sec_15_body), Pair(R.string.chap_2_sec_16_title, R.string.chap_2_sec_16_body), Pair(R.string.chap_2_sec_17_title, R.string.chap_2_sec_17_body), Pair(R.string.chap_2_sec_18_title, R.string.chap_2_sec_18_body), Pair(R.string.chap_2_sec_19_title, R.string.chap_2_sec_19_body), Pair(R.string.chap_2_sec_20_title, R.string.chap_2_sec_20_body), Pair(R.string.chap_2_sec_21_title, R.string.chap_2_sec_21_body), Pair(R.string.chap_2_sec_22_title, R.string.chap_2_sec_22_body), Pair(R.string.chap_2_sec_23_title, R.string.chap_2_sec_23_body), Pair(R.string.chap_2_sec_24_title, R.string.chap_2_sec_24_body), Pair(R.string.chap_2_sec_25_title, R.string.chap_2_sec_25_body), Pair(R.string.chap_2_sec_26_title, R.string.chap_2_sec_26_body), Pair(R.string.chap_2_sec_27_title, R.string.chap_2_sec_27_body), Pair(R.string.chap_2_sec_28_title, R.string.chap_2_sec_28_body), Pair(R.string.chap_2_sec_29_title, R.string.chap_2_sec_29_body), Pair(R.string.chap_2_sec_30_title, R.string.chap_2_sec_30_body), Pair(R.string.chap_2_sec_31_title, R.string.chap_2_sec_31_body), Pair(R.string.chap_2_sec_32_title, R.string.chap_2_sec_32_body), Pair(R.string.chap_2_sec_33_title, R.string.chap_2_sec_33_body), Pair(R.string.chap_2_sec_34_title, R.string.chap_2_sec_34_body), Pair(R.string.chap_2_sec_35_title, R.string.chap_2_sec_35_body), Pair(R.string.chap_2_sec_36_title, R.string.chap_2_sec_36_body), Pair(R.string.chap_2_sec_37_title, R.string.chap_2_sec_37_body), Pair(R.string.chap_2_sec_38_title, R.string.chap_2_sec_38_body), Pair(R.string.chap_2_sec_39_title, R.string.chap_2_sec_39_body), Pair(R.string.chap_2_sec_40_title, R.string.chap_2_sec_40_body), Pair(R.string.chap_2_sec_41_title, R.string.chap_2_sec_41_body), Pair(R.string.chap_2_sec_42_title, R.string.chap_2_sec_42_body), Pair(R.string.chap_2_sec_43_title, R.string.chap_2_sec_43_body), Pair(R.string.chap_2_sec_44_title, R.string.chap_2_sec_44_body), Pair(R.string.chap_2_sec_45_title, R.string.chap_2_sec_45_body), Pair(R.string.chap_2_sec_46_title, R.string.chap_2_sec_46_body), Pair(R.string.chap_2_sec_47_title, R.string.chap_2_sec_47_body), Pair(R.string.chap_2_sec_48_title, R.string.chap_2_sec_48_body), Pair(R.string.chap_2_sec_49_title, R.string.chap_2_sec_49_body), Pair(R.string.chap_2_sec_50_title, R.string.chap_2_sec_50_body), Pair(R.string.chap_2_sec_51_title, R.string.chap_2_sec_51_body), Pair(R.string.chap_2_sec_52_title, R.string.chap_2_sec_52_body), Pair(R.string.chap_2_sec_53_title, R.string.chap_2_sec_53_body), Pair(R.string.chap_2_sec_54_title, R.string.chap_2_sec_54_body), Pair(R.string.chap_2_sec_55_title, R.string.chap_2_sec_55_body), Pair(R.string.chap_2_sec_56_title, R.string.chap_2_sec_56_body), Pair(R.string.chap_2_sec_57_title, R.string.chap_2_sec_57_body), Pair(R.string.chap_2_sec_58_title, R.string.chap_2_sec_58_body), Pair(R.string.chap_2_sec_59_title, R.string.chap_2_sec_59_body), Pair(R.string.chap_2_sec_60_title, R.string.chap_2_sec_60_body), Pair(R.string.chap_2_sec_61_title, R.string.chap_2_sec_61_body), Pair(R.string.chap_2_sec_62_title, R.string.chap_2_sec_62_body), Pair(R.string.chap_2_sec_63_title, R.string.chap_2_sec_63_body), Pair(R.string.chap_2_sec_64_title, R.string.chap_2_sec_64_body), Pair(R.string.chap_2_sec_65_title, R.string.chap_2_sec_65_body), Pair(R.string.chap_2_sec_66_title, R.string.chap_2_sec_66_body), Pair(R.string.chap_2_sec_67_title, R.string.chap_2_sec_67_body), Pair(R.string.chap_2_sec_68_title, R.string.chap_2_sec_68_body)),
        3 to listOf(Pair(R.string.chap_3_sec_0_title, R.string.chap_3_sec_0_body), Pair(R.string.chap_3_sec_1_title, R.string.chap_3_sec_1_body), Pair(R.string.chap_3_sec_2_title, R.string.chap_3_sec_2_body), Pair(R.string.chap_3_sec_3_title, R.string.chap_3_sec_3_body), Pair(R.string.chap_3_sec_4_title, R.string.chap_3_sec_4_body), Pair(R.string.chap_3_sec_5_title, R.string.chap_3_sec_5_body), Pair(R.string.chap_3_sec_6_title, R.string.chap_3_sec_6_body), Pair(R.string.chap_3_sec_7_title, R.string.chap_3_sec_7_body), Pair(R.string.chap_3_sec_8_title, R.string.chap_3_sec_8_body), Pair(R.string.chap_3_sec_9_title, R.string.chap_3_sec_9_body), Pair(R.string.chap_3_sec_10_title, R.string.chap_3_sec_10_body), Pair(R.string.chap_3_sec_11_title, R.string.chap_3_sec_11_body), Pair(R.string.chap_3_sec_12_title, R.string.chap_3_sec_12_body), Pair(R.string.chap_3_sec_13_title, R.string.chap_3_sec_13_body), Pair(R.string.chap_3_sec_14_title, R.string.chap_3_sec_14_body), Pair(R.string.chap_3_sec_15_title, R.string.chap_3_sec_15_body), Pair(R.string.chap_3_sec_16_title, R.string.chap_3_sec_16_body), Pair(R.string.chap_3_sec_17_title, R.string.chap_3_sec_17_body), Pair(R.string.chap_3_sec_18_title, R.string.chap_3_sec_18_body), Pair(R.string.chap_3_sec_19_title, R.string.chap_3_sec_19_body), Pair(R.string.chap_3_sec_20_title, R.string.chap_3_sec_20_body), Pair(R.string.chap_3_sec_21_title, R.string.chap_3_sec_21_body), Pair(R.string.chap_3_sec_22_title, R.string.chap_3_sec_22_body), Pair(R.string.chap_3_sec_23_title, R.string.chap_3_sec_23_body), Pair(R.string.chap_3_sec_24_title, R.string.chap_3_sec_24_body), Pair(R.string.chap_3_sec_25_title, R.string.chap_3_sec_25_body), Pair(R.string.chap_3_sec_26_title, R.string.chap_3_sec_26_body), Pair(R.string.chap_3_sec_27_title, R.string.chap_3_sec_27_body), Pair(R.string.chap_3_sec_28_title, R.string.chap_3_sec_28_body), Pair(R.string.chap_3_sec_29_title, R.string.chap_3_sec_29_body), Pair(R.string.chap_3_sec_30_title, R.string.chap_3_sec_30_body), Pair(R.string.chap_3_sec_31_title, R.string.chap_3_sec_31_body), Pair(R.string.chap_3_sec_32_title, R.string.chap_3_sec_32_body), Pair(R.string.chap_3_sec_33_title, R.string.chap_3_sec_33_body), Pair(R.string.chap_3_sec_34_title, R.string.chap_3_sec_34_body), Pair(R.string.chap_3_sec_35_title, R.string.chap_3_sec_35_body)),
        4 to listOf(Pair(R.string.chap_4_sec_0_title, R.string.chap_4_sec_0_body), Pair(R.string.chap_4_sec_1_title, R.string.chap_4_sec_1_body), Pair(R.string.chap_4_sec_2_title, R.string.chap_4_sec_2_body), Pair(R.string.chap_4_sec_3_title, R.string.chap_4_sec_3_body), Pair(R.string.chap_4_sec_4_title, R.string.chap_4_sec_4_body), Pair(R.string.chap_4_sec_5_title, R.string.chap_4_sec_5_body), Pair(R.string.chap_4_sec_6_title, R.string.chap_4_sec_6_body), Pair(R.string.chap_4_sec_7_title, R.string.chap_4_sec_7_body), Pair(R.string.chap_4_sec_8_title, R.string.chap_4_sec_8_body), Pair(R.string.chap_4_sec_9_title, R.string.chap_4_sec_9_body), Pair(R.string.chap_4_sec_10_title, R.string.chap_4_sec_10_body), Pair(R.string.chap_4_sec_11_title, R.string.chap_4_sec_11_body), Pair(R.string.chap_4_sec_12_title, R.string.chap_4_sec_12_body), Pair(R.string.chap_4_sec_13_title, R.string.chap_4_sec_13_body), Pair(R.string.chap_4_sec_14_title, R.string.chap_4_sec_14_body), Pair(R.string.chap_4_sec_15_title, R.string.chap_4_sec_15_body), Pair(R.string.chap_4_sec_16_title, R.string.chap_4_sec_16_body), Pair(R.string.chap_4_sec_17_title, R.string.chap_4_sec_17_body), Pair(R.string.chap_4_sec_18_title, R.string.chap_4_sec_18_body), Pair(R.string.chap_4_sec_19_title, R.string.chap_4_sec_19_body), Pair(R.string.chap_4_sec_20_title, R.string.chap_4_sec_20_body), Pair(R.string.chap_4_sec_21_title, R.string.chap_4_sec_21_body), Pair(R.string.chap_4_sec_22_title, R.string.chap_4_sec_22_body), Pair(R.string.chap_4_sec_23_title, R.string.chap_4_sec_23_body), Pair(R.string.chap_4_sec_24_title, R.string.chap_4_sec_24_body), Pair(R.string.chap_4_sec_25_title, R.string.chap_4_sec_25_body), Pair(R.string.chap_4_sec_26_title, R.string.chap_4_sec_26_body), Pair(R.string.chap_4_sec_27_title, R.string.chap_4_sec_27_body), Pair(R.string.chap_4_sec_28_title, R.string.chap_4_sec_28_body), Pair(R.string.chap_4_sec_29_title, R.string.chap_4_sec_29_body), Pair(R.string.chap_4_sec_30_title, R.string.chap_4_sec_30_body), Pair(R.string.chap_4_sec_31_title, R.string.chap_4_sec_31_body), Pair(R.string.chap_4_sec_32_title, R.string.chap_4_sec_32_body), Pair(R.string.chap_4_sec_33_title, R.string.chap_4_sec_33_body), Pair(R.string.chap_4_sec_34_title, R.string.chap_4_sec_34_body), Pair(R.string.chap_4_sec_35_title, R.string.chap_4_sec_35_body), Pair(R.string.chap_4_sec_36_title, R.string.chap_4_sec_36_body), Pair(R.string.chap_4_sec_37_title, R.string.chap_4_sec_37_body), Pair(R.string.chap_4_sec_38_title, R.string.chap_4_sec_38_body), Pair(R.string.chap_4_sec_39_title, R.string.chap_4_sec_39_body), Pair(R.string.chap_4_sec_40_title, R.string.chap_4_sec_40_body)),
        5 to listOf(Pair(R.string.chap_5_sec_0_title, R.string.chap_5_sec_0_body), Pair(R.string.chap_5_sec_1_title, R.string.chap_5_sec_1_body), Pair(R.string.chap_5_sec_2_title, R.string.chap_5_sec_2_body), Pair(R.string.chap_5_sec_3_title, R.string.chap_5_sec_3_body), Pair(R.string.chap_5_sec_4_title, R.string.chap_5_sec_4_body), Pair(R.string.chap_5_sec_5_title, R.string.chap_5_sec_5_body), Pair(R.string.chap_5_sec_6_title, R.string.chap_5_sec_6_body), Pair(R.string.chap_5_sec_7_title, R.string.chap_5_sec_7_body), Pair(R.string.chap_5_sec_8_title, R.string.chap_5_sec_8_body), Pair(R.string.chap_5_sec_9_title, R.string.chap_5_sec_9_body), Pair(R.string.chap_5_sec_10_title, R.string.chap_5_sec_10_body), Pair(R.string.chap_5_sec_11_title, R.string.chap_5_sec_11_body), Pair(R.string.chap_5_sec_12_title, R.string.chap_5_sec_12_body), Pair(R.string.chap_5_sec_13_title, R.string.chap_5_sec_13_body), Pair(R.string.chap_5_sec_14_title, R.string.chap_5_sec_14_body), Pair(R.string.chap_5_sec_15_title, R.string.chap_5_sec_15_body), Pair(R.string.chap_5_sec_16_title, R.string.chap_5_sec_16_body), Pair(R.string.chap_5_sec_17_title, R.string.chap_5_sec_17_body), Pair(R.string.chap_5_sec_18_title, R.string.chap_5_sec_18_body), Pair(R.string.chap_5_sec_19_title, R.string.chap_5_sec_19_body), Pair(R.string.chap_5_sec_20_title, R.string.chap_5_sec_20_body), Pair(R.string.chap_5_sec_21_title, R.string.chap_5_sec_21_body), Pair(R.string.chap_5_sec_22_title, R.string.chap_5_sec_22_body), Pair(R.string.chap_5_sec_23_title, R.string.chap_5_sec_23_body), Pair(R.string.chap_5_sec_24_title, R.string.chap_5_sec_24_body), Pair(R.string.chap_5_sec_25_title, R.string.chap_5_sec_25_body), Pair(R.string.chap_5_sec_26_title, R.string.chap_5_sec_26_body), Pair(R.string.chap_5_sec_27_title, R.string.chap_5_sec_27_body), Pair(R.string.chap_5_sec_28_title, R.string.chap_5_sec_28_body), Pair(R.string.chap_5_sec_29_title, R.string.chap_5_sec_29_body), Pair(R.string.chap_5_sec_30_title, R.string.chap_5_sec_30_body), Pair(R.string.chap_5_sec_31_title, R.string.chap_5_sec_31_body), Pair(R.string.chap_5_sec_32_title, R.string.chap_5_sec_32_body), Pair(R.string.chap_5_sec_33_title, R.string.chap_5_sec_33_body), Pair(R.string.chap_5_sec_34_title, R.string.chap_5_sec_34_body), Pair(R.string.chap_5_sec_35_title, R.string.chap_5_sec_35_body), Pair(R.string.chap_5_sec_36_title, R.string.chap_5_sec_36_body), Pair(R.string.chap_5_sec_37_title, R.string.chap_5_sec_37_body)),
        6 to listOf(Pair(R.string.chap_6_sec_0_title, R.string.chap_6_sec_0_body), Pair(R.string.chap_6_sec_1_title, R.string.chap_6_sec_1_body), Pair(R.string.chap_6_sec_2_title, R.string.chap_6_sec_2_body), Pair(R.string.chap_6_sec_3_title, R.string.chap_6_sec_3_body), Pair(R.string.chap_6_sec_4_title, R.string.chap_6_sec_4_body), Pair(R.string.chap_6_sec_5_title, R.string.chap_6_sec_5_body), Pair(R.string.chap_6_sec_6_title, R.string.chap_6_sec_6_body), Pair(R.string.chap_6_sec_7_title, R.string.chap_6_sec_7_body), Pair(R.string.chap_6_sec_8_title, R.string.chap_6_sec_8_body), Pair(R.string.chap_6_sec_9_title, R.string.chap_6_sec_9_body), Pair(R.string.chap_6_sec_10_title, R.string.chap_6_sec_10_body), Pair(R.string.chap_6_sec_11_title, R.string.chap_6_sec_11_body), Pair(R.string.chap_6_sec_12_title, R.string.chap_6_sec_12_body), Pair(R.string.chap_6_sec_13_title, R.string.chap_6_sec_13_body), Pair(R.string.chap_6_sec_14_title, R.string.chap_6_sec_14_body), Pair(R.string.chap_6_sec_15_title, R.string.chap_6_sec_15_body), Pair(R.string.chap_6_sec_16_title, R.string.chap_6_sec_16_body), Pair(R.string.chap_6_sec_17_title, R.string.chap_6_sec_17_body), Pair(R.string.chap_6_sec_18_title, R.string.chap_6_sec_18_body), Pair(R.string.chap_6_sec_19_title, R.string.chap_6_sec_19_body), Pair(R.string.chap_6_sec_20_title, R.string.chap_6_sec_20_body), Pair(R.string.chap_6_sec_21_title, R.string.chap_6_sec_21_body), Pair(R.string.chap_6_sec_22_title, R.string.chap_6_sec_22_body), Pair(R.string.chap_6_sec_23_title, R.string.chap_6_sec_23_body), Pair(R.string.chap_6_sec_24_title, R.string.chap_6_sec_24_body), Pair(R.string.chap_6_sec_25_title, R.string.chap_6_sec_25_body), Pair(R.string.chap_6_sec_26_title, R.string.chap_6_sec_26_body), Pair(R.string.chap_6_sec_27_title, R.string.chap_6_sec_27_body), Pair(R.string.chap_6_sec_28_title, R.string.chap_6_sec_28_body), Pair(R.string.chap_6_sec_29_title, R.string.chap_6_sec_29_body), Pair(R.string.chap_6_sec_30_title, R.string.chap_6_sec_30_body), Pair(R.string.chap_6_sec_31_title, R.string.chap_6_sec_31_body), Pair(R.string.chap_6_sec_32_title, R.string.chap_6_sec_32_body), Pair(R.string.chap_6_sec_33_title, R.string.chap_6_sec_33_body)),
        7 to listOf(Pair(R.string.chap_7_sec_0_title, R.string.chap_7_sec_0_body), Pair(R.string.chap_7_sec_1_title, R.string.chap_7_sec_1_body), Pair(R.string.chap_7_sec_2_title, R.string.chap_7_sec_2_body), Pair(R.string.chap_7_sec_3_title, R.string.chap_7_sec_3_body), Pair(R.string.chap_7_sec_4_title, R.string.chap_7_sec_4_body), Pair(R.string.chap_7_sec_5_title, R.string.chap_7_sec_5_body), Pair(R.string.chap_7_sec_6_title, R.string.chap_7_sec_6_body), Pair(R.string.chap_7_sec_7_title, R.string.chap_7_sec_7_body), Pair(R.string.chap_7_sec_8_title, R.string.chap_7_sec_8_body), Pair(R.string.chap_7_sec_9_title, R.string.chap_7_sec_9_body), Pair(R.string.chap_7_sec_10_title, R.string.chap_7_sec_10_body), Pair(R.string.chap_7_sec_11_title, R.string.chap_7_sec_11_body), Pair(R.string.chap_7_sec_12_title, R.string.chap_7_sec_12_body), Pair(R.string.chap_7_sec_13_title, R.string.chap_7_sec_13_body), Pair(R.string.chap_7_sec_14_title, R.string.chap_7_sec_14_body), Pair(R.string.chap_7_sec_15_title, R.string.chap_7_sec_15_body), Pair(R.string.chap_7_sec_16_title, R.string.chap_7_sec_16_body), Pair(R.string.chap_7_sec_17_title, R.string.chap_7_sec_17_body), Pair(R.string.chap_7_sec_18_title, R.string.chap_7_sec_18_body), Pair(R.string.chap_7_sec_19_title, R.string.chap_7_sec_19_body), Pair(R.string.chap_7_sec_20_title, R.string.chap_7_sec_20_body), Pair(R.string.chap_7_sec_21_title, R.string.chap_7_sec_21_body), Pair(R.string.chap_7_sec_22_title, R.string.chap_7_sec_22_body), Pair(R.string.chap_7_sec_23_title, R.string.chap_7_sec_23_body), Pair(R.string.chap_7_sec_24_title, R.string.chap_7_sec_24_body), Pair(R.string.chap_7_sec_25_title, R.string.chap_7_sec_25_body), Pair(R.string.chap_7_sec_26_title, R.string.chap_7_sec_26_body), Pair(R.string.chap_7_sec_27_title, R.string.chap_7_sec_27_body), Pair(R.string.chap_7_sec_28_title, R.string.chap_7_sec_28_body), Pair(R.string.chap_7_sec_29_title, R.string.chap_7_sec_29_body), Pair(R.string.chap_7_sec_30_title, R.string.chap_7_sec_30_body), Pair(R.string.chap_7_sec_31_title, R.string.chap_7_sec_31_body), Pair(R.string.chap_7_sec_32_title, R.string.chap_7_sec_32_body), Pair(R.string.chap_7_sec_33_title, R.string.chap_7_sec_33_body), Pair(R.string.chap_7_sec_34_title, R.string.chap_7_sec_34_body), Pair(R.string.chap_7_sec_35_title, R.string.chap_7_sec_35_body), Pair(R.string.chap_7_sec_36_title, R.string.chap_7_sec_36_body), Pair(R.string.chap_7_sec_37_title, R.string.chap_7_sec_37_body), Pair(R.string.chap_7_sec_38_title, R.string.chap_7_sec_38_body), Pair(R.string.chap_7_sec_39_title, R.string.chap_7_sec_39_body), Pair(R.string.chap_7_sec_40_title, R.string.chap_7_sec_40_body), Pair(R.string.chap_7_sec_41_title, R.string.chap_7_sec_41_body), Pair(R.string.chap_7_sec_42_title, R.string.chap_7_sec_42_body), Pair(R.string.chap_7_sec_43_title, R.string.chap_7_sec_43_body), Pair(R.string.chap_7_sec_44_title, R.string.chap_7_sec_44_body), Pair(R.string.chap_7_sec_45_title, R.string.chap_7_sec_45_body), Pair(R.string.chap_7_sec_46_title, R.string.chap_7_sec_46_body), Pair(R.string.chap_7_sec_47_title, R.string.chap_7_sec_47_body), Pair(R.string.chap_7_sec_48_title, R.string.chap_7_sec_48_body)),
        8 to listOf(Pair(R.string.chap_8_sec_0_title, R.string.chap_8_sec_0_body), Pair(R.string.chap_8_sec_1_title, R.string.chap_8_sec_1_body), Pair(R.string.chap_8_sec_2_title, R.string.chap_8_sec_2_body), Pair(R.string.chap_8_sec_3_title, R.string.chap_8_sec_3_body), Pair(R.string.chap_8_sec_4_title, R.string.chap_8_sec_4_body), Pair(R.string.chap_8_sec_5_title, R.string.chap_8_sec_5_body), Pair(R.string.chap_8_sec_6_title, R.string.chap_8_sec_6_body), Pair(R.string.chap_8_sec_7_title, R.string.chap_8_sec_7_body), Pair(R.string.chap_8_sec_8_title, R.string.chap_8_sec_8_body), Pair(R.string.chap_8_sec_9_title, R.string.chap_8_sec_9_body), Pair(R.string.chap_8_sec_10_title, R.string.chap_8_sec_10_body), Pair(R.string.chap_8_sec_11_title, R.string.chap_8_sec_11_body), Pair(R.string.chap_8_sec_12_title, R.string.chap_8_sec_12_body), Pair(R.string.chap_8_sec_13_title, R.string.chap_8_sec_13_body), Pair(R.string.chap_8_sec_14_title, R.string.chap_8_sec_14_body), Pair(R.string.chap_8_sec_15_title, R.string.chap_8_sec_15_body), Pair(R.string.chap_8_sec_16_title, R.string.chap_8_sec_16_body), Pair(R.string.chap_8_sec_17_title, R.string.chap_8_sec_17_body), Pair(R.string.chap_8_sec_18_title, R.string.chap_8_sec_18_body), Pair(R.string.chap_8_sec_19_title, R.string.chap_8_sec_19_body), Pair(R.string.chap_8_sec_20_title, R.string.chap_8_sec_20_body), Pair(R.string.chap_8_sec_21_title, R.string.chap_8_sec_21_body), Pair(R.string.chap_8_sec_22_title, R.string.chap_8_sec_22_body), Pair(R.string.chap_8_sec_23_title, R.string.chap_8_sec_23_body), Pair(R.string.chap_8_sec_24_title, R.string.chap_8_sec_24_body), Pair(R.string.chap_8_sec_25_title, R.string.chap_8_sec_25_body), Pair(R.string.chap_8_sec_26_title, R.string.chap_8_sec_26_body), Pair(R.string.chap_8_sec_27_title, R.string.chap_8_sec_27_body), Pair(R.string.chap_8_sec_28_title, R.string.chap_8_sec_28_body), Pair(R.string.chap_8_sec_29_title, R.string.chap_8_sec_29_body), Pair(R.string.chap_8_sec_30_title, R.string.chap_8_sec_30_body), Pair(R.string.chap_8_sec_31_title, R.string.chap_8_sec_31_body), Pair(R.string.chap_8_sec_32_title, R.string.chap_8_sec_32_body), Pair(R.string.chap_8_sec_33_title, R.string.chap_8_sec_33_body), Pair(R.string.chap_8_sec_34_title, R.string.chap_8_sec_34_body), Pair(R.string.chap_8_sec_35_title, R.string.chap_8_sec_35_body), Pair(R.string.chap_8_sec_36_title, R.string.chap_8_sec_36_body), Pair(R.string.chap_8_sec_37_title, R.string.chap_8_sec_37_body), Pair(R.string.chap_8_sec_38_title, R.string.chap_8_sec_38_body), Pair(R.string.chap_8_sec_39_title, R.string.chap_8_sec_39_body), Pair(R.string.chap_8_sec_40_title, R.string.chap_8_sec_40_body), Pair(R.string.chap_8_sec_41_title, R.string.chap_8_sec_41_body), Pair(R.string.chap_8_sec_42_title, R.string.chap_8_sec_42_body), Pair(R.string.chap_8_sec_43_title, R.string.chap_8_sec_43_body), Pair(R.string.chap_8_sec_44_title, R.string.chap_8_sec_44_body), Pair(R.string.chap_8_sec_45_title, R.string.chap_8_sec_45_body), Pair(R.string.chap_8_sec_46_title, R.string.chap_8_sec_46_body)),
        9 to listOf(Pair(R.string.chap_9_sec_0_title, R.string.chap_9_sec_0_body), Pair(R.string.chap_9_sec_1_title, R.string.chap_9_sec_1_body), Pair(R.string.chap_9_sec_2_title, R.string.chap_9_sec_2_body), Pair(R.string.chap_9_sec_3_title, R.string.chap_9_sec_3_body), Pair(R.string.chap_9_sec_4_title, R.string.chap_9_sec_4_body), Pair(R.string.chap_9_sec_5_title, R.string.chap_9_sec_5_body), Pair(R.string.chap_9_sec_6_title, R.string.chap_9_sec_6_body), Pair(R.string.chap_9_sec_7_title, R.string.chap_9_sec_7_body), Pair(R.string.chap_9_sec_8_title, R.string.chap_9_sec_8_body), Pair(R.string.chap_9_sec_9_title, R.string.chap_9_sec_9_body), Pair(R.string.chap_9_sec_10_title, R.string.chap_9_sec_10_body), Pair(R.string.chap_9_sec_11_title, R.string.chap_9_sec_11_body), Pair(R.string.chap_9_sec_12_title, R.string.chap_9_sec_12_body), Pair(R.string.chap_9_sec_13_title, R.string.chap_9_sec_13_body), Pair(R.string.chap_9_sec_14_title, R.string.chap_9_sec_14_body), Pair(R.string.chap_9_sec_15_title, R.string.chap_9_sec_15_body), Pair(R.string.chap_9_sec_16_title, R.string.chap_9_sec_16_body), Pair(R.string.chap_9_sec_17_title, R.string.chap_9_sec_17_body), Pair(R.string.chap_9_sec_18_title, R.string.chap_9_sec_18_body), Pair(R.string.chap_9_sec_19_title, R.string.chap_9_sec_19_body), Pair(R.string.chap_9_sec_20_title, R.string.chap_9_sec_20_body), Pair(R.string.chap_9_sec_21_title, R.string.chap_9_sec_21_body), Pair(R.string.chap_9_sec_22_title, R.string.chap_9_sec_22_body), Pair(R.string.chap_9_sec_23_title, R.string.chap_9_sec_23_body), Pair(R.string.chap_9_sec_24_title, R.string.chap_9_sec_24_body), Pair(R.string.chap_9_sec_25_title, R.string.chap_9_sec_25_body), Pair(R.string.chap_9_sec_26_title, R.string.chap_9_sec_26_body), Pair(R.string.chap_9_sec_27_title, R.string.chap_9_sec_27_body), Pair(R.string.chap_9_sec_28_title, R.string.chap_9_sec_28_body), Pair(R.string.chap_9_sec_29_title, R.string.chap_9_sec_29_body), Pair(R.string.chap_9_sec_30_title, R.string.chap_9_sec_30_body), Pair(R.string.chap_9_sec_31_title, R.string.chap_9_sec_31_body), Pair(R.string.chap_9_sec_32_title, R.string.chap_9_sec_32_body), Pair(R.string.chap_9_sec_33_title, R.string.chap_9_sec_33_body), Pair(R.string.chap_9_sec_34_title, R.string.chap_9_sec_34_body), Pair(R.string.chap_9_sec_35_title, R.string.chap_9_sec_35_body), Pair(R.string.chap_9_sec_36_title, R.string.chap_9_sec_36_body), Pair(R.string.chap_9_sec_37_title, R.string.chap_9_sec_37_body), Pair(R.string.chap_9_sec_38_title, R.string.chap_9_sec_38_body), Pair(R.string.chap_9_sec_39_title, R.string.chap_9_sec_39_body), Pair(R.string.chap_9_sec_40_title, R.string.chap_9_sec_40_body), Pair(R.string.chap_9_sec_41_title, R.string.chap_9_sec_41_body), Pair(R.string.chap_9_sec_42_title, R.string.chap_9_sec_42_body), Pair(R.string.chap_9_sec_43_title, R.string.chap_9_sec_43_body), Pair(R.string.chap_9_sec_44_title, R.string.chap_9_sec_44_body), Pair(R.string.chap_9_sec_45_title, R.string.chap_9_sec_45_body), Pair(R.string.chap_9_sec_46_title, R.string.chap_9_sec_46_body), Pair(R.string.chap_9_sec_47_title, R.string.chap_9_sec_47_body), Pair(R.string.chap_9_sec_48_title, R.string.chap_9_sec_48_body), Pair(R.string.chap_9_sec_49_title, R.string.chap_9_sec_49_body)),
        10 to listOf(Pair(R.string.chap_10_sec_0_title, R.string.chap_10_sec_0_body), Pair(R.string.chap_10_sec_1_title, R.string.chap_10_sec_1_body), Pair(R.string.chap_10_sec_2_title, R.string.chap_10_sec_2_body), Pair(R.string.chap_10_sec_3_title, R.string.chap_10_sec_3_body), Pair(R.string.chap_10_sec_4_title, R.string.chap_10_sec_4_body), Pair(R.string.chap_10_sec_5_title, R.string.chap_10_sec_5_body), Pair(R.string.chap_10_sec_6_title, R.string.chap_10_sec_6_body), Pair(R.string.chap_10_sec_7_title, R.string.chap_10_sec_7_body), Pair(R.string.chap_10_sec_8_title, R.string.chap_10_sec_8_body), Pair(R.string.chap_10_sec_9_title, R.string.chap_10_sec_9_body), Pair(R.string.chap_10_sec_10_title, R.string.chap_10_sec_10_body), Pair(R.string.chap_10_sec_11_title, R.string.chap_10_sec_11_body), Pair(R.string.chap_10_sec_12_title, R.string.chap_10_sec_12_body), Pair(R.string.chap_10_sec_13_title, R.string.chap_10_sec_13_body), Pair(R.string.chap_10_sec_14_title, R.string.chap_10_sec_14_body), Pair(R.string.chap_10_sec_15_title, R.string.chap_10_sec_15_body), Pair(R.string.chap_10_sec_16_title, R.string.chap_10_sec_16_body), Pair(R.string.chap_10_sec_17_title, R.string.chap_10_sec_17_body), Pair(R.string.chap_10_sec_18_title, R.string.chap_10_sec_18_body), Pair(R.string.chap_10_sec_19_title, R.string.chap_10_sec_19_body), Pair(R.string.chap_10_sec_20_title, R.string.chap_10_sec_20_body), Pair(R.string.chap_10_sec_21_title, R.string.chap_10_sec_21_body), Pair(R.string.chap_10_sec_22_title, R.string.chap_10_sec_22_body), Pair(R.string.chap_10_sec_23_title, R.string.chap_10_sec_23_body), Pair(R.string.chap_10_sec_24_title, R.string.chap_10_sec_24_body), Pair(R.string.chap_10_sec_25_title, R.string.chap_10_sec_25_body), Pair(R.string.chap_10_sec_26_title, R.string.chap_10_sec_26_body), Pair(R.string.chap_10_sec_27_title, R.string.chap_10_sec_27_body), Pair(R.string.chap_10_sec_28_title, R.string.chap_10_sec_28_body), Pair(R.string.chap_10_sec_29_title, R.string.chap_10_sec_29_body), Pair(R.string.chap_10_sec_30_title, R.string.chap_10_sec_30_body), Pair(R.string.chap_10_sec_31_title, R.string.chap_10_sec_31_body), Pair(R.string.chap_10_sec_32_title, R.string.chap_10_sec_32_body)),
        11 to listOf(Pair(R.string.chap_11_sec_0_title, R.string.chap_11_sec_0_body), Pair(R.string.chap_11_sec_1_title, R.string.chap_11_sec_1_body), Pair(R.string.chap_11_sec_2_title, R.string.chap_11_sec_2_body), Pair(R.string.chap_11_sec_3_title, R.string.chap_11_sec_3_body), Pair(R.string.chap_11_sec_4_title, R.string.chap_11_sec_4_body), Pair(R.string.chap_11_sec_5_title, R.string.chap_11_sec_5_body), Pair(R.string.chap_11_sec_6_title, R.string.chap_11_sec_6_body), Pair(R.string.chap_11_sec_7_title, R.string.chap_11_sec_7_body), Pair(R.string.chap_11_sec_8_title, R.string.chap_11_sec_8_body), Pair(R.string.chap_11_sec_9_title, R.string.chap_11_sec_9_body), Pair(R.string.chap_11_sec_10_title, R.string.chap_11_sec_10_body), Pair(R.string.chap_11_sec_11_title, R.string.chap_11_sec_11_body), Pair(R.string.chap_11_sec_12_title, R.string.chap_11_sec_12_body), Pair(R.string.chap_11_sec_13_title, R.string.chap_11_sec_13_body), Pair(R.string.chap_11_sec_14_title, R.string.chap_11_sec_14_body), Pair(R.string.chap_11_sec_15_title, R.string.chap_11_sec_15_body), Pair(R.string.chap_11_sec_16_title, R.string.chap_11_sec_16_body), Pair(R.string.chap_11_sec_17_title, R.string.chap_11_sec_17_body), Pair(R.string.chap_11_sec_18_title, R.string.chap_11_sec_18_body), Pair(R.string.chap_11_sec_19_title, R.string.chap_11_sec_19_body), Pair(R.string.chap_11_sec_20_title, R.string.chap_11_sec_20_body), Pair(R.string.chap_11_sec_21_title, R.string.chap_11_sec_21_body), Pair(R.string.chap_11_sec_22_title, R.string.chap_11_sec_22_body), Pair(R.string.chap_11_sec_23_title, R.string.chap_11_sec_23_body), Pair(R.string.chap_11_sec_24_title, R.string.chap_11_sec_24_body), Pair(R.string.chap_11_sec_25_title, R.string.chap_11_sec_25_body), Pair(R.string.chap_11_sec_26_title, R.string.chap_11_sec_26_body), Pair(R.string.chap_11_sec_27_title, R.string.chap_11_sec_27_body), Pair(R.string.chap_11_sec_28_title, R.string.chap_11_sec_28_body), Pair(R.string.chap_11_sec_29_title, R.string.chap_11_sec_29_body), Pair(R.string.chap_11_sec_30_title, R.string.chap_11_sec_30_body), Pair(R.string.chap_11_sec_31_title, R.string.chap_11_sec_31_body), Pair(R.string.chap_11_sec_32_title, R.string.chap_11_sec_32_body), Pair(R.string.chap_11_sec_33_title, R.string.chap_11_sec_33_body), Pair(R.string.chap_11_sec_34_title, R.string.chap_11_sec_34_body), Pair(R.string.chap_11_sec_35_title, R.string.chap_11_sec_35_body), Pair(R.string.chap_11_sec_36_title, R.string.chap_11_sec_36_body)),
        12 to listOf(Pair(R.string.chap_12_sec_0_title, R.string.chap_12_sec_0_body), Pair(R.string.chap_12_sec_1_title, R.string.chap_12_sec_1_body), Pair(R.string.chap_12_sec_2_title, R.string.chap_12_sec_2_body), Pair(R.string.chap_12_sec_3_title, R.string.chap_12_sec_3_body), Pair(R.string.chap_12_sec_4_title, R.string.chap_12_sec_4_body), Pair(R.string.chap_12_sec_5_title, R.string.chap_12_sec_5_body), Pair(R.string.chap_12_sec_6_title, R.string.chap_12_sec_6_body), Pair(R.string.chap_12_sec_7_title, R.string.chap_12_sec_7_body), Pair(R.string.chap_12_sec_8_title, R.string.chap_12_sec_8_body), Pair(R.string.chap_12_sec_9_title, R.string.chap_12_sec_9_body), Pair(R.string.chap_12_sec_10_title, R.string.chap_12_sec_10_body), Pair(R.string.chap_12_sec_11_title, R.string.chap_12_sec_11_body), Pair(R.string.chap_12_sec_12_title, R.string.chap_12_sec_12_body), Pair(R.string.chap_12_sec_13_title, R.string.chap_12_sec_13_body), Pair(R.string.chap_12_sec_14_title, R.string.chap_12_sec_14_body), Pair(R.string.chap_12_sec_15_title, R.string.chap_12_sec_15_body), Pair(R.string.chap_12_sec_16_title, R.string.chap_12_sec_16_body), Pair(R.string.chap_12_sec_17_title, R.string.chap_12_sec_17_body), Pair(R.string.chap_12_sec_18_title, R.string.chap_12_sec_18_body), Pair(R.string.chap_12_sec_19_title, R.string.chap_12_sec_19_body), Pair(R.string.chap_12_sec_20_title, R.string.chap_12_sec_20_body), Pair(R.string.chap_12_sec_21_title, R.string.chap_12_sec_21_body), Pair(R.string.chap_12_sec_22_title, R.string.chap_12_sec_22_body), Pair(R.string.chap_12_sec_23_title, R.string.chap_12_sec_23_body), Pair(R.string.chap_12_sec_24_title, R.string.chap_12_sec_24_body), Pair(R.string.chap_12_sec_25_title, R.string.chap_12_sec_25_body), Pair(R.string.chap_12_sec_26_title, R.string.chap_12_sec_26_body), Pair(R.string.chap_12_sec_27_title, R.string.chap_12_sec_27_body), Pair(R.string.chap_12_sec_28_title, R.string.chap_12_sec_28_body), Pair(R.string.chap_12_sec_29_title, R.string.chap_12_sec_29_body), Pair(R.string.chap_12_sec_30_title, R.string.chap_12_sec_30_body), Pair(R.string.chap_12_sec_31_title, R.string.chap_12_sec_31_body), Pair(R.string.chap_12_sec_32_title, R.string.chap_12_sec_32_body), Pair(R.string.chap_12_sec_33_title, R.string.chap_12_sec_33_body), Pair(R.string.chap_12_sec_34_title, R.string.chap_12_sec_34_body), Pair(R.string.chap_12_sec_35_title, R.string.chap_12_sec_35_body), Pair(R.string.chap_12_sec_36_title, R.string.chap_12_sec_36_body), Pair(R.string.chap_12_sec_37_title, R.string.chap_12_sec_37_body), Pair(R.string.chap_12_sec_38_title, R.string.chap_12_sec_38_body), Pair(R.string.chap_12_sec_39_title, R.string.chap_12_sec_39_body), Pair(R.string.chap_12_sec_40_title, R.string.chap_12_sec_40_body), Pair(R.string.chap_12_sec_41_title, R.string.chap_12_sec_41_body), Pair(R.string.chap_12_sec_42_title, R.string.chap_12_sec_42_body), Pair(R.string.chap_12_sec_43_title, R.string.chap_12_sec_43_body), Pair(R.string.chap_12_sec_44_title, R.string.chap_12_sec_44_body), Pair(R.string.chap_12_sec_45_title, R.string.chap_12_sec_45_body), Pair(R.string.chap_12_sec_46_title, R.string.chap_12_sec_46_body), Pair(R.string.chap_12_sec_47_title, R.string.chap_12_sec_47_body), Pair(R.string.chap_12_sec_48_title, R.string.chap_12_sec_48_body), Pair(R.string.chap_12_sec_49_title, R.string.chap_12_sec_49_body)),
        13 to listOf(Pair(R.string.chap_13_sec_0_title, R.string.chap_13_sec_0_body), Pair(R.string.chap_13_sec_1_title, R.string.chap_13_sec_1_body), Pair(R.string.chap_13_sec_2_title, R.string.chap_13_sec_2_body), Pair(R.string.chap_13_sec_3_title, R.string.chap_13_sec_3_body), Pair(R.string.chap_13_sec_4_title, R.string.chap_13_sec_4_body), Pair(R.string.chap_13_sec_5_title, R.string.chap_13_sec_5_body), Pair(R.string.chap_13_sec_6_title, R.string.chap_13_sec_6_body), Pair(R.string.chap_13_sec_7_title, R.string.chap_13_sec_7_body), Pair(R.string.chap_13_sec_8_title, R.string.chap_13_sec_8_body), Pair(R.string.chap_13_sec_9_title, R.string.chap_13_sec_9_body), Pair(R.string.chap_13_sec_10_title, R.string.chap_13_sec_10_body), Pair(R.string.chap_13_sec_11_title, R.string.chap_13_sec_11_body), Pair(R.string.chap_13_sec_12_title, R.string.chap_13_sec_12_body), Pair(R.string.chap_13_sec_13_title, R.string.chap_13_sec_13_body), Pair(R.string.chap_13_sec_14_title, R.string.chap_13_sec_14_body), Pair(R.string.chap_13_sec_15_title, R.string.chap_13_sec_15_body), Pair(R.string.chap_13_sec_16_title, R.string.chap_13_sec_16_body), Pair(R.string.chap_13_sec_17_title, R.string.chap_13_sec_17_body), Pair(R.string.chap_13_sec_18_title, R.string.chap_13_sec_18_body), Pair(R.string.chap_13_sec_19_title, R.string.chap_13_sec_19_body), Pair(R.string.chap_13_sec_20_title, R.string.chap_13_sec_20_body))
    )

    private val chapterFormSpecs: Map<Int, List<FormResSpec>> = mapOf(
        1 to listOf(FormResSpec(R.string.chap_1_form_0_title, R.string.chap_1_form_0_meta, R.string.chap_1_form_0_headers, R.string.chap_1_form_0_rows, R.string.chap_1_form_0_footer)),
        2 to listOf(FormResSpec(R.string.chap_2_form_0_title, R.string.chap_2_form_0_meta, R.string.chap_2_form_0_headers, R.string.chap_2_form_0_rows, R.string.chap_2_form_0_footer), FormResSpec(R.string.chap_2_form_1_title, R.string.chap_2_form_1_meta, R.string.chap_2_form_1_headers, R.string.chap_2_form_1_rows, R.string.chap_2_form_1_footer), FormResSpec(R.string.chap_2_form_2_title, R.string.chap_2_form_2_meta, R.string.chap_2_form_2_headers, R.string.chap_2_form_2_rows, R.string.chap_2_form_2_footer), FormResSpec(R.string.chap_2_form_3_title, R.string.chap_2_form_3_meta, R.string.chap_2_form_3_headers, R.string.chap_2_form_3_rows, R.string.chap_2_form_3_footer)),
        3 to listOf(FormResSpec(R.string.chap_3_form_0_title, R.string.chap_3_form_0_meta, R.string.chap_3_form_0_headers, R.string.chap_3_form_0_rows, R.string.chap_3_form_0_footer), FormResSpec(R.string.chap_3_form_1_title, R.string.chap_3_form_1_meta, R.string.chap_3_form_1_headers, R.string.chap_3_form_1_rows, R.string.chap_3_form_1_footer)),
        4 to listOf(FormResSpec(R.string.chap_4_form_0_title, R.string.chap_4_form_0_meta, R.string.chap_4_form_0_headers, R.string.chap_4_form_0_rows, R.string.chap_4_form_0_footer), FormResSpec(R.string.chap_4_form_1_title, R.string.chap_4_form_1_meta, R.string.chap_4_form_1_headers, R.string.chap_4_form_1_rows, R.string.chap_4_form_1_footer)),
        5 to listOf(FormResSpec(R.string.chap_5_form_0_title, R.string.chap_5_form_0_meta, R.string.chap_5_form_0_headers, R.string.chap_5_form_0_rows, R.string.chap_5_form_0_footer), FormResSpec(R.string.chap_5_form_1_title, R.string.chap_5_form_1_meta, R.string.chap_5_form_1_headers, R.string.chap_5_form_1_rows, R.string.chap_5_form_1_footer)),
        6 to listOf(FormResSpec(R.string.chap_6_form_0_title, R.string.chap_6_form_0_meta, R.string.chap_6_form_0_headers, R.string.chap_6_form_0_rows, R.string.chap_6_form_0_footer)),
        7 to listOf(FormResSpec(R.string.chap_7_form_0_title, R.string.chap_7_form_0_meta, R.string.chap_7_form_0_headers, R.string.chap_7_form_0_rows, R.string.chap_7_form_0_footer)),
        8 to listOf(FormResSpec(R.string.chap_8_form_0_title, R.string.chap_8_form_0_meta, R.string.chap_8_form_0_headers, R.string.chap_8_form_0_rows, R.string.chap_8_form_0_footer), FormResSpec(R.string.chap_8_form_1_title, R.string.chap_8_form_1_meta, R.string.chap_8_form_1_headers, R.string.chap_8_form_1_rows, R.string.chap_8_form_1_footer)),
        9 to listOf(FormResSpec(R.string.chap_9_form_0_title, R.string.chap_9_form_0_meta, R.string.chap_9_form_0_headers, R.string.chap_9_form_0_rows, R.string.chap_9_form_0_footer), FormResSpec(R.string.chap_9_form_1_title, R.string.chap_9_form_1_meta, R.string.chap_9_form_1_headers, R.string.chap_9_form_1_rows, R.string.chap_9_form_1_footer)),
        10 to listOf(FormResSpec(R.string.chap_10_form_0_title, R.string.chap_10_form_0_meta, R.string.chap_10_form_0_headers, R.string.chap_10_form_0_rows, R.string.chap_10_form_0_footer), FormResSpec(R.string.chap_10_form_1_title, R.string.chap_10_form_1_meta, R.string.chap_10_form_1_headers, R.string.chap_10_form_1_rows, R.string.chap_10_form_1_footer)),
        11 to listOf(FormResSpec(R.string.chap_11_form_0_title, R.string.chap_11_form_0_meta, R.string.chap_11_form_0_headers, R.string.chap_11_form_0_rows, R.string.chap_11_form_0_footer), FormResSpec(R.string.chap_11_form_1_title, R.string.chap_11_form_1_meta, R.string.chap_11_form_1_headers, R.string.chap_11_form_1_rows, R.string.chap_11_form_1_footer)),
        12 to listOf(FormResSpec(R.string.chap_12_form_0_title, R.string.chap_12_form_0_meta, R.string.chap_12_form_0_headers, R.string.chap_12_form_0_rows, R.string.chap_12_form_0_footer), FormResSpec(R.string.chap_12_form_1_title, R.string.chap_12_form_1_meta, R.string.chap_12_form_1_headers, R.string.chap_12_form_1_rows, R.string.chap_12_form_1_footer)),
        13 to listOf(FormResSpec(R.string.chap_13_form_0_title, R.string.chap_13_form_0_meta, R.string.chap_13_form_0_headers, R.string.chap_13_form_0_rows, R.string.chap_13_form_0_footer))
    )

    private val quizSpecs: List<QuizResSpec> = listOf(
        QuizResSpec(1, R.string.quiz_1_cat, R.string.quiz_1_q, R.string.quiz_1_opt_0, R.string.quiz_1_opt_1, R.string.quiz_1_opt_2, R.string.quiz_1_opt_3, 0, R.string.quiz_1_expl),
        QuizResSpec(2, R.string.quiz_2_cat, R.string.quiz_2_q, R.string.quiz_2_opt_0, R.string.quiz_2_opt_1, R.string.quiz_2_opt_2, R.string.quiz_2_opt_3, 3, R.string.quiz_2_expl),
        QuizResSpec(3, R.string.quiz_3_cat, R.string.quiz_3_q, R.string.quiz_3_opt_0, R.string.quiz_3_opt_1, R.string.quiz_3_opt_2, R.string.quiz_3_opt_3, 2, R.string.quiz_3_expl),
        QuizResSpec(4, R.string.quiz_4_cat, R.string.quiz_4_q, R.string.quiz_4_opt_0, R.string.quiz_4_opt_1, R.string.quiz_4_opt_2, R.string.quiz_4_opt_3, 1, R.string.quiz_4_expl),
        QuizResSpec(5, R.string.quiz_5_cat, R.string.quiz_5_q, R.string.quiz_5_opt_0, R.string.quiz_5_opt_1, R.string.quiz_5_opt_2, R.string.quiz_5_opt_3, 1, R.string.quiz_5_expl),
        QuizResSpec(6, R.string.quiz_6_cat, R.string.quiz_6_q, R.string.quiz_6_opt_0, R.string.quiz_6_opt_1, R.string.quiz_6_opt_2, R.string.quiz_6_opt_3, 0, R.string.quiz_6_expl),
        QuizResSpec(7, R.string.quiz_7_cat, R.string.quiz_7_q, R.string.quiz_7_opt_0, R.string.quiz_7_opt_1, R.string.quiz_7_opt_2, R.string.quiz_7_opt_3, 3, R.string.quiz_7_expl),
        QuizResSpec(8, R.string.quiz_8_cat, R.string.quiz_8_q, R.string.quiz_8_opt_0, R.string.quiz_8_opt_1, R.string.quiz_8_opt_2, R.string.quiz_8_opt_3, 2, R.string.quiz_8_expl),
        QuizResSpec(9, R.string.quiz_9_cat, R.string.quiz_9_q, R.string.quiz_9_opt_0, R.string.quiz_9_opt_1, R.string.quiz_9_opt_2, R.string.quiz_9_opt_3, 2, R.string.quiz_9_expl),
        QuizResSpec(10, R.string.quiz_10_cat, R.string.quiz_10_q, R.string.quiz_10_opt_0, R.string.quiz_10_opt_1, R.string.quiz_10_opt_2, R.string.quiz_10_opt_3, 1, R.string.quiz_10_expl),
        QuizResSpec(11, R.string.quiz_11_cat, R.string.quiz_11_q, R.string.quiz_11_opt_0, R.string.quiz_11_opt_1, R.string.quiz_11_opt_2, R.string.quiz_11_opt_3, 0, R.string.quiz_11_expl),
        QuizResSpec(12, R.string.quiz_12_cat, R.string.quiz_12_q, R.string.quiz_12_opt_0, R.string.quiz_12_opt_1, R.string.quiz_12_opt_2, R.string.quiz_12_opt_3, 0, R.string.quiz_12_expl),
        QuizResSpec(13, R.string.quiz_13_cat, R.string.quiz_13_q, R.string.quiz_13_opt_0, R.string.quiz_13_opt_1, R.string.quiz_13_opt_2, R.string.quiz_13_opt_3, 1, R.string.quiz_13_expl),
        QuizResSpec(14, R.string.quiz_14_cat, R.string.quiz_14_q, R.string.quiz_14_opt_0, R.string.quiz_14_opt_1, R.string.quiz_14_opt_2, R.string.quiz_14_opt_3, 3, R.string.quiz_14_expl),
        QuizResSpec(15, R.string.quiz_15_cat, R.string.quiz_15_q, R.string.quiz_15_opt_0, R.string.quiz_15_opt_1, R.string.quiz_15_opt_2, R.string.quiz_15_opt_3, 2, R.string.quiz_15_expl),
        QuizResSpec(16, R.string.quiz_16_cat, R.string.quiz_16_q, R.string.quiz_16_opt_0, R.string.quiz_16_opt_1, R.string.quiz_16_opt_2, R.string.quiz_16_opt_3, 1, R.string.quiz_16_expl),
        QuizResSpec(17, R.string.quiz_17_cat, R.string.quiz_17_q, R.string.quiz_17_opt_0, R.string.quiz_17_opt_1, R.string.quiz_17_opt_2, R.string.quiz_17_opt_3, 1, R.string.quiz_17_expl),
        QuizResSpec(18, R.string.quiz_18_cat, R.string.quiz_18_q, R.string.quiz_18_opt_0, R.string.quiz_18_opt_1, R.string.quiz_18_opt_2, R.string.quiz_18_opt_3, 0, R.string.quiz_18_expl),
        QuizResSpec(19, R.string.quiz_19_cat, R.string.quiz_19_q, R.string.quiz_19_opt_0, R.string.quiz_19_opt_1, R.string.quiz_19_opt_2, R.string.quiz_19_opt_3, 3, R.string.quiz_19_expl),
        QuizResSpec(20, R.string.quiz_20_cat, R.string.quiz_20_q, R.string.quiz_20_opt_0, R.string.quiz_20_opt_1, R.string.quiz_20_opt_2, R.string.quiz_20_opt_3, 2, R.string.quiz_20_expl),
        QuizResSpec(21, R.string.quiz_21_cat, R.string.quiz_21_q, R.string.quiz_21_opt_0, R.string.quiz_21_opt_1, R.string.quiz_21_opt_2, R.string.quiz_21_opt_3, 2, R.string.quiz_21_expl),
        QuizResSpec(22, R.string.quiz_22_cat, R.string.quiz_22_q, R.string.quiz_22_opt_0, R.string.quiz_22_opt_1, R.string.quiz_22_opt_2, R.string.quiz_22_opt_3, 1, R.string.quiz_22_expl),
        QuizResSpec(23, R.string.quiz_23_cat, R.string.quiz_23_q, R.string.quiz_23_opt_0, R.string.quiz_23_opt_1, R.string.quiz_23_opt_2, R.string.quiz_23_opt_3, 1, R.string.quiz_23_expl),
        QuizResSpec(24, R.string.quiz_24_cat, R.string.quiz_24_q, R.string.quiz_24_opt_0, R.string.quiz_24_opt_1, R.string.quiz_24_opt_2, R.string.quiz_24_opt_3, 0, R.string.quiz_24_expl),
        QuizResSpec(25, R.string.quiz_25_cat, R.string.quiz_25_q, R.string.quiz_25_opt_0, R.string.quiz_25_opt_1, R.string.quiz_25_opt_2, R.string.quiz_25_opt_3, 0, R.string.quiz_25_expl),
        QuizResSpec(26, R.string.quiz_26_cat, R.string.quiz_26_q, R.string.quiz_26_opt_0, R.string.quiz_26_opt_1, R.string.quiz_26_opt_2, R.string.quiz_26_opt_3, 3, R.string.quiz_26_expl),
        QuizResSpec(27, R.string.quiz_27_cat, R.string.quiz_27_q, R.string.quiz_27_opt_0, R.string.quiz_27_opt_1, R.string.quiz_27_opt_2, R.string.quiz_27_opt_3, 2, R.string.quiz_27_expl),
        QuizResSpec(28, R.string.quiz_28_cat, R.string.quiz_28_q, R.string.quiz_28_opt_0, R.string.quiz_28_opt_1, R.string.quiz_28_opt_2, R.string.quiz_28_opt_3, 1, R.string.quiz_28_expl),
        QuizResSpec(29, R.string.quiz_29_cat, R.string.quiz_29_q, R.string.quiz_29_opt_0, R.string.quiz_29_opt_1, R.string.quiz_29_opt_2, R.string.quiz_29_opt_3, 1, R.string.quiz_29_expl),
        QuizResSpec(30, R.string.quiz_30_cat, R.string.quiz_30_q, R.string.quiz_30_opt_0, R.string.quiz_30_opt_1, R.string.quiz_30_opt_2, R.string.quiz_30_opt_3, 0, R.string.quiz_30_expl),
        QuizResSpec(31, R.string.quiz_31_cat, R.string.quiz_31_q, R.string.quiz_31_opt_0, R.string.quiz_31_opt_1, R.string.quiz_31_opt_2, R.string.quiz_31_opt_3, 3, R.string.quiz_31_expl),
        QuizResSpec(32, R.string.quiz_32_cat, R.string.quiz_32_q, R.string.quiz_32_opt_0, R.string.quiz_32_opt_1, R.string.quiz_32_opt_2, R.string.quiz_32_opt_3, 2, R.string.quiz_32_expl),
        QuizResSpec(33, R.string.quiz_33_cat, R.string.quiz_33_q, R.string.quiz_33_opt_0, R.string.quiz_33_opt_1, R.string.quiz_33_opt_2, R.string.quiz_33_opt_3, 2, R.string.quiz_33_expl),
        QuizResSpec(34, R.string.quiz_34_cat, R.string.quiz_34_q, R.string.quiz_34_opt_0, R.string.quiz_34_opt_1, R.string.quiz_34_opt_2, R.string.quiz_34_opt_3, 3, R.string.quiz_34_expl),
        QuizResSpec(35, R.string.quiz_35_cat, R.string.quiz_35_q, R.string.quiz_35_opt_0, R.string.quiz_35_opt_1, R.string.quiz_35_opt_2, R.string.quiz_35_opt_3, 1, R.string.quiz_35_expl),
        QuizResSpec(36, R.string.quiz_36_cat, R.string.quiz_36_q, R.string.quiz_36_opt_0, R.string.quiz_36_opt_1, R.string.quiz_36_opt_2, R.string.quiz_36_opt_3, 0, R.string.quiz_36_expl),
        QuizResSpec(37, R.string.quiz_37_cat, R.string.quiz_37_q, R.string.quiz_37_opt_0, R.string.quiz_37_opt_1, R.string.quiz_37_opt_2, R.string.quiz_37_opt_3, 0, R.string.quiz_37_expl),
        QuizResSpec(38, R.string.quiz_38_cat, R.string.quiz_38_q, R.string.quiz_38_opt_0, R.string.quiz_38_opt_1, R.string.quiz_38_opt_2, R.string.quiz_38_opt_3, 3, R.string.quiz_38_expl),
        QuizResSpec(39, R.string.quiz_39_cat, R.string.quiz_39_q, R.string.quiz_39_opt_0, R.string.quiz_39_opt_1, R.string.quiz_39_opt_2, R.string.quiz_39_opt_3, 2, R.string.quiz_39_expl),
        QuizResSpec(40, R.string.quiz_40_cat, R.string.quiz_40_q, R.string.quiz_40_opt_0, R.string.quiz_40_opt_1, R.string.quiz_40_opt_2, R.string.quiz_40_opt_3, 1, R.string.quiz_40_expl),
        QuizResSpec(41, R.string.quiz_41_cat, R.string.quiz_41_q, R.string.quiz_41_opt_0, R.string.quiz_41_opt_1, R.string.quiz_41_opt_2, R.string.quiz_41_opt_3, 1, R.string.quiz_41_expl),
        QuizResSpec(42, R.string.quiz_42_cat, R.string.quiz_42_q, R.string.quiz_42_opt_0, R.string.quiz_42_opt_1, R.string.quiz_42_opt_2, R.string.quiz_42_opt_3, 0, R.string.quiz_42_expl),
        QuizResSpec(43, R.string.quiz_43_cat, R.string.quiz_43_q, R.string.quiz_43_opt_0, R.string.quiz_43_opt_1, R.string.quiz_43_opt_2, R.string.quiz_43_opt_3, 3, R.string.quiz_43_expl),
        QuizResSpec(44, R.string.quiz_44_cat, R.string.quiz_44_q, R.string.quiz_44_opt_0, R.string.quiz_44_opt_1, R.string.quiz_44_opt_2, R.string.quiz_44_opt_3, 2, R.string.quiz_44_expl),
        QuizResSpec(45, R.string.quiz_45_cat, R.string.quiz_45_q, R.string.quiz_45_opt_0, R.string.quiz_45_opt_1, R.string.quiz_45_opt_2, R.string.quiz_45_opt_3, 3, R.string.quiz_45_expl),
        QuizResSpec(46, R.string.quiz_46_cat, R.string.quiz_46_q, R.string.quiz_46_opt_0, R.string.quiz_46_opt_1, R.string.quiz_46_opt_2, R.string.quiz_46_opt_3, 2, R.string.quiz_46_expl),
        QuizResSpec(47, R.string.quiz_47_cat, R.string.quiz_47_q, R.string.quiz_47_opt_0, R.string.quiz_47_opt_1, R.string.quiz_47_opt_2, R.string.quiz_47_opt_3, 1, R.string.quiz_47_expl),
        QuizResSpec(48, R.string.quiz_48_cat, R.string.quiz_48_q, R.string.quiz_48_opt_0, R.string.quiz_48_opt_1, R.string.quiz_48_opt_2, R.string.quiz_48_opt_3, 0, R.string.quiz_48_expl),
        QuizResSpec(49, R.string.quiz_49_cat, R.string.quiz_49_q, R.string.quiz_49_opt_0, R.string.quiz_49_opt_1, R.string.quiz_49_opt_2, R.string.quiz_49_opt_3, 0, R.string.quiz_49_expl),
        QuizResSpec(50, R.string.quiz_50_cat, R.string.quiz_50_q, R.string.quiz_50_opt_0, R.string.quiz_50_opt_1, R.string.quiz_50_opt_2, R.string.quiz_50_opt_3, 3, R.string.quiz_50_expl),
        QuizResSpec(51, R.string.quiz_51_cat, R.string.quiz_51_q, R.string.quiz_51_opt_0, R.string.quiz_51_opt_1, R.string.quiz_51_opt_2, R.string.quiz_51_opt_3, 2, R.string.quiz_51_expl),
        QuizResSpec(52, R.string.quiz_52_cat, R.string.quiz_52_q, R.string.quiz_52_opt_0, R.string.quiz_52_opt_1, R.string.quiz_52_opt_2, R.string.quiz_52_opt_3, 1, R.string.quiz_52_expl),
        QuizResSpec(53, R.string.quiz_53_cat, R.string.quiz_53_q, R.string.quiz_53_opt_0, R.string.quiz_53_opt_1, R.string.quiz_53_opt_2, R.string.quiz_53_opt_3, 1, R.string.quiz_53_expl),
        QuizResSpec(54, R.string.quiz_54_cat, R.string.quiz_54_q, R.string.quiz_54_opt_0, R.string.quiz_54_opt_1, R.string.quiz_54_opt_2, R.string.quiz_54_opt_3, 0, R.string.quiz_54_expl),
        QuizResSpec(55, R.string.quiz_55_cat, R.string.quiz_55_q, R.string.quiz_55_opt_0, R.string.quiz_55_opt_1, R.string.quiz_55_opt_2, R.string.quiz_55_opt_3, 3, R.string.quiz_55_expl),
        QuizResSpec(56, R.string.quiz_56_cat, R.string.quiz_56_q, R.string.quiz_56_opt_0, R.string.quiz_56_opt_1, R.string.quiz_56_opt_2, R.string.quiz_56_opt_3, 3, R.string.quiz_56_expl),
        QuizResSpec(57, R.string.quiz_57_cat, R.string.quiz_57_q, R.string.quiz_57_opt_0, R.string.quiz_57_opt_1, R.string.quiz_57_opt_2, R.string.quiz_57_opt_3, 0, R.string.quiz_57_expl),
        QuizResSpec(58, R.string.quiz_58_cat, R.string.quiz_58_q, R.string.quiz_58_opt_0, R.string.quiz_58_opt_1, R.string.quiz_58_opt_2, R.string.quiz_58_opt_3, 2, R.string.quiz_58_expl),
        QuizResSpec(59, R.string.quiz_59_cat, R.string.quiz_59_q, R.string.quiz_59_opt_0, R.string.quiz_59_opt_1, R.string.quiz_59_opt_2, R.string.quiz_59_opt_3, 1, R.string.quiz_59_expl),
        QuizResSpec(60, R.string.quiz_60_cat, R.string.quiz_60_q, R.string.quiz_60_opt_0, R.string.quiz_60_opt_1, R.string.quiz_60_opt_2, R.string.quiz_60_opt_3, 0, R.string.quiz_60_expl),
        QuizResSpec(61, R.string.quiz_61_cat, R.string.quiz_61_q, R.string.quiz_61_opt_0, R.string.quiz_61_opt_1, R.string.quiz_61_opt_2, R.string.quiz_61_opt_3, 0, R.string.quiz_61_expl),
        QuizResSpec(62, R.string.quiz_62_cat, R.string.quiz_62_q, R.string.quiz_62_opt_0, R.string.quiz_62_opt_1, R.string.quiz_62_opt_2, R.string.quiz_62_opt_3, 3, R.string.quiz_62_expl),
        QuizResSpec(63, R.string.quiz_63_cat, R.string.quiz_63_q, R.string.quiz_63_opt_0, R.string.quiz_63_opt_1, R.string.quiz_63_opt_2, R.string.quiz_63_opt_3, 2, R.string.quiz_63_expl),
        QuizResSpec(64, R.string.quiz_64_cat, R.string.quiz_64_q, R.string.quiz_64_opt_0, R.string.quiz_64_opt_1, R.string.quiz_64_opt_2, R.string.quiz_64_opt_3, 1, R.string.quiz_64_expl),
        QuizResSpec(65, R.string.quiz_65_cat, R.string.quiz_65_q, R.string.quiz_65_opt_0, R.string.quiz_65_opt_1, R.string.quiz_65_opt_2, R.string.quiz_65_opt_3, 1, R.string.quiz_65_expl),
        QuizResSpec(66, R.string.quiz_66_cat, R.string.quiz_66_q, R.string.quiz_66_opt_0, R.string.quiz_66_opt_1, R.string.quiz_66_opt_2, R.string.quiz_66_opt_3, 0, R.string.quiz_66_expl),
        QuizResSpec(67, R.string.quiz_67_cat, R.string.quiz_67_q, R.string.quiz_67_opt_0, R.string.quiz_67_opt_1, R.string.quiz_67_opt_2, R.string.quiz_67_opt_3, 0, R.string.quiz_67_expl),
        QuizResSpec(68, R.string.quiz_68_cat, R.string.quiz_68_q, R.string.quiz_68_opt_0, R.string.quiz_68_opt_1, R.string.quiz_68_opt_2, R.string.quiz_68_opt_3, 3, R.string.quiz_68_expl),
        QuizResSpec(69, R.string.quiz_69_cat, R.string.quiz_69_q, R.string.quiz_69_opt_0, R.string.quiz_69_opt_1, R.string.quiz_69_opt_2, R.string.quiz_69_opt_3, 3, R.string.quiz_69_expl),
        QuizResSpec(70, R.string.quiz_70_cat, R.string.quiz_70_q, R.string.quiz_70_opt_0, R.string.quiz_70_opt_1, R.string.quiz_70_opt_2, R.string.quiz_70_opt_3, 2, R.string.quiz_70_expl),
        QuizResSpec(71, R.string.quiz_71_cat, R.string.quiz_71_q, R.string.quiz_71_opt_0, R.string.quiz_71_opt_1, R.string.quiz_71_opt_2, R.string.quiz_71_opt_3, 1, R.string.quiz_71_expl),
        QuizResSpec(72, R.string.quiz_72_cat, R.string.quiz_72_q, R.string.quiz_72_opt_0, R.string.quiz_72_opt_1, R.string.quiz_72_opt_2, R.string.quiz_72_opt_3, 0, R.string.quiz_72_expl),
        QuizResSpec(73, R.string.quiz_73_cat, R.string.quiz_73_q, R.string.quiz_73_opt_0, R.string.quiz_73_opt_1, R.string.quiz_73_opt_2, R.string.quiz_73_opt_3, 0, R.string.quiz_73_expl),
        QuizResSpec(74, R.string.quiz_74_cat, R.string.quiz_74_q, R.string.quiz_74_opt_0, R.string.quiz_74_opt_1, R.string.quiz_74_opt_2, R.string.quiz_74_opt_3, 3, R.string.quiz_74_expl),
        QuizResSpec(75, R.string.quiz_75_cat, R.string.quiz_75_q, R.string.quiz_75_opt_0, R.string.quiz_75_opt_1, R.string.quiz_75_opt_2, R.string.quiz_75_opt_3, 2, R.string.quiz_75_expl),
        QuizResSpec(76, R.string.quiz_76_cat, R.string.quiz_76_q, R.string.quiz_76_opt_0, R.string.quiz_76_opt_1, R.string.quiz_76_opt_2, R.string.quiz_76_opt_3, 1, R.string.quiz_76_expl),
        QuizResSpec(77, R.string.quiz_77_cat, R.string.quiz_77_q, R.string.quiz_77_opt_0, R.string.quiz_77_opt_1, R.string.quiz_77_opt_2, R.string.quiz_77_opt_3, 1, R.string.quiz_77_expl),
        QuizResSpec(78, R.string.quiz_78_cat, R.string.quiz_78_q, R.string.quiz_78_opt_0, R.string.quiz_78_opt_1, R.string.quiz_78_opt_2, R.string.quiz_78_opt_3, 2, R.string.quiz_78_expl),
        QuizResSpec(79, R.string.quiz_79_cat, R.string.quiz_79_q, R.string.quiz_79_opt_0, R.string.quiz_79_opt_1, R.string.quiz_79_opt_2, R.string.quiz_79_opt_3, 0, R.string.quiz_79_expl),
        QuizResSpec(80, R.string.quiz_80_cat, R.string.quiz_80_q, R.string.quiz_80_opt_0, R.string.quiz_80_opt_1, R.string.quiz_80_opt_2, R.string.quiz_80_opt_3, 3, R.string.quiz_80_expl),
        QuizResSpec(81, R.string.quiz_81_cat, R.string.quiz_81_q, R.string.quiz_81_opt_0, R.string.quiz_81_opt_1, R.string.quiz_81_opt_2, R.string.quiz_81_opt_3, 3, R.string.quiz_81_expl),
        QuizResSpec(82, R.string.quiz_82_cat, R.string.quiz_82_q, R.string.quiz_82_opt_0, R.string.quiz_82_opt_1, R.string.quiz_82_opt_2, R.string.quiz_82_opt_3, 2, R.string.quiz_82_expl),
        QuizResSpec(83, R.string.quiz_83_cat, R.string.quiz_83_q, R.string.quiz_83_opt_0, R.string.quiz_83_opt_1, R.string.quiz_83_opt_2, R.string.quiz_83_opt_3, 1, R.string.quiz_83_expl),
        QuizResSpec(84, R.string.quiz_84_cat, R.string.quiz_84_q, R.string.quiz_84_opt_0, R.string.quiz_84_opt_1, R.string.quiz_84_opt_2, R.string.quiz_84_opt_3, 0, R.string.quiz_84_expl),
        QuizResSpec(85, R.string.quiz_85_cat, R.string.quiz_85_q, R.string.quiz_85_opt_0, R.string.quiz_85_opt_1, R.string.quiz_85_opt_2, R.string.quiz_85_opt_3, 0, R.string.quiz_85_expl),
        QuizResSpec(86, R.string.quiz_86_cat, R.string.quiz_86_q, R.string.quiz_86_opt_0, R.string.quiz_86_opt_1, R.string.quiz_86_opt_2, R.string.quiz_86_opt_3, 3, R.string.quiz_86_expl),
        QuizResSpec(87, R.string.quiz_87_cat, R.string.quiz_87_q, R.string.quiz_87_opt_0, R.string.quiz_87_opt_1, R.string.quiz_87_opt_2, R.string.quiz_87_opt_3, 2, R.string.quiz_87_expl),
        QuizResSpec(88, R.string.quiz_88_cat, R.string.quiz_88_q, R.string.quiz_88_opt_0, R.string.quiz_88_opt_1, R.string.quiz_88_opt_2, R.string.quiz_88_opt_3, 1, R.string.quiz_88_expl),
        QuizResSpec(89, R.string.quiz_89_cat, R.string.quiz_89_q, R.string.quiz_89_opt_0, R.string.quiz_89_opt_1, R.string.quiz_89_opt_2, R.string.quiz_89_opt_3, 2, R.string.quiz_89_expl),
        QuizResSpec(90, R.string.quiz_90_cat, R.string.quiz_90_q, R.string.quiz_90_opt_0, R.string.quiz_90_opt_1, R.string.quiz_90_opt_2, R.string.quiz_90_opt_3, 1, R.string.quiz_90_expl),
        QuizResSpec(91, R.string.quiz_91_cat, R.string.quiz_91_q, R.string.quiz_91_opt_0, R.string.quiz_91_opt_1, R.string.quiz_91_opt_2, R.string.quiz_91_opt_3, 0, R.string.quiz_91_expl),
        QuizResSpec(92, R.string.quiz_92_cat, R.string.quiz_92_q, R.string.quiz_92_opt_0, R.string.quiz_92_opt_1, R.string.quiz_92_opt_2, R.string.quiz_92_opt_3, 3, R.string.quiz_92_expl),
        QuizResSpec(93, R.string.quiz_93_cat, R.string.quiz_93_q, R.string.quiz_93_opt_0, R.string.quiz_93_opt_1, R.string.quiz_93_opt_2, R.string.quiz_93_opt_3, 3, R.string.quiz_93_expl),
        QuizResSpec(94, R.string.quiz_94_cat, R.string.quiz_94_q, R.string.quiz_94_opt_0, R.string.quiz_94_opt_1, R.string.quiz_94_opt_2, R.string.quiz_94_opt_3, 2, R.string.quiz_94_expl),
        QuizResSpec(95, R.string.quiz_95_cat, R.string.quiz_95_q, R.string.quiz_95_opt_0, R.string.quiz_95_opt_1, R.string.quiz_95_opt_2, R.string.quiz_95_opt_3, 1, R.string.quiz_95_expl),
        QuizResSpec(96, R.string.quiz_96_cat, R.string.quiz_96_q, R.string.quiz_96_opt_0, R.string.quiz_96_opt_1, R.string.quiz_96_opt_2, R.string.quiz_96_opt_3, 0, R.string.quiz_96_expl),
        QuizResSpec(97, R.string.quiz_97_cat, R.string.quiz_97_q, R.string.quiz_97_opt_0, R.string.quiz_97_opt_1, R.string.quiz_97_opt_2, R.string.quiz_97_opt_3, 0, R.string.quiz_97_expl),
        QuizResSpec(98, R.string.quiz_98_cat, R.string.quiz_98_q, R.string.quiz_98_opt_0, R.string.quiz_98_opt_1, R.string.quiz_98_opt_2, R.string.quiz_98_opt_3, 3, R.string.quiz_98_expl),
        QuizResSpec(99, R.string.quiz_99_cat, R.string.quiz_99_q, R.string.quiz_99_opt_0, R.string.quiz_99_opt_1, R.string.quiz_99_opt_2, R.string.quiz_99_opt_3, 2, R.string.quiz_99_expl),
        QuizResSpec(100, R.string.quiz_100_cat, R.string.quiz_100_q, R.string.quiz_100_opt_0, R.string.quiz_100_opt_1, R.string.quiz_100_opt_2, R.string.quiz_100_opt_3, 2, R.string.quiz_100_expl),
        QuizResSpec(101, R.string.quiz_101_cat, R.string.quiz_101_q, R.string.quiz_101_opt_0, R.string.quiz_101_opt_1, R.string.quiz_101_opt_2, R.string.quiz_101_opt_3, 3, R.string.quiz_101_expl),
        QuizResSpec(102, R.string.quiz_102_cat, R.string.quiz_102_q, R.string.quiz_102_opt_0, R.string.quiz_102_opt_1, R.string.quiz_102_opt_2, R.string.quiz_102_opt_3, 1, R.string.quiz_102_expl),
        QuizResSpec(103, R.string.quiz_103_cat, R.string.quiz_103_q, R.string.quiz_103_opt_0, R.string.quiz_103_opt_1, R.string.quiz_103_opt_2, R.string.quiz_103_opt_3, 0, R.string.quiz_103_expl),
        QuizResSpec(104, R.string.quiz_104_cat, R.string.quiz_104_q, R.string.quiz_104_opt_0, R.string.quiz_104_opt_1, R.string.quiz_104_opt_2, R.string.quiz_104_opt_3, 3, R.string.quiz_104_expl),
        QuizResSpec(105, R.string.quiz_105_cat, R.string.quiz_105_q, R.string.quiz_105_opt_0, R.string.quiz_105_opt_1, R.string.quiz_105_opt_2, R.string.quiz_105_opt_3, 3, R.string.quiz_105_expl),
        QuizResSpec(106, R.string.quiz_106_cat, R.string.quiz_106_q, R.string.quiz_106_opt_0, R.string.quiz_106_opt_1, R.string.quiz_106_opt_2, R.string.quiz_106_opt_3, 2, R.string.quiz_106_expl),
        QuizResSpec(107, R.string.quiz_107_cat, R.string.quiz_107_q, R.string.quiz_107_opt_0, R.string.quiz_107_opt_1, R.string.quiz_107_opt_2, R.string.quiz_107_opt_3, 1, R.string.quiz_107_expl),
        QuizResSpec(108, R.string.quiz_108_cat, R.string.quiz_108_q, R.string.quiz_108_opt_0, R.string.quiz_108_opt_1, R.string.quiz_108_opt_2, R.string.quiz_108_opt_3, 0, R.string.quiz_108_expl),
        QuizResSpec(109, R.string.quiz_109_cat, R.string.quiz_109_q, R.string.quiz_109_opt_0, R.string.quiz_109_opt_1, R.string.quiz_109_opt_2, R.string.quiz_109_opt_3, 0, R.string.quiz_109_expl),
        QuizResSpec(110, R.string.quiz_110_cat, R.string.quiz_110_q, R.string.quiz_110_opt_0, R.string.quiz_110_opt_1, R.string.quiz_110_opt_2, R.string.quiz_110_opt_3, 3, R.string.quiz_110_expl),
        QuizResSpec(111, R.string.quiz_111_cat, R.string.quiz_111_q, R.string.quiz_111_opt_0, R.string.quiz_111_opt_1, R.string.quiz_111_opt_2, R.string.quiz_111_opt_3, 3, R.string.quiz_111_expl),
        QuizResSpec(112, R.string.quiz_112_cat, R.string.quiz_112_q, R.string.quiz_112_opt_0, R.string.quiz_112_opt_1, R.string.quiz_112_opt_2, R.string.quiz_112_opt_3, 2, R.string.quiz_112_expl),
        QuizResSpec(113, R.string.quiz_113_cat, R.string.quiz_113_q, R.string.quiz_113_opt_0, R.string.quiz_113_opt_1, R.string.quiz_113_opt_2, R.string.quiz_113_opt_3, 2, R.string.quiz_113_expl),
        QuizResSpec(114, R.string.quiz_114_cat, R.string.quiz_114_q, R.string.quiz_114_opt_0, R.string.quiz_114_opt_1, R.string.quiz_114_opt_2, R.string.quiz_114_opt_3, 1, R.string.quiz_114_expl),
        QuizResSpec(115, R.string.quiz_115_cat, R.string.quiz_115_q, R.string.quiz_115_opt_0, R.string.quiz_115_opt_1, R.string.quiz_115_opt_2, R.string.quiz_115_opt_3, 0, R.string.quiz_115_expl),
        QuizResSpec(116, R.string.quiz_116_cat, R.string.quiz_116_q, R.string.quiz_116_opt_0, R.string.quiz_116_opt_1, R.string.quiz_116_opt_2, R.string.quiz_116_opt_3, 3, R.string.quiz_116_expl),
        QuizResSpec(117, R.string.quiz_117_cat, R.string.quiz_117_q, R.string.quiz_117_opt_0, R.string.quiz_117_opt_1, R.string.quiz_117_opt_2, R.string.quiz_117_opt_3, 3, R.string.quiz_117_expl),
        QuizResSpec(118, R.string.quiz_118_cat, R.string.quiz_118_q, R.string.quiz_118_opt_0, R.string.quiz_118_opt_1, R.string.quiz_118_opt_2, R.string.quiz_118_opt_3, 2, R.string.quiz_118_expl),
        QuizResSpec(119, R.string.quiz_119_cat, R.string.quiz_119_q, R.string.quiz_119_opt_0, R.string.quiz_119_opt_1, R.string.quiz_119_opt_2, R.string.quiz_119_opt_3, 1, R.string.quiz_119_expl),
        QuizResSpec(120, R.string.quiz_120_cat, R.string.quiz_120_q, R.string.quiz_120_opt_0, R.string.quiz_120_opt_1, R.string.quiz_120_opt_2, R.string.quiz_120_opt_3, 0, R.string.quiz_120_expl),
        QuizResSpec(121, R.string.quiz_121_cat, R.string.quiz_121_q, R.string.quiz_121_opt_0, R.string.quiz_121_opt_1, R.string.quiz_121_opt_2, R.string.quiz_121_opt_3, 0, R.string.quiz_121_expl),
        QuizResSpec(122, R.string.quiz_122_cat, R.string.quiz_122_q, R.string.quiz_122_opt_0, R.string.quiz_122_opt_1, R.string.quiz_122_opt_2, R.string.quiz_122_opt_3, 1, R.string.quiz_122_expl),
        QuizResSpec(123, R.string.quiz_123_cat, R.string.quiz_123_q, R.string.quiz_123_opt_0, R.string.quiz_123_opt_1, R.string.quiz_123_opt_2, R.string.quiz_123_opt_3, 3, R.string.quiz_123_expl),
        QuizResSpec(124, R.string.quiz_124_cat, R.string.quiz_124_q, R.string.quiz_124_opt_0, R.string.quiz_124_opt_1, R.string.quiz_124_opt_2, R.string.quiz_124_opt_3, 2, R.string.quiz_124_expl),
        QuizResSpec(125, R.string.quiz_125_cat, R.string.quiz_125_q, R.string.quiz_125_opt_0, R.string.quiz_125_opt_1, R.string.quiz_125_opt_2, R.string.quiz_125_opt_3, 2, R.string.quiz_125_expl),
        QuizResSpec(126, R.string.quiz_126_cat, R.string.quiz_126_q, R.string.quiz_126_opt_0, R.string.quiz_126_opt_1, R.string.quiz_126_opt_2, R.string.quiz_126_opt_3, 1, R.string.quiz_126_expl),
        QuizResSpec(127, R.string.quiz_127_cat, R.string.quiz_127_q, R.string.quiz_127_opt_0, R.string.quiz_127_opt_1, R.string.quiz_127_opt_2, R.string.quiz_127_opt_3, 0, R.string.quiz_127_expl),
        QuizResSpec(128, R.string.quiz_128_cat, R.string.quiz_128_q, R.string.quiz_128_opt_0, R.string.quiz_128_opt_1, R.string.quiz_128_opt_2, R.string.quiz_128_opt_3, 3, R.string.quiz_128_expl),
        QuizResSpec(129, R.string.quiz_129_cat, R.string.quiz_129_q, R.string.quiz_129_opt_0, R.string.quiz_129_opt_1, R.string.quiz_129_opt_2, R.string.quiz_129_opt_3, 3, R.string.quiz_129_expl),
        QuizResSpec(130, R.string.quiz_130_cat, R.string.quiz_130_q, R.string.quiz_130_opt_0, R.string.quiz_130_opt_1, R.string.quiz_130_opt_2, R.string.quiz_130_opt_3, 2, R.string.quiz_130_expl),
        QuizResSpec(131, R.string.quiz_131_cat, R.string.quiz_131_q, R.string.quiz_131_opt_0, R.string.quiz_131_opt_1, R.string.quiz_131_opt_2, R.string.quiz_131_opt_3, 1, R.string.quiz_131_expl),
        QuizResSpec(132, R.string.quiz_132_cat, R.string.quiz_132_q, R.string.quiz_132_opt_0, R.string.quiz_132_opt_1, R.string.quiz_132_opt_2, R.string.quiz_132_opt_3, 0, R.string.quiz_132_expl),
        QuizResSpec(133, R.string.quiz_133_cat, R.string.quiz_133_q, R.string.quiz_133_opt_0, R.string.quiz_133_opt_1, R.string.quiz_133_opt_2, R.string.quiz_133_opt_3, 1, R.string.quiz_133_expl),
        QuizResSpec(134, R.string.quiz_134_cat, R.string.quiz_134_q, R.string.quiz_134_opt_0, R.string.quiz_134_opt_1, R.string.quiz_134_opt_2, R.string.quiz_134_opt_3, 0, R.string.quiz_134_expl),
        QuizResSpec(135, R.string.quiz_135_cat, R.string.quiz_135_q, R.string.quiz_135_opt_0, R.string.quiz_135_opt_1, R.string.quiz_135_opt_2, R.string.quiz_135_opt_3, 3, R.string.quiz_135_expl),
        QuizResSpec(136, R.string.quiz_136_cat, R.string.quiz_136_q, R.string.quiz_136_opt_0, R.string.quiz_136_opt_1, R.string.quiz_136_opt_2, R.string.quiz_136_opt_3, 2, R.string.quiz_136_expl),
        QuizResSpec(137, R.string.quiz_137_cat, R.string.quiz_137_q, R.string.quiz_137_opt_0, R.string.quiz_137_opt_1, R.string.quiz_137_opt_2, R.string.quiz_137_opt_3, 2, R.string.quiz_137_expl),
        QuizResSpec(138, R.string.quiz_138_cat, R.string.quiz_138_q, R.string.quiz_138_opt_0, R.string.quiz_138_opt_1, R.string.quiz_138_opt_2, R.string.quiz_138_opt_3, 1, R.string.quiz_138_expl),
        QuizResSpec(139, R.string.quiz_139_cat, R.string.quiz_139_q, R.string.quiz_139_opt_0, R.string.quiz_139_opt_1, R.string.quiz_139_opt_2, R.string.quiz_139_opt_3, 0, R.string.quiz_139_expl),
        QuizResSpec(140, R.string.quiz_140_cat, R.string.quiz_140_q, R.string.quiz_140_opt_0, R.string.quiz_140_opt_1, R.string.quiz_140_opt_2, R.string.quiz_140_opt_3, 3, R.string.quiz_140_expl),
        QuizResSpec(141, R.string.quiz_141_cat, R.string.quiz_141_q, R.string.quiz_141_opt_0, R.string.quiz_141_opt_1, R.string.quiz_141_opt_2, R.string.quiz_141_opt_3, 3, R.string.quiz_141_expl),
        QuizResSpec(142, R.string.quiz_142_cat, R.string.quiz_142_q, R.string.quiz_142_opt_0, R.string.quiz_142_opt_1, R.string.quiz_142_opt_2, R.string.quiz_142_opt_3, 2, R.string.quiz_142_expl),
        QuizResSpec(143, R.string.quiz_143_cat, R.string.quiz_143_q, R.string.quiz_143_opt_0, R.string.quiz_143_opt_1, R.string.quiz_143_opt_2, R.string.quiz_143_opt_3, 1, R.string.quiz_143_expl),
        QuizResSpec(144, R.string.quiz_144_cat, R.string.quiz_144_q, R.string.quiz_144_opt_0, R.string.quiz_144_opt_1, R.string.quiz_144_opt_2, R.string.quiz_144_opt_3, 1, R.string.quiz_144_expl),
        QuizResSpec(145, R.string.quiz_145_cat, R.string.quiz_145_q, R.string.quiz_145_opt_0, R.string.quiz_145_opt_1, R.string.quiz_145_opt_2, R.string.quiz_145_opt_3, 2, R.string.quiz_145_expl),
        QuizResSpec(146, R.string.quiz_146_cat, R.string.quiz_146_q, R.string.quiz_146_opt_0, R.string.quiz_146_opt_1, R.string.quiz_146_opt_2, R.string.quiz_146_opt_3, 0, R.string.quiz_146_expl),
        QuizResSpec(147, R.string.quiz_147_cat, R.string.quiz_147_q, R.string.quiz_147_opt_0, R.string.quiz_147_opt_1, R.string.quiz_147_opt_2, R.string.quiz_147_opt_3, 3, R.string.quiz_147_expl),
        QuizResSpec(148, R.string.quiz_148_cat, R.string.quiz_148_q, R.string.quiz_148_opt_0, R.string.quiz_148_opt_1, R.string.quiz_148_opt_2, R.string.quiz_148_opt_3, 2, R.string.quiz_148_expl),
        QuizResSpec(149, R.string.quiz_149_cat, R.string.quiz_149_q, R.string.quiz_149_opt_0, R.string.quiz_149_opt_1, R.string.quiz_149_opt_2, R.string.quiz_149_opt_3, 2, R.string.quiz_149_expl),
        QuizResSpec(150, R.string.quiz_150_cat, R.string.quiz_150_q, R.string.quiz_150_opt_0, R.string.quiz_150_opt_1, R.string.quiz_150_opt_2, R.string.quiz_150_opt_3, 1, R.string.quiz_150_expl),
        QuizResSpec(151, R.string.quiz_151_cat, R.string.quiz_151_q, R.string.quiz_151_opt_0, R.string.quiz_151_opt_1, R.string.quiz_151_opt_2, R.string.quiz_151_opt_3, 0, R.string.quiz_151_expl),
        QuizResSpec(152, R.string.quiz_152_cat, R.string.quiz_152_q, R.string.quiz_152_opt_0, R.string.quiz_152_opt_1, R.string.quiz_152_opt_2, R.string.quiz_152_opt_3, 3, R.string.quiz_152_expl),
        QuizResSpec(153, R.string.quiz_153_cat, R.string.quiz_153_q, R.string.quiz_153_opt_0, R.string.quiz_153_opt_1, R.string.quiz_153_opt_2, R.string.quiz_153_opt_3, 3, R.string.quiz_153_expl),
        QuizResSpec(154, R.string.quiz_154_cat, R.string.quiz_154_q, R.string.quiz_154_opt_0, R.string.quiz_154_opt_1, R.string.quiz_154_opt_2, R.string.quiz_154_opt_3, 2, R.string.quiz_154_expl),
        QuizResSpec(155, R.string.quiz_155_cat, R.string.quiz_155_q, R.string.quiz_155_opt_0, R.string.quiz_155_opt_1, R.string.quiz_155_opt_2, R.string.quiz_155_opt_3, 2, R.string.quiz_155_expl),
        QuizResSpec(156, R.string.quiz_156_cat, R.string.quiz_156_q, R.string.quiz_156_opt_0, R.string.quiz_156_opt_1, R.string.quiz_156_opt_2, R.string.quiz_156_opt_3, 1, R.string.quiz_156_expl),
        QuizResSpec(157, R.string.quiz_157_cat, R.string.quiz_157_q, R.string.quiz_157_opt_0, R.string.quiz_157_opt_1, R.string.quiz_157_opt_2, R.string.quiz_157_opt_3, 1, R.string.quiz_157_expl),
        QuizResSpec(158, R.string.quiz_158_cat, R.string.quiz_158_q, R.string.quiz_158_opt_0, R.string.quiz_158_opt_1, R.string.quiz_158_opt_2, R.string.quiz_158_opt_3, 0, R.string.quiz_158_expl),
        QuizResSpec(159, R.string.quiz_159_cat, R.string.quiz_159_q, R.string.quiz_159_opt_0, R.string.quiz_159_opt_1, R.string.quiz_159_opt_2, R.string.quiz_159_opt_3, 3, R.string.quiz_159_expl),
        QuizResSpec(160, R.string.quiz_160_cat, R.string.quiz_160_q, R.string.quiz_160_opt_0, R.string.quiz_160_opt_1, R.string.quiz_160_opt_2, R.string.quiz_160_opt_3, 2, R.string.quiz_160_expl),
        QuizResSpec(161, R.string.quiz_161_cat, R.string.quiz_161_q, R.string.quiz_161_opt_0, R.string.quiz_161_opt_1, R.string.quiz_161_opt_2, R.string.quiz_161_opt_3, 2, R.string.quiz_161_expl),
        QuizResSpec(162, R.string.quiz_162_cat, R.string.quiz_162_q, R.string.quiz_162_opt_0, R.string.quiz_162_opt_1, R.string.quiz_162_opt_2, R.string.quiz_162_opt_3, 1, R.string.quiz_162_expl),
        QuizResSpec(163, R.string.quiz_163_cat, R.string.quiz_163_q, R.string.quiz_163_opt_0, R.string.quiz_163_opt_1, R.string.quiz_163_opt_2, R.string.quiz_163_opt_3, 0, R.string.quiz_163_expl),
        QuizResSpec(164, R.string.quiz_164_cat, R.string.quiz_164_q, R.string.quiz_164_opt_0, R.string.quiz_164_opt_1, R.string.quiz_164_opt_2, R.string.quiz_164_opt_3, 3, R.string.quiz_164_expl),
        QuizResSpec(165, R.string.quiz_165_cat, R.string.quiz_165_q, R.string.quiz_165_opt_0, R.string.quiz_165_opt_1, R.string.quiz_165_opt_2, R.string.quiz_165_opt_3, 3, R.string.quiz_165_expl),
        QuizResSpec(166, R.string.quiz_166_cat, R.string.quiz_166_q, R.string.quiz_166_opt_0, R.string.quiz_166_opt_1, R.string.quiz_166_opt_2, R.string.quiz_166_opt_3, 0, R.string.quiz_166_expl),
        QuizResSpec(167, R.string.quiz_167_cat, R.string.quiz_167_q, R.string.quiz_167_opt_0, R.string.quiz_167_opt_1, R.string.quiz_167_opt_2, R.string.quiz_167_opt_3, 2, R.string.quiz_167_expl),
        QuizResSpec(168, R.string.quiz_168_cat, R.string.quiz_168_q, R.string.quiz_168_opt_0, R.string.quiz_168_opt_1, R.string.quiz_168_opt_2, R.string.quiz_168_opt_3, 1, R.string.quiz_168_expl),
        QuizResSpec(169, R.string.quiz_169_cat, R.string.quiz_169_q, R.string.quiz_169_opt_0, R.string.quiz_169_opt_1, R.string.quiz_169_opt_2, R.string.quiz_169_opt_3, 1, R.string.quiz_169_expl),
        QuizResSpec(170, R.string.quiz_170_cat, R.string.quiz_170_q, R.string.quiz_170_opt_0, R.string.quiz_170_opt_1, R.string.quiz_170_opt_2, R.string.quiz_170_opt_3, 0, R.string.quiz_170_expl),
        QuizResSpec(171, R.string.quiz_171_cat, R.string.quiz_171_q, R.string.quiz_171_opt_0, R.string.quiz_171_opt_1, R.string.quiz_171_opt_2, R.string.quiz_171_opt_3, 3, R.string.quiz_171_expl),
        QuizResSpec(172, R.string.quiz_172_cat, R.string.quiz_172_q, R.string.quiz_172_opt_0, R.string.quiz_172_opt_1, R.string.quiz_172_opt_2, R.string.quiz_172_opt_3, 2, R.string.quiz_172_expl),
        QuizResSpec(173, R.string.quiz_173_cat, R.string.quiz_173_q, R.string.quiz_173_opt_0, R.string.quiz_173_opt_1, R.string.quiz_173_opt_2, R.string.quiz_173_opt_3, 2, R.string.quiz_173_expl),
        QuizResSpec(174, R.string.quiz_174_cat, R.string.quiz_174_q, R.string.quiz_174_opt_0, R.string.quiz_174_opt_1, R.string.quiz_174_opt_2, R.string.quiz_174_opt_3, 1, R.string.quiz_174_expl),
        QuizResSpec(175, R.string.quiz_175_cat, R.string.quiz_175_q, R.string.quiz_175_opt_0, R.string.quiz_175_opt_1, R.string.quiz_175_opt_2, R.string.quiz_175_opt_3, 0, R.string.quiz_175_expl),
        QuizResSpec(176, R.string.quiz_176_cat, R.string.quiz_176_q, R.string.quiz_176_opt_0, R.string.quiz_176_opt_1, R.string.quiz_176_opt_2, R.string.quiz_176_opt_3, 3, R.string.quiz_176_expl),
        QuizResSpec(177, R.string.quiz_177_cat, R.string.quiz_177_q, R.string.quiz_177_opt_0, R.string.quiz_177_opt_1, R.string.quiz_177_opt_2, R.string.quiz_177_opt_3, 0, R.string.quiz_177_expl),
        QuizResSpec(178, R.string.quiz_178_cat, R.string.quiz_178_q, R.string.quiz_178_opt_0, R.string.quiz_178_opt_1, R.string.quiz_178_opt_2, R.string.quiz_178_opt_3, 3, R.string.quiz_178_expl),
        QuizResSpec(179, R.string.quiz_179_cat, R.string.quiz_179_q, R.string.quiz_179_opt_0, R.string.quiz_179_opt_1, R.string.quiz_179_opt_2, R.string.quiz_179_opt_3, 2, R.string.quiz_179_expl),
        QuizResSpec(180, R.string.quiz_180_cat, R.string.quiz_180_q, R.string.quiz_180_opt_0, R.string.quiz_180_opt_1, R.string.quiz_180_opt_2, R.string.quiz_180_opt_3, 1, R.string.quiz_180_expl),
        QuizResSpec(181, R.string.quiz_181_cat, R.string.quiz_181_q, R.string.quiz_181_opt_0, R.string.quiz_181_opt_1, R.string.quiz_181_opt_2, R.string.quiz_181_opt_3, 1, R.string.quiz_181_expl),
        QuizResSpec(182, R.string.quiz_182_cat, R.string.quiz_182_q, R.string.quiz_182_opt_0, R.string.quiz_182_opt_1, R.string.quiz_182_opt_2, R.string.quiz_182_opt_3, 0, R.string.quiz_182_expl),
        QuizResSpec(183, R.string.quiz_183_cat, R.string.quiz_183_q, R.string.quiz_183_opt_0, R.string.quiz_183_opt_1, R.string.quiz_183_opt_2, R.string.quiz_183_opt_3, 3, R.string.quiz_183_expl),
        QuizResSpec(184, R.string.quiz_184_cat, R.string.quiz_184_q, R.string.quiz_184_opt_0, R.string.quiz_184_opt_1, R.string.quiz_184_opt_2, R.string.quiz_184_opt_3, 2, R.string.quiz_184_expl),
        QuizResSpec(185, R.string.quiz_185_cat, R.string.quiz_185_q, R.string.quiz_185_opt_0, R.string.quiz_185_opt_1, R.string.quiz_185_opt_2, R.string.quiz_185_opt_3, 2, R.string.quiz_185_expl),
        QuizResSpec(186, R.string.quiz_186_cat, R.string.quiz_186_q, R.string.quiz_186_opt_0, R.string.quiz_186_opt_1, R.string.quiz_186_opt_2, R.string.quiz_186_opt_3, 1, R.string.quiz_186_expl),
        QuizResSpec(187, R.string.quiz_187_cat, R.string.quiz_187_q, R.string.quiz_187_opt_0, R.string.quiz_187_opt_1, R.string.quiz_187_opt_2, R.string.quiz_187_opt_3, 0, R.string.quiz_187_expl),
        QuizResSpec(188, R.string.quiz_188_cat, R.string.quiz_188_q, R.string.quiz_188_opt_0, R.string.quiz_188_opt_1, R.string.quiz_188_opt_2, R.string.quiz_188_opt_3, 0, R.string.quiz_188_expl),
        QuizResSpec(189, R.string.quiz_189_cat, R.string.quiz_189_q, R.string.quiz_189_opt_0, R.string.quiz_189_opt_1, R.string.quiz_189_opt_2, R.string.quiz_189_opt_3, 1, R.string.quiz_189_expl),
        QuizResSpec(190, R.string.quiz_190_cat, R.string.quiz_190_q, R.string.quiz_190_opt_0, R.string.quiz_190_opt_1, R.string.quiz_190_opt_2, R.string.quiz_190_opt_3, 3, R.string.quiz_190_expl),
        QuizResSpec(191, R.string.quiz_191_cat, R.string.quiz_191_q, R.string.quiz_191_opt_0, R.string.quiz_191_opt_1, R.string.quiz_191_opt_2, R.string.quiz_191_opt_3, 2, R.string.quiz_191_expl),
        QuizResSpec(192, R.string.quiz_192_cat, R.string.quiz_192_q, R.string.quiz_192_opt_0, R.string.quiz_192_opt_1, R.string.quiz_192_opt_2, R.string.quiz_192_opt_3, 1, R.string.quiz_192_expl),
        QuizResSpec(193, R.string.quiz_193_cat, R.string.quiz_193_q, R.string.quiz_193_opt_0, R.string.quiz_193_opt_1, R.string.quiz_193_opt_2, R.string.quiz_193_opt_3, 1, R.string.quiz_193_expl),
        QuizResSpec(194, R.string.quiz_194_cat, R.string.quiz_194_q, R.string.quiz_194_opt_0, R.string.quiz_194_opt_1, R.string.quiz_194_opt_2, R.string.quiz_194_opt_3, 0, R.string.quiz_194_expl),
        QuizResSpec(195, R.string.quiz_195_cat, R.string.quiz_195_q, R.string.quiz_195_opt_0, R.string.quiz_195_opt_1, R.string.quiz_195_opt_2, R.string.quiz_195_opt_3, 3, R.string.quiz_195_expl)
    )


    private data class PhotoSpec(
        @DrawableRes val imageRes: Int,
        @StringRes val captionRes: Int,
        val afterSectionIndex: Int
    )

    private val chapterPhotoSpecs: Map<Int, List<PhotoSpec>> = mapOf(
        1 to listOf(
            PhotoSpec(R.drawable.photo_festival_1, R.string.photo_festival_1_caption, 2),
            PhotoSpec(R.drawable.photo_festival_2, R.string.photo_festival_2_caption, 3)
        ),
        2 to listOf(
            PhotoSpec(R.drawable.photo_gena_1, R.string.photo_gena_1_caption, 0),
            PhotoSpec(R.drawable.photo_gena_2, R.string.photo_gena_2_caption, 6)
        ),
        3 to listOf(
            PhotoSpec(R.drawable.photo_kurbo_1, R.string.photo_kurbo_1_caption, 4)
        ),
        4 to listOf(
            PhotoSpec(R.drawable.photo_kinchibosh_1, R.string.photo_kinchibosh_1_caption, 6),
            PhotoSpec(R.drawable.photo_kinchibosh_2, R.string.photo_kinchibosh_2_caption, 9)
        ),
        5 to listOf(
            PhotoSpec(R.drawable.photo_slus_1, R.string.photo_slus_1_caption, 0),
            PhotoSpec(R.drawable.photo_slus_2, R.string.photo_slus_2_caption, 5),
            PhotoSpec(R.drawable.photo_slus_3, R.string.photo_slus_3_caption, 7)
        ),
        6 to listOf(
            PhotoSpec(R.drawable.photo_feres_gugs_1, R.string.photo_feres_gugs_1_caption, 3)
        ),
        7 to listOf(
            PhotoSpec(R.drawable.photo_feres_shert_1, R.string.photo_feres_shert_1_caption, 10)
        ),
        8 to listOf(
            PhotoSpec(R.drawable.photo_hurbe_1, R.string.photo_hurbe_1_caption, 7)
        ),
        9 to listOf(
            PhotoSpec(R.drawable.photo_qest_1, R.string.photo_qest_1_caption, 0),
            PhotoSpec(R.drawable.photo_qest_3, R.string.photo_qest_3_caption, 3),
            PhotoSpec(R.drawable.photo_qest_2, R.string.photo_qest_2_caption, 5),
            PhotoSpec(R.drawable.photo_qest_4, R.string.photo_qest_4_caption, 7),
            PhotoSpec(R.drawable.photo_qest_5, R.string.photo_qest_5_caption, 8),
            PhotoSpec(R.drawable.photo_qest_6, R.string.photo_qest_6_caption, 9)
        ),
        10 to listOf(
            PhotoSpec(R.drawable.photo_shah_1, R.string.photo_shah_1_caption, 0),
            PhotoSpec(R.drawable.photo_shah_2, R.string.photo_shah_2_caption, 2),
            PhotoSpec(R.drawable.photo_shah_3, R.string.photo_shah_3_caption, 4),
            PhotoSpec(R.drawable.photo_shah_4, R.string.photo_shah_4_caption, 5)
        ),
        11 to listOf(
            PhotoSpec(R.drawable.photo_bub_1, R.string.photo_bub_1_caption, 0),
            PhotoSpec(R.drawable.photo_bub_2, R.string.photo_bub_2_caption, 3),
            PhotoSpec(R.drawable.photo_bub_3, R.string.photo_bub_3_caption, 5)
        ),
        12 to listOf(
            PhotoSpec(R.drawable.photo_tigl_1, R.string.photo_tigl_1_caption, 0),
            PhotoSpec(R.drawable.photo_tigl_2, R.string.photo_tigl_2_caption, 4),
            PhotoSpec(R.drawable.photo_tigl_3, R.string.photo_tigl_3_caption, 5)
        ),
        13 to listOf(
            PhotoSpec(R.drawable.photo_festival_1, R.string.photo_festival_1_caption, 0),
            PhotoSpec(R.drawable.photo_festival_2, R.string.photo_festival_2_caption, 3)
        )
    )

    override fun getCategories(languageCode: String): List<String> {
        val res = localizedContext(languageCode).resources
        return categoryResIds.map { res.getString(it) }
    }

    override fun getChapters(languageCode: String): List<Chapter> {
        val res = localizedContext(languageCode).resources
        return chapterHeaders.map { hdr ->
            val secs = (chapterSectionSpecs[hdr.id] ?: emptyList()).mapIndexed { idx, pair ->
                RuleSection(
                    index = idx,
                    titleRes = pair.first,
                    bodyRes = pair.second,
                    titleText = res.getString(pair.first),
                    bodyText = res.getString(pair.second)
                )
            }
            val forms = (chapterFormSpecs[hdr.id] ?: emptyList()).mapIndexed { fIdx, fSpec ->
                val metaRaw = res.getString(fSpec.metaRes)
                val headersRaw = res.getString(fSpec.headersRes)
                val rowsRaw = res.getString(fSpec.rowsRes)
                val footerRaw = res.getString(fSpec.footerRes)
                CompetitionFormTable(
                    index = fIdx,
                    title = res.getString(fSpec.titleRes),
                    metaItems = metaRaw.split(" | ").map { it.trim() }.filter { it.isNotEmpty() },
                    headers = headersRaw.split(" || ").map { it.trim() },
                    rows = rowsRaw.lines().filter { it.isNotBlank() }.map { line ->
                        line.split(" || ").map { it.trim() }
                    },
                    footerItems = footerRaw.lines().map { it.trim() }.filter { it.isNotEmpty() }
                )
            }
            val fType = SportFieldType.fromChapterId(hdr.id)
            val photos = (chapterPhotoSpecs[hdr.id] ?: emptyList()).map { p ->
                SportPhotoItem(
                    imageRes = p.imageRes,
                    caption = res.getString(p.captionRes),
                    afterSectionIndex = p.afterSectionIndex
                )
            }
            Chapter(
                id = hdr.id,
                iconRes = hdr.iconRes,
                categoryName = res.getString(hdr.catRes),
                title = res.getString(hdr.titleRes),
                subtitle = res.getString(hdr.subRes),
                fieldType = fType,
                sections = secs,
                officialForms = forms,
                diagramRes = fType.diagramDrawableRes(),
                photos = photos
            )
        }
    }

    override fun getQuizzes(languageCode: String): List<QuizQuestion> {
        val res = localizedContext(languageCode).resources
        return quizSpecs.map { q ->
            QuizQuestion(
                id = q.id,
                category = res.getString(q.catRes),
                question = res.getString(q.qRes),
                options = listOf(
                    res.getString(q.opt0Res),
                    res.getString(q.opt1Res),
                    res.getString(q.opt2Res),
                    res.getString(q.opt3Res)
                ),
                correctIndex = q.ansIndex,
                explanation = res.getString(q.explRes)
            )
        }
    }
}
