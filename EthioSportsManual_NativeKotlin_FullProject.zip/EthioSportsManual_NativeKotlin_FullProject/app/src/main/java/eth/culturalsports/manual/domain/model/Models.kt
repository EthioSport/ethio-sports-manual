package eth.culturalsports.manual.domain.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import eth.culturalsports.manual.R

enum class SportFieldType(val id: Int) {
    GOVERNANCE_STRUCTURE(1),
    GENA_PITCH(2),
    KURBO_FIELD(3),
    KINCHIBOSH_12_BOARD(4),
    SLUS_18_BOARD(5),
    FERES_GUGS_FIELD(6),
    FERES_SHERT_TRACK(7),
    HURBE_5ZONE_PITCH(8),
    QEST_ARCHERY_RANGE(9),
    SHAH_BOARD(10),
    BUB_BOARD(11),
    TIGL_WRESTLING_MAT(12),
    FESTIVAL_TRAINING_BOARD(13);

    @DrawableRes
    fun diagramDrawableRes(): Int? = when (this) {
        GENA_PITCH -> R.drawable.diagram_sport_2
        KURBO_FIELD -> R.drawable.diagram_sport_3
        KINCHIBOSH_12_BOARD -> R.drawable.diagram_sport_4
        SLUS_18_BOARD -> R.drawable.diagram_sport_5
        FERES_GUGS_FIELD -> R.drawable.diagram_sport_6
        FERES_SHERT_TRACK -> R.drawable.diagram_sport_7
        HURBE_5ZONE_PITCH -> R.drawable.diagram_sport_8
        QEST_ARCHERY_RANGE -> R.drawable.diagram_sport_9
        SHAH_BOARD -> R.drawable.diagram_sport_10
        BUB_BOARD -> R.drawable.diagram_sport_11
        TIGL_WRESTLING_MAT -> R.drawable.diagram_sport_12
        else -> null
    }

    companion object {
        fun fromChapterId(id: Int): SportFieldType {
            return entries.find { it.id == id } ?: GENA_PITCH
        }
    }
}

data class RuleSection(
    val index: Int,
    @StringRes val titleRes: Int,
    @StringRes val bodyRes: Int,
    val titleText: String,
    val bodyText: String
)

data class SportPhotoItem(
    @DrawableRes val imageRes: Int,
    val caption: String,
    val afterSectionIndex: Int
)

data class CompetitionFormTable(
    val index: Int,
    val title: String,
    val metaItems: List<String>,
    val headers: List<String>,
    val rows: List<List<String>>,
    val footerItems: List<String>
)

data class Chapter(
    val id: Int,
    @DrawableRes val iconRes: Int,
    val categoryName: String,
    val title: String,
    val subtitle: String,
    val fieldType: SportFieldType,
    val sections: List<RuleSection>,
    val officialForms: List<CompetitionFormTable>,
    @DrawableRes val diagramRes: Int? = null,
    val photos: List<SportPhotoItem> = emptyList()
)

data class QuizQuestion(
    val id: Int,
    val category: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

enum class TacticalTool {
    PAN_ZOOM,
    FREEHAND_LINE,
    TACTICAL_ARROW,
    PLACE_PEBBLE
}

data class TacticalStroke(
    val points: List<Offset>,
    val color: Color,
    val isArrow: Boolean,
    val isDashed: Boolean,
    val strokeWidth: Float = 6f
)

data class TacticalPebble(
    val position: Offset,
    val color: Color,
    val label: String
)

data class SearchMatchResult(
    val chapterId: Int,
    val chapterTitle: String,
    val categoryName: String,
    val sectionIndex: Int,
    val sectionTitle: String,
    val sectionBody: String,
    @DrawableRes val iconRes: Int
)
