package eth.culturalsports.manual.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import eth.culturalsports.manual.R
import eth.culturalsports.manual.domain.model.Chapter
import eth.culturalsports.manual.domain.model.SportFieldType
import eth.culturalsports.manual.domain.model.TacticalPebble
import eth.culturalsports.manual.domain.model.TacticalStroke
import eth.culturalsports.manual.domain.model.TacticalTool
import eth.culturalsports.manual.ui.components.InteractiveSportFieldCard

@Composable
fun TacticalBoardScreen(
    chapters: List<Chapter>,
    selectedFieldType: SportFieldType,
    tacticalTool: TacticalTool,
    activeColor: Color,
    isDashed: Boolean,
    strokes: List<TacticalStroke>,
    pebbles: List<TacticalPebble>,
    isAmharic: Boolean,
    onSelectFieldType: (SportFieldType) -> Unit,
    onSelectTool: (TacticalTool) -> Unit,
    onSelectColor: (Color) -> Unit,
    onAddStroke: (TacticalStroke) -> Unit,
    onAddPebble: (TacticalPebble) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onClear: () -> Unit
) {
    val palette = listOf(
        Color(0xFFFBBF24),
        Color(0xFFEF4444),
        Color(0xFF22C55E),
        Color(0xFF38BDF8),
        Color(0xFFFFFFFF)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(
            text = stringResource(id = R.string.tactical_title),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Sport Field / Board Selector with Circular Sport Photo Icons
        LazyRow(
            contentPadding = PaddingValues(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(chapters, key = { it.id }) { chap ->
                FilterChip(
                    selected = selectedFieldType == chap.fieldType,
                    onClick = { onSelectFieldType(chap.fieldType) },
                    leadingIcon = {
                        Image(
                            painter = painterResource(id = chap.iconRes),
                            contentDescription = null,
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    },
                    label = { Text(chap.categoryName) }
                )
            }
        }

        // Tool Mode Selector
        LazyRow(
            contentPadding = PaddingValues(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = tacticalTool == TacticalTool.PAN_ZOOM,
                    onClick = { onSelectTool(TacticalTool.PAN_ZOOM) },
                    label = { Text(stringResource(R.string.tactical_mode_pan)) }
                )
            }
            item {
                FilterChip(
                    selected = tacticalTool == TacticalTool.FREEHAND_LINE,
                    onClick = { onSelectTool(TacticalTool.FREEHAND_LINE) },
                    label = { Text(stringResource(R.string.tactical_mode_draw)) }
                )
            }
            item {
                FilterChip(
                    selected = tacticalTool == TacticalTool.TACTICAL_ARROW,
                    onClick = { onSelectTool(TacticalTool.TACTICAL_ARROW) },
                    label = { Text(stringResource(R.string.tactical_mode_arrow)) }
                )
            }
            item {
                FilterChip(
                    selected = tacticalTool == TacticalTool.PLACE_PEBBLE,
                    onClick = { onSelectTool(TacticalTool.PLACE_PEBBLE) },
                    label = { Text(stringResource(R.string.tactical_mode_pebble)) }
                )
            }
        }

        // Color Palette & Undo / Redo / Clear Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                palette.forEach { col ->
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(col)
                            .border(
                                width = if (activeColor == col) 3.dp else 1.dp,
                                color = if (activeColor == col) MaterialTheme.colorScheme.primary else Color.Gray,
                                shape = CircleShape
                            )
                            .clickable { onSelectColor(col) }
                    )
                }
            }

            Row {
                IconButton(onClick = onUndo) {
                    Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = stringResource(R.string.tactical_undo))
                }
                IconButton(onClick = onRedo) {
                    Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = stringResource(R.string.tactical_redo))
                }
                IconButton(onClick = onClear) {
                    Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.tactical_clear))
                }
            }
        }

        InteractiveSportFieldCard(
            fieldType = selectedFieldType,
            isAmharic = isAmharic,
            tacticalTool = tacticalTool,
            activeColor = activeColor,
            isDashed = isDashed,
            strokes = strokes,
            pebbles = pebbles,
            onAddStroke = onAddStroke,
            onAddPebble = onAddPebble
        )
    }
}
