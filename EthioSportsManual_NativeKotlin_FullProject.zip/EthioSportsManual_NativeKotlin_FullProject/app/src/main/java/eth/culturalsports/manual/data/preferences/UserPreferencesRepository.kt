package eth.culturalsports.manual.data.preferences

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ethio_sports_user_prefs")

data class UserPreferencesState(
    val languageCode: String = "am",
    val isDarkMode: Boolean = false,
    val useDynamicColors: Boolean = false,
    val fontScale: Float = 1.0f,
    val onboardingCompleted: Boolean = false,
    val privacyAccepted: Boolean = false,
    val lastReadChapterId: Int = 1,
    val lastReadSectionIndex: Int = 0
)

class UserPreferencesRepository(
    private val context: Context
) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language_code")
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val PRIVACY_ACCEPTED = booleanPreferencesKey("privacy_accepted")
        val LAST_CHAPTER_ID = intPreferencesKey("last_chapter_id")
        val LAST_SECTION_IDX = intPreferencesKey("last_section_idx")
    }

    val preferencesFlow: Flow<UserPreferencesState> = context.dataStore.data.map { prefs ->
        UserPreferencesState(
            languageCode = prefs[Keys.LANGUAGE] ?: "am",
            isDarkMode = prefs[Keys.DARK_MODE] ?: false,
            useDynamicColors = prefs[Keys.DYNAMIC_COLOR] ?: false,
            fontScale = prefs[Keys.FONT_SCALE] ?: 1.0f,
            onboardingCompleted = prefs[Keys.ONBOARDING_DONE] ?: false,
            privacyAccepted = prefs[Keys.PRIVACY_ACCEPTED] ?: false,
            lastReadChapterId = prefs[Keys.LAST_CHAPTER_ID] ?: 1,
            lastReadSectionIndex = prefs[Keys.LAST_SECTION_IDX] ?: 0
        )
    }

    private val securePrefs: SharedPreferences by lazy {
        context.getSharedPreferences("official_encrypted_prefs", Context.MODE_PRIVATE)
    }

    suspend fun setLanguage(langCode: String) {
        context.dataStore.edit { it[Keys.LANGUAGE] = langCode }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_MODE] = enabled }
    }

    suspend fun setDynamicColors(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DYNAMIC_COLOR] = enabled }
    }

    suspend fun setFontScale(scale: Float) {
        context.dataStore.edit { it[Keys.FONT_SCALE] = scale.coerceIn(0.85f, 1.45f) }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_DONE] = completed }
    }

    suspend fun setPrivacyAccepted(accepted: Boolean) {
        context.dataStore.edit { it[Keys.PRIVACY_ACCEPTED] = accepted }
    }

    suspend fun saveReadingPosition(chapterId: Int, sectionIndex: Int) {
        context.dataStore.edit {
            it[Keys.LAST_CHAPTER_ID] = chapterId
            it[Keys.LAST_SECTION_IDX] = sectionIndex
        }
    }

    fun saveEncryptedOfficialPin(pin: String) {
        val encoded = Base64.encodeToString(pin.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        securePrefs.edit().putString("official_vault_pin", encoded).apply()
    }

    fun getEncryptedOfficialPin(): String {
        val encoded = securePrefs.getString("official_vault_pin", null) ?: return "1970"
        return try {
            String(Base64.decode(encoded, Base64.NO_WRAP), Charsets.UTF_8)
        } catch (e: Exception) {
            "1970"
        }
    }
}
