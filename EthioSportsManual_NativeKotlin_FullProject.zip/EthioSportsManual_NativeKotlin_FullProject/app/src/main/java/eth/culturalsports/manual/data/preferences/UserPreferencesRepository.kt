package eth.culturalsports.manual.data.preferences

import android.content.Context
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ethio_sports_user_prefs")

data class UserPreferencesState(
    val languageCode: String = "am",
    val isDarkMode: Boolean = false,
    val useDynamicColors: Boolean = false,
    val fontScale: Float = 1.0f,
    val onboardingCompleted: Boolean = false,
    val privacyAccepted: Boolean = false,
    val lastReadChapterId: Int = 1,
    val lastReadSectionIndex: Int = 0
)

@Singleton
class UserPreferencesRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language_code")
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val PRIVACY_ACCEPTED = booleanPreferencesKey("privacy_accepted")
        val LAST_CHAPTER_ID = intPreferencesKey("last_chapter_id")
        val LAST_SECTION_IDX = intPreferencesKey("last_section_idx")
    }

    val preferencesFlow: Flow<UserPreferencesState> = context.dataStore.data.map { prefs ->
        UserPreferencesState(
            languageCode = prefs[Keys.LANGUAGE] ?: "am",
            isDarkMode = prefs[Keys.DARK_MODE] ?: false,
            useDynamicColors = prefs[Keys.DYNAMIC_COLOR] ?: false,
            fontScale = prefs[Keys.FONT_SCALE] ?: 1.0f,
            onboardingCompleted = prefs[Keys.ONBOARDING_DONE] ?: false,
            privacyAccepted = prefs[Keys.PRIVACY_ACCEPTED] ?: false,
            lastReadChapterId = prefs[Keys.LAST_CHAPTER_ID] ?: 1,
            lastReadSectionIndex = prefs[Keys.LAST_SECTION_IDX] ?: 0
        )
    }

    private val encryptedPrefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "official_encrypted_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            context.getSharedPreferences("official_fallback_prefs", Context.MODE_PRIVATE)
        }
    }

    suspend fun setLanguage(langCode: String) {
        context.dataStore.edit { it[Keys.LANGUAGE] = langCode }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_MODE] = enabled }
    }

    suspend fun setDynamicColors(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DYNAMIC_COLOR] = enabled }
    }

    suspend fun setFontScale(scale: Float) {
        context.dataStore.edit { it[Keys.FONT_SCALE] = scale.coerceIn(0.85f, 1.45f) }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_DONE] = completed }
    }

    suspend fun setPrivacyAccepted(accepted: Boolean) {
        context.dataStore.edit { it[Keys.PRIVACY_ACCEPTED] = accepted }
    }

    suspend fun saveReadingPosition(chapterId: Int, sectionIndex: Int) {
        context.dataStore.edit {
            it[Keys.LAST_CHAPTER_ID] = chapterId
            it[Keys.LAST_SECTION_IDX] = sectionIndex
        }
    }

    fun saveEncryptedOfficialPin(pin: String) {
        encryptedPrefs.edit().putString("official_vault_pin", pin).apply()
    }

    fun getEncryptedOfficialPin(): String {
        return encryptedPrefs.getString("official_vault_pin", "1970") ?: "1970"
    }
}
