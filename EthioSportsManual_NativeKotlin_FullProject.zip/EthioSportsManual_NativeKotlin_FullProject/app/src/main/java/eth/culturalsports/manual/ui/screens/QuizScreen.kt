package eth.culturalsports.manual.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import eth.culturalsports.manual.R
import eth.culturalsports.manual.domain.model.QuizQuestion

@Composable
fun QuizScreen(
    categories: List<String>,
    selectedCategoryIndex: Int,
    questions: List<QuizQuestion>,
    currentQuestionIndex: Int,
    answersMap: Map<Int, Int>,
    onSelectCategory: (Int) -> Unit,
    onSelectOption: (Int, Int) -> Unit,
    onNextQuestion: () -> Unit,
    onPrevQuestion: () -> Unit,
    onRestartQuiz: (String, Int, Int) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    var showResultModal by remember { mutableStateOf(false) }

    val totalQ = questions.size
    val currentQ = questions.getOrNull(currentQuestionIndex)
    val correctCount = questions.count { q -> answersMap[q.id] == q.correctIndex }
    val activeCategoryName = categories.getOrElse(selectedCategoryIndex) { "" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        // Category Filter Row
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(categories) { idx, catName ->
                FilterChip(
                    selected = idx == selectedCategoryIndex,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelectCategory(idx)
                    },
                    label = { Text(catName) }
                )
            }
        }

        if (currentQ != null) {
            val selectedOpt = answersMap[currentQ.id]

            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${stringResource(R.string.quiz_question_progress)} ${currentQuestionIndex + 1} / $totalQ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${stringResource(R.string.quiz_score_label)}: $correctCount / ${answersMap.size}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = { (currentQuestionIndex + 1).toFloat() / totalQ.coerceAtLeast(1) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Question Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = currentQ.category,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = currentQ.question,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 4 Balanced Options
                currentQ.options.forEachIndexed { optIdx, optText ->
                    val isAnswered = selectedOpt != null
                    val isCorrectOption = optIdx == currentQ.correctIndex
                    val isChosenOption = optIdx == selectedOpt

                    val borderColor = when {
                        !isAnswered -> MaterialTheme.colorScheme.outlineVariant
                        isCorrectOption -> Color(0xFF16A34A)
                        isChosenOption -> Color(0xFFDC2626)
                        else -> MaterialTheme.colorScheme.outlineVariant
                    }
                    val cardBg = when {
                        !isAnswered -> MaterialTheme.colorScheme.surface
                        isCorrectOption -> Color(0xFF16A34A).copy(alpha = 0.14f)
                        isChosenOption -> Color(0xFFDC2626).copy(alpha = 0.14f)
                        else -> MaterialTheme.colorScheme.surface
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .clickable(enabled = !isAnswered) {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onSelectOption(currentQ.id, optIdx)
                            },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(2.dp, borderColor),
                        colors = CardDefaults.cardColors(containerColor = cardBg)
                    ) {
                        Text(
                            text = optText,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = if (isAnswered && (isCorrectOption || isChosenOption)) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }

                // Instant Official Explanation Feedback Box
                if (selectedOpt != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    val isRight = selectedOpt == currentQ.correctIndex
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isRight) Color(0xFF065F46).copy(alpha = 0.15f)
                            else Color(0xFF991B1B).copy(alpha = 0.15f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = stringResource(id = if (isRight) R.string.quiz_correct_badge else R.string.quiz_wrong_badge),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isRight) Color(0xFF16A34A) else Color(0xFFDC2626)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = currentQ.explanation,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Prev / Next / Finish Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OutlinedButton(
                        onClick = onPrevQuestion,
                        enabled = currentQuestionIndex > 0
                    ) {
                        Text(text = stringResource(R.string.quiz_prev))
                    }

                    if (currentQuestionIndex + 1 < totalQ) {
                        Button(onClick = onNextQuestion) {
                            Text(text = stringResource(R.string.quiz_next))
                        }
                    } else {
                        Button(onClick = { showResultModal = true }) {
                            Text(text = stringResource(R.string.quiz_finish))
                        }
                    }
                }
            }
        }
    }

    if (showResultModal) {
        val pct = if (totalQ > 0) (correctCount * 100) / totalQ else 0
        AlertDialog(
            onDismissRequest = { showResultModal = false },
            title = {
                Text(
                    text = stringResource(R.string.quiz_result_title),
                    fontWeight = FontWeight.ExtraBold
                )
            },
            text = {
                Column {
                    Text(
                        text = "$correctCount / $totalQ ($pct%)",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(id = if (pct >= 70) R.string.quiz_pass_msg else R.string.quiz_review_msg),
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResultModal = false
                        onRestartQuiz(activeCategoryName, correctCount, totalQ)
                    }
                ) {
                    Text(text = stringResource(R.string.quiz_restart))
                }
            }
        )
    }
}
