package eth.culturalsports.manual.di

import android.content.Context
import androidx.room.Room
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import eth.culturalsports.manual.data.local.BookmarkDao
import eth.culturalsports.manual.data.local.ManualDatabase
import eth.culturalsports.manual.data.local.OfficialNoteDao
import eth.culturalsports.manual.data.local.QuizScoreDao
import eth.culturalsports.manual.data.repository.ManualRepositoryImpl
import eth.culturalsports.manual.domain.repository.ManualRepository
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryBindingModule {
    @Binds
    @Singleton
    abstract fun bindManualRepository(impl: ManualRepositoryImpl): ManualRepository
}

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun provideManualDatabase(@ApplicationContext context: Context): ManualDatabase {
        return Room.databaseBuilder(
            context,
            ManualDatabase::class.java,
            "ethio_cultural_sports_manual.db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    fun provideBookmarkDao(db: ManualDatabase): BookmarkDao = db.bookmarkDao()

    @Provides
    fun provideQuizScoreDao(db: ManualDatabase): QuizScoreDao = db.quizScoreDao()

    @Provides
    fun provideOfficialNoteDao(db: ManualDatabase): OfficialNoteDao = db.officialNoteDao()
}
