package eth.culturalsports.manual

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.StarRate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import eth.culturalsports.manual.ui.components.EthioSplashScreen
import eth.culturalsports.manual.ui.components.OnboardingScreen
import eth.culturalsports.manual.ui.components.PrivacyPolicyBeautifulModal
import eth.culturalsports.manual.ui.components.PrivacyPolicyMandatoryDialog
import eth.culturalsports.manual.ui.components.findActivity
import eth.culturalsports.manual.ui.components.launchExternalUrl
import eth.culturalsports.manual.ui.screens.AboutAndContactScreen
import eth.culturalsports.manual.ui.screens.ChapterDetailScreen
import eth.culturalsports.manual.ui.screens.HomeScreen
import eth.culturalsports.manual.ui.screens.QuizScreen
import eth.culturalsports.manual.ui.screens.SearchScreen
import eth.culturalsports.manual.ui.screens.TacticalBoardScreen
import eth.culturalsports.manual.ui.theme.EthioSportsManualTheme
import eth.culturalsports.manual.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MainViewModel = viewModel(factory = MainViewModel.provideFactory(this@MainActivity))
            val prefs by viewModel.userPrefs.collectAsState()

            val baseContext = LocalContext.current
            val localizedContext = remember(prefs.languageCode, baseContext) {
                baseContext.createLocalizedContext(prefs.languageCode)
            }

            CompositionLocalProvider(LocalContext provides localizedContext) {
                EthioSportsManualTheme(
                    darkTheme = prefs.isDarkMode,
                    dynamicColor = prefs.useDynamicColors,
                    fontScale = prefs.fontScale
                ) {
                    EthioSportsRootApp(
                        viewModel = viewModel,
                        onExitApp = { finish() }
                    )
                }
            }
        }
    }
}

private fun Context.createLocalizedContext(languageCode: String): Context {
    val locale = Locale(languageCode)
    Locale.setDefault(locale)
    val config = Configuration(resources.configuration)
    config.setLocale(locale)
    return createConfigurationContext(config)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EthioSportsRootApp(
    viewModel: MainViewModel,
    onExitApp: () -> Unit
) {
    val prefs by viewModel.userPrefs.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val selectedCategoryIdx by viewModel.selectedCategoryIndex.collectAsState()
    val allChapters by viewModel.allChapters.collectAsState()
    val filteredChapters by viewModel.filteredChapters.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.debouncedSearchResults.collectAsState()
    val selectedQuizCatIdx by viewModel.selectedQuizCategoryIndex.collectAsState()
    val filteredQuizzes by viewModel.filteredQuizzes.collectAsState()
    val currentQuizIdx by viewModel.currentQuizIndex.collectAsState()
    val quizAnswersMap by viewModel.quizAnswersMap.collectAsState()
    val selectedFieldType by viewModel.selectedFieldType.collectAsState()
    val tacticalTool by viewModel.tacticalTool.collectAsState()
    val tacticalColor by viewModel.tacticalColor.collectAsState()
    val isDashed by viewModel.isDashedStroke.collectAsState()
    val strokes by viewModel.strokes.collectAsState()
    val pebbles by viewModel.pebbles.collectAsState()
    val officialNotes by viewModel.officialNotes.collectAsState()

    var showSplash by remember { mutableStateOf(true) }
    var currentBottomTab by remember { mutableIntStateOf(0) }
    var activeChapterId by remember { mutableStateOf<Int?>(null) }
    var activeSectionIdx by remember { mutableIntStateOf(0) }
    var showExitConfirmation by remember { mutableStateOf(false) }
    var showDrawerPrivacyModal by remember { mutableStateOf(false) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current

    if (showSplash) {
        EthioSplashScreen(onSplashFinished = { showSplash = false })
        return
    }

    if (!prefs.onboardingCompleted) {
        OnboardingScreen(
            currentLanguage = prefs.languageCode,
            onSelectLanguage = { viewModel.setLanguage(it) },
            onFinishOnboarding = { viewModel.completeOnboarding() }
        )
        return
    }

    if (!prefs.privacyAccepted) {
        PrivacyPolicyMandatoryDialog(
            onAccept = { viewModel.acceptPrivacyPolicy() }
        )
    }

    BackHandler {
        when {
            drawerState.isOpen -> scope.launch { drawerState.close() }
            activeChapterId != null -> activeChapterId = null
            currentBottomTab != 0 -> currentBottomTab = 0
            else -> showExitConfirmation = true
        }
    }

    val openedChapter = activeChapterId?.let { id -> allChapters.find { it.id == id } }
    if (openedChapter != null) {
        val isBookmarked = bookmarks.any { it.chapterId == openedChapter.id }
        ChapterDetailScreen(
            chapter = openedChapter,
            initialSectionIndex = activeSectionIdx,
            isAmharic = prefs.languageCode == "am",
            isBookmarked = isBookmarked,
            onBack = { activeChapterId = null },
            onToggleBookmark = { viewModel.toggleBookmark(openedChapter.id, activeSectionIdx) },
            onOpenTacticalBoard = {
                viewModel.selectFieldType(openedChapter.fieldType)
                activeChapterId = null
                currentBottomTab = 3
            }
        )
        return
    }

    val appTitle = stringResource(id = R.string.app_name)

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_federation_logo),
                            contentDescription = stringResource(id = R.string.cd_federation_logo),
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(id = R.string.app_name),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = stringResource(id = R.string.about_us_header),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                HorizontalDivider()

                NavigationDrawerItem(
                    label = { Text(stringResource(id = R.string.nav_home)) },
                    selected = currentBottomTab == 0,
                    icon = { Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null) },
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        currentBottomTab = 0
                        scope.launch { drawerState.close() }
                    }
                )
                NavigationDrawerItem(
                    label = { Text(stringResource(id = R.string.nav_quiz)) },
                    selected = currentBottomTab == 2,
                    icon = { Icon(Icons.Default.Quiz, contentDescription = null) },
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        currentBottomTab = 2
                        scope.launch { drawerState.close() }
                    }
                )
                NavigationDrawerItem(
                    label = { Text(stringResource(id = R.string.nav_tactical)) },
                    selected = currentBottomTab == 3,
                    icon = { Icon(Icons.Default.SportsSoccer, contentDescription = null) },
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        currentBottomTab = 3
                        scope.launch { drawerState.close() }
                    }
                )
                NavigationDrawerItem(
                    label = { Text(stringResource(id = R.string.nav_about)) },
                    selected = currentBottomTab == 4,
                    icon = { Icon(Icons.Default.Info, contentDescription = null) },
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        currentBottomTab = 4
                        scope.launch { drawerState.close() }
                    }
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                NavigationDrawerItem(
                    label = {
                        Text(
                            "${stringResource(id = R.string.drawer_language)}: " +
                                if (prefs.languageCode == "am") stringResource(R.string.lang_english)
                                else stringResource(R.string.lang_amharic)
                        )
                    },
                    selected = false,
                    icon = { Icon(Icons.Default.Language, contentDescription = null) },
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.toggleLanguage()
                    }
                )

                NavigationDrawerItem(
                    label = { Text(stringResource(id = R.string.dark_mode_label)) },
                    selected = prefs.isDarkMode,
                    icon = {
                        Icon(
                            if (prefs.isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = null
                        )
                    },
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.toggleDarkMode()
                    }
                )

                NavigationDrawerItem(
                    label = { Text(stringResource(id = R.string.drawer_privacy_policy)) },
                    selected = false,
                    icon = { Icon(Icons.Default.PrivacyTip, contentDescription = null) },
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        scope.launch { drawerState.close() }
                        showDrawerPrivacyModal = true
                    }
                )

                NavigationDrawerItem(
                    label = { Text(stringResource(id = R.string.drawer_share_app)) },
                    selected = false,
                    icon = { Icon(Icons.Default.Share, contentDescription = null) },
                    onClick = {
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            setType("text/plain")
                            putExtra(Intent.EXTRA_SUBJECT, appTitle)
                            putExtra(Intent.EXTRA_TEXT, "$appTitle - https://play.google.com/store/apps/details?id=eth.culturalsports.manual")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        val chooser = Intent.createChooser(sendIntent, appTitle).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        val activity = context.findActivity()
                        runCatching {
                            if (activity != null) activity.startActivity(chooser)
                            else context.startActivity(chooser)
                        }
                        scope.launch { drawerState.close() }
                    }
                )

                NavigationDrawerItem(
                    label = { Text(stringResource(id = R.string.drawer_rate_app)) },
                    selected = false,
                    icon = { Icon(Icons.Default.StarRate, contentDescription = null) },
                    onClick = {
                        launchExternalUrl(context, "https://play.google.com/store/apps/details?id=eth.culturalsports.manual")
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = stringResource(id = R.string.app_name),
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                scope.launch { drawerState.open() }
                            }
                        ) {
                            Icon(Icons.Default.Menu, contentDescription = null)
                        }
                    },
                    actions = {
                        TextButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.toggleLanguage()
                            }
                        ) {
                            Text(
                                text = if (prefs.languageCode == "am") "EN" else "አማ",
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.toggleDarkMode()
                            }
                        ) {
                            Icon(
                                imageVector = if (prefs.isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = stringResource(id = R.string.dark_mode_label)
                            )
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentBottomTab == 0,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            currentBottomTab = 0
                        },
                        icon = { Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = stringResource(R.string.nav_home)) },
                        label = { Text(stringResource(R.string.nav_home), maxLines = 1) }
                    )
                    NavigationBarItem(
                        selected = currentBottomTab == 1,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            currentBottomTab = 1
                        },
                        icon = { Icon(Icons.Default.Search, contentDescription = stringResource(R.string.nav_search)) },
                        label = { Text(stringResource(R.string.nav_search), maxLines = 1) }
                    )
                    NavigationBarItem(
                        selected = currentBottomTab == 2,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            currentBottomTab = 2
                        },
                        icon = { Icon(Icons.Default.Quiz, contentDescription = stringResource(R.string.nav_quiz)) },
                        label = { Text(stringResource(R.string.nav_quiz), maxLines = 1) }
                    )
                    NavigationBarItem(
                        selected = currentBottomTab == 3,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            currentBottomTab = 3
                        },
                        icon = { Icon(Icons.Default.SportsSoccer, contentDescription = stringResource(R.string.nav_tactical)) },
                        label = { Text(stringResource(R.string.nav_tactical), maxLines = 1) }
                    )
                    NavigationBarItem(
                        selected = currentBottomTab == 4,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            currentBottomTab = 4
                        },
                        icon = { Icon(Icons.Default.Info, contentDescription = stringResource(R.string.nav_about)) },
                        label = { Text(stringResource(R.string.nav_about), maxLines = 1) }
                    )
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentBottomTab) {
                    0 -> HomeScreen(
                        categories = categories,
                        selectedCategoryIndex = selectedCategoryIdx,
                        chapters = filteredChapters,
                        bookmarks = bookmarks,
                        fontScale = prefs.fontScale,
                        onSelectCategory = { viewModel.selectCategory(it) },
                        onOpenChapter = { chapId ->
                            viewModel.saveLastRead(chapId, 0)
                            activeSectionIdx = 0
                            activeChapterId = chapId
                        },
                        onToggleBookmark = { viewModel.toggleBookmark(it) },
                        onFontScaleChange = { viewModel.updateFontScale(it) }
                    )
                    1 -> SearchScreen(
                        searchQuery = searchQuery,
                        results = searchResults,
                        onQueryChange = { viewModel.updateSearchQuery(it) },
                        onOpenResult = { chapId, secIdx ->
                            viewModel.saveLastRead(chapId, secIdx)
                            activeSectionIdx = secIdx
                            activeChapterId = chapId
                        }
                    )
                    2 -> QuizScreen(
                        categories = categories,
                        selectedCategoryIndex = selectedQuizCatIdx,
                        questions = filteredQuizzes,
                        currentQuestionIndex = currentQuizIdx,
                        answersMap = quizAnswersMap,
                        onSelectCategory = { viewModel.selectQuizCategory(it) },
                        onSelectOption = { qId, optIdx -> viewModel.answerQuizQuestion(qId, optIdx) },
                        onNextQuestion = { viewModel.nextQuizQuestion(filteredQuizzes.size) },
                        onPrevQuestion = { viewModel.prevQuizQuestion() },
                        onRestartQuiz = { cat, score, total -> viewModel.resetQuizSession(cat, score, total) }
                    )
                    3 -> TacticalBoardScreen(
                        chapters = allChapters,
                        selectedFieldType = selectedFieldType,
                        tacticalTool = tacticalTool,
                        activeColor = tacticalColor,
                        isDashed = isDashed,
                        strokes = strokes,
                        pebbles = pebbles,
                        isAmharic = prefs.languageCode == "am",
                        onSelectFieldType = { viewModel.selectFieldType(it) },
                        onSelectTool = { viewModel.setTacticalTool(it) },
                        onSelectColor = { viewModel.setTacticalColor(it) },
                        onAddStroke = { viewModel.addTacticalStroke(it) },
                        onAddPebble = { viewModel.addTacticalPebble(it) },
                        onUndo = { viewModel.undoTactical() },
                        onRedo = { viewModel.redoTactical() },
                        onClear = { viewModel.clearTacticalBoard() }
                    )
                    4 -> AboutAndContactScreen(
                        officialNotes = officialNotes,
                        onAddOfficialNote = { title, body -> viewModel.addOfficialNote(title, body) },
                        onDeleteOfficialNote = { viewModel.deleteOfficialNote(it) }
                    )
                }
            }
        }
    }

    if (showDrawerPrivacyModal) {
        PrivacyPolicyBeautifulModal(
            isMandatoryFirstLaunch = false,
            onAcceptOrClose = { showDrawerPrivacyModal = false }
        )
    }

    if (showExitConfirmation) {
        AlertDialog(
            onDismissRequest = { showExitConfirmation = false },
            title = { Text(stringResource(id = R.string.exit_dialog_title), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(id = R.string.exit_dialog_message)) },
            confirmButton = {
                Button(onClick = onExitApp) {
                    Text(stringResource(id = R.string.exit_confirm))
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showExitConfirmation = false }) {
                    Text(stringResource(id = R.string.exit_cancel))
                }
            }
        )
    }
}
