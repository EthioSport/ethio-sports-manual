package eth.culturalsports.manual.data.local

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

data class BookmarkEntity(
    val chapterId: Int,
    val sectionIndex: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

data class QuizScoreEntity(
    val id: Int = 0,
    val category: String,
    val score: Int,
    val totalQuestions: Int,
    val timestamp: Long = System.currentTimeMillis()
)

data class OfficialNoteEntity(
    val id: Int = 0,
    val title: String,
    val encryptedContent: String,
    val timestamp: Long = System.currentTimeMillis()
)

interface BookmarkDao {
    fun observeBookmarks(): Flow<List<BookmarkEntity>>
    suspend fun insertBookmark(bookmark: BookmarkEntity)
    suspend fun removeBookmark(chapterId: Int)
}

interface QuizScoreDao {
    fun observeRecentScores(): Flow<List<QuizScoreEntity>>
    suspend fun insertScore(score: QuizScoreEntity)
}

interface OfficialNoteDao {
    fun observeNotes(): Flow<List<OfficialNoteEntity>>
    suspend fun insertNote(note: OfficialNoteEntity)
    suspend fun deleteNote(note: OfficialNoteEntity)
}

class ManualDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "ethio_cultural_sports_manual.db", null, 1),
    BookmarkDao,
    QuizScoreDao,
    OfficialNoteDao {

    private val bookmarksFlow = MutableStateFlow<List<BookmarkEntity>>(emptyList())
    private val scoresFlow = MutableStateFlow<List<QuizScoreEntity>>(emptyList())
    private val notesFlow = MutableStateFlow<List<OfficialNoteEntity>>(emptyList())

    init {
        refreshAll()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS bookmarks (chapterId INTEGER PRIMARY KEY, sectionIndex INTEGER NOT NULL, timestamp INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS quiz_scores (id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, score INTEGER NOT NULL, totalQuestions INTEGER NOT NULL, timestamp INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS official_notes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, encryptedContent TEXT NOT NULL, timestamp INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onCreate(db)
    }

    private fun refreshAll() {
        bookmarksFlow.value = queryBookmarksInternal()
        scoresFlow.value = queryScoresInternal()
        notesFlow.value = queryNotesInternal()
    }

    private fun queryBookmarksInternal(): List<BookmarkEntity> {
        val list = mutableListOf<BookmarkEntity>()
        readableDatabase.rawQuery("SELECT chapterId, sectionIndex, timestamp FROM bookmarks ORDER BY timestamp DESC", null).use { c ->
            while (c.moveToNext()) {
                list.add(BookmarkEntity(c.getInt(0), c.getInt(1), c.getLong(2)))
            }
        }
        return list
    }

    private fun queryScoresInternal(): List<QuizScoreEntity> {
        val list = mutableListOf<QuizScoreEntity>()
        readableDatabase.rawQuery("SELECT id, category, score, totalQuestions, timestamp FROM quiz_scores ORDER BY timestamp DESC LIMIT 20", null).use { c ->
            while (c.moveToNext()) {
                list.add(QuizScoreEntity(c.getInt(0), c.getString(1), c.getInt(2), c.getInt(3), c.getLong(4)))
            }
        }
        return list
    }

    private fun queryNotesInternal(): List<OfficialNoteEntity> {
        val list = mutableListOf<OfficialNoteEntity>()
        readableDatabase.rawQuery("SELECT id, title, encryptedContent, timestamp FROM official_notes ORDER BY timestamp DESC", null).use { c ->
            while (c.moveToNext()) {
                list.add(OfficialNoteEntity(c.getInt(0), c.getString(1), c.getString(2), c.getLong(3)))
            }
        }
        return list
    }

    override fun observeBookmarks(): Flow<List<BookmarkEntity>> = bookmarksFlow.asStateFlow()

    override suspend fun insertBookmark(bookmark: BookmarkEntity) {
        withContext(Dispatchers.IO) {
            val cv = ContentValues().apply {
                put("chapterId", bookmark.chapterId)
                put("sectionIndex", bookmark.sectionIndex)
                put("timestamp", bookmark.timestamp)
            }
            writableDatabase.insertWithOnConflict("bookmarks", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            bookmarksFlow.value = queryBookmarksInternal()
        }
    }

    override suspend fun removeBookmark(chapterId: Int) {
        withContext(Dispatchers.IO) {
            writableDatabase.delete("bookmarks", "chapterId = ?", arrayOf(chapterId.toString()))
            bookmarksFlow.value = queryBookmarksInternal()
        }
    }

    override fun observeRecentScores(): Flow<List<QuizScoreEntity>> = scoresFlow.asStateFlow()

    override suspend fun insertScore(score: QuizScoreEntity) {
        withContext(Dispatchers.IO) {
            val cv = ContentValues().apply {
                put("category", score.category)
                put("score", score.score)
                put("totalQuestions", score.totalQuestions)
                put("timestamp", score.timestamp)
            }
            writableDatabase.insertWithOnConflict("quiz_scores", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            scoresFlow.value = queryScoresInternal()
        }
    }

    override fun observeNotes(): Flow<List<OfficialNoteEntity>> = notesFlow.asStateFlow()

    override suspend fun insertNote(note: OfficialNoteEntity) {
        withContext(Dispatchers.IO) {
            val cv = ContentValues().apply {
                put("title", note.title)
                put("encryptedContent", note.encryptedContent)
                put("timestamp", note.timestamp)
            }
            writableDatabase.insertWithOnConflict("official_notes", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            notesFlow.value = queryNotesInternal()
        }
    }

    override suspend fun deleteNote(note: OfficialNoteEntity) {
        withContext(Dispatchers.IO) {
            writableDatabase.delete("official_notes", "id = ?", arrayOf(note.id.toString()))
            notesFlow.value = queryNotesInternal()
        }
    }

    fun bookmarkDao(): BookmarkDao = this
    fun quizScoreDao(): QuizScoreDao = this
    fun officialNoteDao(): OfficialNoteDao = this

    companion object {
        @Volatile
        private var INSTANCE: ManualDatabase? = null

        fun getInstance(context: Context): ManualDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ManualDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
