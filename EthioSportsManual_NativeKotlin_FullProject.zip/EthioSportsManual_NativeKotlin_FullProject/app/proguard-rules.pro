# ProGuard / R8 Rules for Ethio-Sports Rulebook (eth.culturalsports.manual)
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Keep Room Database entities and DAOs
-keep class eth.culturalsports.manual.data.local.** { *; }
-keep class eth.culturalsports.manual.domain.model.** { *; }

# Keep Hilt generated classes
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }

# Keep Compose & Lottie classes
-keep class com.airbnb.lottie.** { *; }
-dontwarn com.google.crypto.tink.**
