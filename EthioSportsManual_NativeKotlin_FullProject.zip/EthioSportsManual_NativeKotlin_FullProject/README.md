# ኢትዮ-ስፖርት ደንብ (Ethio-Sports Rulebook) — ሙሉ የአንድሮይድ ፕሮጀክት እና በሞባይል የGitHub Actions አውቶማቲክ ግንባታ መመሪያ

ይህ ሰነድ የኢትዮጵያ ባህል ስፖርቶች ፌዴሬሽንን የተሻሻለው የውድድር ህግና ደንብ ማንዋል ወደ **100% Native Kotlin (Jetpack Compose + Material 3 + Clean Architecture)** የተቀየረውን ሙሉ የአንድሮይድ ፕሮጀክት በስልክዎ ብቻ በመጠቀም በGitHub Actions እንዴት ወደ **`.apk`** እና **`.aab`** እንደሚቀይሩ በቅደም ተከተል ያብራራል።

---

## 1. የፕሮጀክቱ መሰረታዊ መለያዎች (Core Project Configuration)

| መለያ (Parameter) | የተዋቀረው ዋጋ (Configured Value) |
| :--- | :--- |
| **App Name (አማርኛ / እንግሊዝኛ)** | `ኢትዮ-ስፖርት ደንብ` / `Ethio-Sports Rulebook` |
| **Package Name / Application ID** | `eth.culturalsports.manual` |
| **Version Code / Version Name** | `versionCode = 1` / `versionName = "1.0.0"` |
| **Compile SDK / Target SDK / Min SDK** | `compileSdk = 36` / `targetSdk = 36` / `minSdk = 23` |
| **GitHub Organization / Username** | `EthioSport` |
| **GitHub Repository Name** | `ethio-sports-manual` |
| **Architecture** | 100% Native Kotlin, MVVM/Clean Architecture, Hilt DI, Room DB, DataStore, EncryptedSharedPreferences, Zero WebView, Zero Internet Permission |

---

## 2. በሞባይል ስልክ ብቻ በGitHub Actions `.apk` እና `.aab` የመገንባት ቅደም ተከተል

### ደረጃ 1፦ በGitHub ላይ አዲስ Repository መፍጠር
1. በስልክዎ ብራውዘር (Chrome) ወደ **https://github.com** ይግቡና በ`EthioSport` አካውንትዎ Sign in ያድርጉ።
2. **New Repository** የሚለውን ይጫኑ።
3. **Repository name** ላይ፦ `ethio-sports-manual` ብለው ይጻፉ።
4. **Public** ወይም **Private** መርጠው **Create repository** የሚለውን ይጫኑ።

### ደረጃ 2፦ የፕሮጀክቱን ፋይሎች ወደ GitHub መጫን (Upload)
1. ከዚህ መልዕክት ጋር የተሰጠዎትን **`EthioSportsManual_NativeKotlin_FullProject.zip`** ፋይል ወደ ስልክዎ ያውርዱና በስልክዎ የፋይል መክፈቻ (Files / ZArchiver) **Extract (Unzip)** ያድርጉት።
2. በውስጡ ያሉትን ፋይሎችና ፎልደሮች (`app/`, `gradle/`, `.github/workflows/android.yml`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `PRIVACY_POLICY.md`) ወደ `EthioSport/ethio-sports-manual` Repository **Upload files** በማድረግ **Commit changes** ይበሉ።
   * **ጠቃሚ ምክር፦** በሞባይል ብራውዘር ላይ `.github` የሚለው ፎልደር ከተደበቀ፣ በGitHub Repository ገጽዎ ላይ **Actions ➔ New workflow ➔ set up a workflow yourself** የሚለውን ነክተው የተሰጠዎትን `android.yml` ፋይል ኮድ በቀጥታ እዚያ ውስጥ Paste አድርገው Commit ማድረግ ይችላሉ።

### ደረጃ 3፦ የSigning Secrets በGitHub Repository ላይ ማስገባት
በGoogle Play Console ላይ የሚጫን የተፈረመ (Signed) `.aab` እና `.apk` ለማውጣት፦
1. በRepository ገጽዎ ላይ **Settings ➔ Secrets and variables ➔ Actions** ውስጥ ይግቡ።
2. **New repository secret** የሚለውን እየተጫኑ የሚከተሉትን 4 ሚስጢራዊ መረጃዎች (Secrets) ያስገቡ፦
   * **`KEY_ALIAS`** ➔ የKeystoreዎትን Alias ስም ያስገቡ።
   * **`KEYSTORE_BASE64`** ➔ የ`.jks` ወይም `.keystore` ፋይልዎን ወደ Base64 የቀየሩትን ረጅም ጽሑፍ ያስገቡ።
   * **`KEY_PASSWORD`** ➔ የKey ይለፍ ቃልዎን ያስገቡ።
   * **`STORE_PASSWORD`** ➔ የKeystore ይለፍ ቃልዎን ያስገቡ።
   *(ማስታወሻ፦ እነዚህን Secrets ገና ባያስገቡ እንኳ ግንባታው እንዳይቋረጥ `android.yml` በራስ-ሰር የመጠባበቂያ መፈረሚያ ቁልፍ በመፍጠር `.apk` እና `.aab` እንዲያወጣ ተደርጎ ተገንብቷል!)*

### ደረጃ 4፦ ግንባታውን ማስጀመር እና `.apk` / `.aab` ማውረድ
1. በRepository ገጽዎ ላይ **Actions** የሚለውን ትር (Tab) ይጫኑ።
2. **Ethio-Sports Rulebook Android CI/CD (APK & AAB)** የሚለውን መርጠው **Run workflow** ይበሉት።
3. ከ3 እስከ 5 ደቂቃ ውስጥ ግንባታው አረንጓዴ ምልክት (✅) ሲያሳይ ወደ ውስጡ ይግቡና ከታች **Artifacts** በሚለው ክፍል ስር፦
   * **`EthioSportsManual-v1.0.0-Release-APK`** (በቀጥታ ስልክ ላይ የሚጫን የተፈረመ Release `.apk`)
   * **`EthioSportsManual-v1.0.0-PlayStore-AAB`** (በቀጥታ Google Play Console ላይ የሚጫን `.aab` Bundle)
   * **`EthioSportsManual-v1.0.0-Debug-APK`** (የሙከራ Debug `.apk`)
   አውርደው መጠቀም ይችላሉ!

---

## 3. በመተግበሪያው ውስጥ የተካተቱት ዋና ማሻሻያዎች እና 30 ፕሪሚየም ገጽታዎች ማረጋገጫ

1. **100% የተሟላ ማንዋል እና 25 ኦፊሴላዊ የውድድር ማወዳደሪያ ቅጽ ሰንጠረዦች፦**
   * ከ`የተሻሻለው ህግና ደንብ ማንዋል.docx` እና ከHTML ማንዋሉ የተገኙት ሁሉም 14 ምዕራፎች (ከመግቢያ፣ የባህል ስፖርት ምንነት፣ ታሪክና የዳኞች ስነ-ምግባር እስከ ገና፣ ትግል፣ ኩርቦ፣ ቅንጭቦሽ፣ ስሉስ፣ ሻህ፣ ቡብ፣ ፈረስ ጉግስ፣ ፈረስ ሽርጥ፣ ሁርቤ፣ ቀስት እና የባህል ስፖርት ፌስቲቫል የስልጠና መመሪያ) እንዲሁም በእያንዳንዱ ስፖርት መጨረሻ ላይ ያሉት **ኦፊሴላዊ የውድድር ማወዳደሪያና የውጤት መመዝገቢያ ቅጽ ሰንጠረዦች** በNative Jetpack Compose Table ተካትተዋል።
2. **100% የቋንቋ ንጽህና (Zero Foreign Script Mixing)፦**
   * በ`res/values-am/strings.xml` (2,673 የአማርኛ ሪሶርሶች) ውስጥ አንድም የእንግሊዝኛ ቃል አልተቀላቀለም፤ በ`res/values/strings.xml` (2,673 የእንግሊዝኛ ሪሶርሶች) ውስጥም አንድም የአማርኛ ፊደል አልተቀላቀለም።
3. **390 የተመጣጠኑ የብቃት ምዘና ጥያቄዎች (195 አማርኛ + 195 እንግሊዝኛ)፦**
   * ትክክለኛ መልሶቹ በ`ሀ` (49)፣ `ለ` (50)፣ `ሐ` (48) እና `መ` (48) ላይ እኩል ተሰራጭተዋል፤ ተከታታይ የፊደል ድግግሞሽ የለም፤ እንዲሁም ትክክለኛ መልስ ያልሆኑት ምርጫዎች ከትክክለኛው መልስ ጋር ተመጣጣኝ ርዝመትና ሙያዊ ይዘት እንዲኖራቸው ተደርገዋል።
4. **12 Native Vector / Compose Canvas የሜዳና የቦርድ ስዕሎች፦**
   * ሁሉም የስፖርት ሜዳዎችና ቦርዶች በNative Compose Canvas በሁለት ጣት እየጎሉ (Pinch-to-Zoom & Pan) እንዲታዩና አሰልጣኞች/ዳኞች በላያቸው ላይ መስመር፣ ቀስትና ጠጠር እያስቀመጡ እንዲያስተምሩባቸው ተደርገው ተገንብተዋል።
5. **የፌዴሬሽኑ ኦፊሴላዊ መረጃዎች (About Us & Contact Us)፦**
   * የተሰጠው ኦፊሴላዊ `Logo.png` ሳይቆረጥና ቀለሙ ሳይቀየር፣ ከፌዴሬሽኑ ታሪክ፣ ራዕይ፣ ተልዕኮ፣ እሴቶች፣ የኢሜይል (`eth.culturalsportsfed.1977@gmail.com`)፣ የቴሌግራም (`@EthiopianculturalsportFDE`)፣ የፌስቡክ (`https://www.facebook.com/profile.php?id=61558619311072`) እና የቢሮ አድራሻ (`📍 አዲስ አበባ ስታዲየም ከቤተዛታ ሆስፒታል ጎን OBS ህንፃ 4ኛ ፎቅ ቢሮ ቁጥር 406`) ጋር በትክክል ተካትቷል።
