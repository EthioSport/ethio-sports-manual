# የኢትዮጵያ ባህል ስፖርቶች ማንዋል (ኢትዮ-ስፖርት ደንብ v1.1.0) — የተሟላ የማሻሻያ፣ የGitHub አስተቃቀም እና የግንባታ መመሪያ

ይህ መመሪያ በ**ኢትዮጵያ ባህል ስፖርቶች ፌዴሬሽን** የሞባይል መተግበሪያ (**ኢትዮ-ስፖርት ደንብ v1.1.0**) ላይ የተደረጉትን ማሻሻያዎች እና አዲሱን የፕሮጀክት ZIP ፋይል በGitHub ላይ በመጫን **Release APK**፣ **Play Store AAB** እና **GitHub Pages Privacy Policy** እንዴት በቀላሉ ማግኘት እንደሚቻል በደረጃ ያብራራል።

## 1. በመተግበሪያው (v1.1.0) ላይ የተከናወኑ ዋና ዋና ማሻሻያዎች

1. **ነባሩ ኮድና ባህሪያት ሙሉ በሙሉ ተጠብቀዋል**፦
   - ሁሉም 13 የስፖርት ምዕራፎች፣ 390 የራስ መፈተሻ ጥያቄዎች፣ የሁለት ቋንቋ ድጋፍ (አማርኛ እና እንግሊዝኛ)፣ የድምጽ ንባብ (TTS)፣ ዕልባቶች እና የውድድር ውጤት መመዝገቢያ ቅጾች ሳይነኩ ቀጥለዋል።
2. **የ«ስለ እኛ» (About Us) ገጽ ማሻሻያ እና የማህበራዊ ሚዲያ ሊንኮች ማስተካከያ**፦
   - በ«ስለ እኛ» ገጽ ላይ የነበረው አላስፈላጊ የማስታወሻ ቮልት (Biometric Vault) እና ተጨማሪ ሳጥን ተወግዷል።
   - የኢሜይል (`eth.culturalsportsfed.1977@gmail.com`)፣ የቴሌግራም (`@EthiopianculturalsportFDE`) እና የፌስቡክ (`https://www.facebook.com/profile.php?id=61558619311072`) ሊንኮች ሲነኩ ወዲያውኑ ወደ ኢሜይል፣ ቴሌግራም እና ፌስቡክ እንዲያስወነጭፉ ተደርገው ተስተካክለዋል።
3. **«በኦፊሴላዊ / ኦፊሴላዊ / ኦፍሲያል» የሚሉ ቃላት ሙሉ በሙሉ ተወግደዋል**፦
   - በመተግበሪያው የንባብ ክፍሎች፣ የውጤት መመዝገቢያ ቅጽ ርዕሶች፣ የሜዳ መግለጫዎች እና የ390 ጥያቄዎች ምርጫዎች ውስጥ የነበሩት «በኦፊሴላዊ / ኦፊሴላዊ / ኦፍሲያል» የሚሉ ቃላት በሙሉ ተነስተዋል።
4. **የሁሉም ስፖርቶች ክብ አይከኖች (`icon.png`)፣ የሜዳ ንድፎች (`SVG.png`) እና የውድድር ፎቶዎች ተካትተዋል**፦
   - በንባብ ክፍል (Home Screen)፣ በምዕራፍ ርዕሶች፣ በፍለጋ ውጤቶች እና በሜዳዎች መምረጫ ላይ የየስፖርቱ ትክክለኛ ክብ አይከኖች (`icon.png`) እንዲታዩ ተደርጓል።
   - በ«ሜዳዎች» ክፍል እና በየምዕራፉ መጀመሪያ ላይ ልኬቶቹ በሜዳው ላይ የተጻፉባቸውና የተሰመሩባቸው የሜዳ ንድፎች (`SVG.png`) እንዲሁም የስልጠና ሰሌዳ (Coaching Canvas) ተካትተዋል።
   - በ12ቱም የስፖርት ፎልደሮች ውስጥ የተሰቀሉት 26 የውድድርና የቁሳቁስ ፎቶዎች ለአጠቃቀም ምቹና ፈጣን በሆነ መጠን ተመጣጥነው በየስፖርቱ የንባብ ክፍሎች ውስጥ በየቦታቸው ተካትተዋል (ሲነኩም በሙሉ ስክሪን እየጎሉ ይታያሉ)።
5. **የግላዊነት ፖሊሲ (Privacy Policy) በመተግበሪያው ውስጥ እና በGitHub Pages ላይ**፦
   - በ«ስለ እኛ» ገጽ እና በጎን ማውጫ (Navigation Drawer) ውስጥ **«የግላዊነት ፖሊሲ»** ክፍል ተካቷል።
   - ተጠቃሚዎች ሲነኩት በመተግበሪያው ውስጥ በውብ መልኩ የሚከፍትላቸው ሲሆን፣ **«በድረ-ገጽ ክፈት»** የሚለውን ቁልፍ ሲጫኑ ደግሞ በGitHub Pages ላይ የተጫነውን ድረ-ገጽ (`https://ethiosport.github.io/ethio-sports-manual/privacy-policy.html`) ይከፍታል።

## 2. በGitHub ላይ አዲሱን ኮድ የመጫን እና የመገንባት ቅደም ተከተል

### ደረጃ 1፦ ነባሩን የZIP ፋይል በአዲሱ መተካት
1. ወደ GitHub ሪፖዚቶሪዎ ይግቡ፦ [https://github.com/EthioSport/ethio-sports-manual](https://github.com/EthioSport/ethio-sports-manual)
2. በሪፖዚቶሪው መነሻ ገጽ (Root) ላይ የሚገኘውን ነባሩን `EthioSportsManual_NativeKotlin_FullProject.zip` ፋይል ይሰርዙ (Delete file -> Commit changes)።
3. **Add file** ➔ **Upload files** የሚለውን በመጫን አሁን የተዘጋጀውን አዲሱን **`EthioSportsManual_NativeKotlin_FullProject.zip`** ፋይል ይስቀሉና **Commit changes** ይበሉ።

### ደረጃ 2፦ የYAML ኮዱን (`android.yml`) ማዘመን
1. በሪፖዚቶሪዎ ውስጥ ወደ `.github/workflows/android.yml` ይግቡ።
2. የእርሳስ ምልክቷን (Edit) በመንካት ነባሩን ኮድ ሙሉ በሙሉ አጥፍተው አዲሱን **`android.yml`** ኮድ ይለጥፉና **Commit changes** ይበሉ።

### ደረጃ 3፦ የተገነቡትን APK እና AAB ፋይሎች ማውረድ
1. ከላይ **Actions** የሚለውን ክፍል ይክፈቱ።
2. **Build Native Kotlin APK & Play Store AAB (v1.1.0)** የሚለው ሂደት አረንጓዴ ምልክት (✅) ሲያሳይ ይንኩት።
3. ወደ ታች ወደ **Artifacts** ክፍል ሲወርዱ ሶስቱን ፋይሎች ያገኛሉ፦
   - **`EthioSportsManual-v1.1.0-Release-APK`** — በማንኛውም አንድሮይድ ስልክና ታብሌት ላይ በቀጥታ የሚጫን የተፈረመ (Signed) ፋይል።
   - **`EthioSportsManual-v1.1.0-PlayStore-AAB`** — ለGoogle Play Console የሚሰቀል `.aab` ፋይል።
   - **`EthioSportsManual-v1.1.0-Debug-APK`** — ለሙከራ የሚያገለግል Debug APK።

### ደረጃ 4፦ የግላዊነት ፖሊሲ (Privacy Policy) የድረ-ገጽ ሊንክ
- የGitHub Actions ሂደቱ ሲጠናቀቅ `privacy-policy.html` በራስ-ሰር ወደ ሪፖዚቶሪዎ ስለሚገባ፣ የግላዊነት ፖሊሲ ድረ-ገጽዎ በሚከተለው ሊንክ ይከፈታል፦
  - `https://ethiosport.github.io/ethio-sports-manual/privacy-policy.html`
- ይህንኑ ሊንክ በመተግበሪያው ውስጥም ሆነ በGoogle Play Console የ**Privacy Policy URL** መሙያ ሳጥን ውስጥ በቀጥታ መጠቀም ይችላሉ።
